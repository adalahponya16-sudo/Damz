/* Firebase web configuration. These values are public in a browser app.
   Protect your data with strict Realtime Database Security Rules. */
window.DAMZ_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDVHCc0DA4vjlKqAthVos0CYB7Rqm9AEIw",
  authDomain: "damz-tools-351e7.firebaseapp.com",
  databaseURL: "https://damz-tools-351e7-default-rtdb.firebaseio.com",
  projectId: "damz-tools-351e7",
  storageBucket: "damz-tools-351e7.firebasestorage.app",
  messagingSenderId: "52048337004",
  appId: "1:52048337004:web:e5b57f1498c3f03e97e049"
};
