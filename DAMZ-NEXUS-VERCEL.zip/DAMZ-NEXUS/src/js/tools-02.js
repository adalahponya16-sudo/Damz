
const $ = s => document.querySelector(s);
const modal = $('#m');
$('#close-m').onclick = () => modal.classList.add('hidden');
modal.onclick = e => { if (e.target === modal) modal.classList.add('hidden'); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') modal.classList.add('hidden'); });

// ===== HELPER CANVAS & UI FUNCTIONS =====
function lines(ctx, text, maxW) {
  const out = [];
  for (const para of String(text ?? '').split('\n')) {
    let line = '';
    for (const word of para.split(' ')) {
      const test = line ? line + ' ' + word : word;
      if (ctx.measureText(test).width > maxW && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

const now = () => {
  const d = new Date();
  return [
    d.toLocaleDateString('en-GB'),
    d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace('.', ':')
  ];
};

function rr(ctx, x, y, w, h, r, fill, stroke = null, lw = 1) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}

function drawCoverImage(ctx, img, x, y, w, h, radius = 0) {
  ctx.save();
  ctx.beginPath();
  if (radius > 0) ctx.roundRect(x, y, w, h, radius);
  else ctx.rect(x, y, w, h);
  ctx.clip();
  const scale = Math.max(w / img.width, h / img.height);
  const dw = img.width * scale;
  const dh = img.height * scale;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  ctx.restore();
}

function circ(ctx, img, cx, cy, r, fallbackBg = '#3b0764') {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();
  if (img) {
    const s = Math.max((2 * r) / img.width, (2 * r) / img.height);
    ctx.drawImage(img, cx - (img.width * s) / 2, cy - (img.height * s) / 2, img.width * s, img.height * s);
  } else {
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    g.addColorStop(0, '#581c87');
    g.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = fallbackBg === '#3b0764' ? g : fallbackBg;
    ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.beginPath(); ctx.arc(cx, cy - r * 0.18, r * 0.34, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy + r * 0.78, r * 0.62, Math.PI, 0); ctx.fill();
  }
  ctx.restore();
}

function copyText(txt, btn) {
  const ta = document.createElement('textarea');
  ta.value = txt;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
  if (btn) {
    const old = btn.innerHTML;
    btn.innerHTML = '✅ Tersalin!';
    setTimeout(() => (btn.innerHTML = old), 1600);
  }
}

// Helper: Extract YouTube Video ID
function getYTId(url) {
  const m = String(url || '').match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/|v\/))([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}

// Helper: Query Cobalt API with fallback
async function queryCobalt(url, isAudio = false) {
  const endpoints = [
    'https://api.cobalt.tools/',
    'https://cobalt-api.kwiatekmiki.com/'
  ];
  for (const ep of endpoints) {
    try {
      const res = await fetch(ep, {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: url.trim(),
          downloadMode: isAudio ? 'audio' : 'auto',
          videoQuality: '1080',
          audioFormat: 'mp3'
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data && (data.url || data.picker)) return data;
      }
    } catch {}
  }
  return null;
}

// ===== 33 TOOLS =====
const T = [
  // ======================== MAKER & FAKE UI ========================
  {
    n: 'Fake Lobby',
    i: '🎮',
    tag: 'GAME',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
    c: 'Maker',
    d: 'Lobi Free Fire & Mobile Legends (Draft)',
    f: [
      ['g', 'Pilih Game', 'sel', 'Free Fire|Mobile Legends'],
      ['n', 'Nickname Pemain', 'text', 'HANZZ'],
      ['r', 'Level / Sub-Rank', 'text', '1081'],
      ['p', 'Foto Karakter / Avatar', 'file']
    ],
    draw(x, c, v, im) {
      const W = (c.width = 540), H = (c.height = 960);
      const grad = (x0, y0, x1, y1, stops) => {
        const g = x.createLinearGradient(x0, y0, x1, y1);
        stops.forEach(([p, col]) => g.addColorStop(p, col));
        return g;
      };

      if (v.g === 'Free Fire') {
        x.fillStyle = grad(0, 0, 0, H, [[0, '#162844'], [0.45, '#2b476e'], [0.75, '#1c2b3d'], [1, '#0f1724']]);
        x.fillRect(0, 0, W, H);
        x.fillStyle = 'rgba(12, 22, 38, 0.75)';
        x.fillRect(0, 60, 190, 420);
        x.fillStyle = grad(360, 180, 540, 460, [[0, '#38bdf8'], [0.5, '#7dd3fc'], [1, '#0284c7']]);
        x.fillRect(390, 210, 150, 230);
        x.fillStyle = '#293545';
        x.beginPath(); x.moveTo(0, 680); x.lineTo(W, 680); x.lineTo(W, H); x.lineTo(0, H); x.fill();
        x.strokeStyle = 'rgba(148, 163, 184, 0.25)'; x.lineWidth = 2;
        for (let i = -3; i <= 8; i++) {
          x.beginPath(); x.moveTo(270 + i * 45, 680); x.lineTo(270 + i * 110, H); x.stroke();
        }
        for (let y = 710; y < H; y += 38) {
          x.beginPath(); x.moveTo(0, y); x.lineTo(W, y); x.stroke();
        }

        const goldThrone = grad(120, 200, 420, 860, [[0, '#fef08a'], [0.35, '#eab308'], [0.7, '#ca8a04'], [1, '#713f12']]);
        x.fillStyle = '#334155'; x.strokeStyle = '#fbbf24'; x.lineWidth = 2.5;
        [[-1], [1]].forEach(([dir]) => {
          x.save(); x.translate(270, 220); x.scale(dir, 1);
          x.beginPath();
          x.moveTo(20, 0); x.lineTo(240, -65); x.lineTo(260, -45); x.lineTo(130, 10);
          x.lineTo(220, 35); x.lineTo(110, 45); x.lineTo(160, 90); x.lineTo(40, 55);
          x.closePath(); x.fill(); x.stroke();
          x.restore();
        });

        x.fillStyle = goldThrone;
        for (let k = -4; k <= 4; k++) {
          if (k === 0) continue;
          x.save();
          x.translate(270 + k * 28, 460);
          x.rotate(k * 0.14);
          x.fillRect(-7, -230 + Math.abs(k) * 14, 14, 240);
          x.restore();
        }
        rr(x, 115, 420, 310, 360, 18, goldThrone, '#fef08a', 2);
        x.fillStyle = grad(40, 760, 500, 860, [[0, '#ca8a04'], [0.5, '#fde047'], [1, '#854d0e']]);
        x.beginPath(); x.moveTo(60, 770); x.lineTo(480, 770); x.lineTo(525, 855); x.lineTo(15, 855); x.closePath(); x.fill();

        if (im.p) {
          const s = Math.min(430 / im.p.width, 670 / im.p.height);
          const dw = im.p.width * s, dh = im.p.height * s;
          x.drawImage(im.p, 270 - dw / 2, 825 - dh, dw, dh);
        } else {
          rr(x, 215, 340, 110, 220, 24, '#f8fafc');
          rr(x, 210, 540, 52, 250, 14, '#0f172a');
          rr(x, 278, 540, 52, 250, 14, '#0f172a');
          rr(x, 215, 525, 110, 22, 6, '#eab308');
          x.fillStyle = '#fed7aa'; x.beginPath(); x.arc(270, 290, 42, 0, Math.PI * 2); x.fill();
          rr(x, 225, 242, 95, 28, 10, '#09090b');
          x.fillStyle = '#facc15'; x.font = 'bold 18px Arial'; x.textAlign = 'center'; x.fillText('FF', 270, 263);
          x.fillStyle = '#e2e8f0'; x.beginPath(); x.arc(270, 308, 36, 0, Math.PI); x.fill();
        }

        x.fillStyle = 'rgba(10, 14, 22, 0.85)';
        x.beginPath(); x.moveTo(0, 0); x.lineTo(445, 0); x.lineTo(415, 62); x.lineTo(0, 62); x.closePath(); x.fill();
        x.strokeStyle = 'rgba(255,255,255,0.2)'; x.lineWidth = 1.5; x.stroke();

        x.fillStyle = '#ffffff'; x.font = 'bold 26px Arial'; x.textAlign = 'left';
        x.fillText(v.r || '1081', 14, 41);

        x.fillStyle = grad(170, 6, 225, 56, [[0, '#fde047'], [0.5, '#ea580c'], [1, '#991b1b']]);
        x.beginPath(); x.moveTo(197, 5); x.lineTo(226, 24); x.lineTo(216, 54); x.lineTo(178, 54); x.lineTo(168, 24); x.closePath(); x.fill();
        x.strokeStyle = '#fef08a'; x.lineWidth = 2; x.stroke();
        x.fillStyle = '#fff'; x.font = 'bold 22px Arial'; x.textAlign = 'center'; x.fillText('8', 197, 40);

        rr(x, 266, 14, 56, 34, 6, grad(266, 14, 322, 48, [[0, '#fcd34d'], [1, '#b45309']]), '#fef9c3', 1.5);
        x.fillStyle = '#fff'; x.font = 'bold 18px Arial'; x.fillText('M 💎', 294, 37);

        x.fillStyle = '#fff'; x.beginPath(); x.arc(386, 31, 18, 0, Math.PI * 2); x.fill();
        x.fillStyle = '#881337'; x.font = 'bold 20px Arial'; x.fillText('☁', 386, 38);

        rr(x, 125, 765, 290, 44, 6, 'rgba(20, 14, 6, 0.88)', '#fbbf24', 2);
        rr(x, 127, 767, 56, 40, 4, grad(127, 767, 183, 807, [[0, '#f59e0b'], [1, '#92400e']]));
        x.fillStyle = '#1c1917'; x.font = '22px Arial'; x.fillText('⚑', 155, 795);
        x.fillStyle = '#fbbf24'; x.font = 'bold 24px Arial'; x.textAlign = 'center';
        x.fillText(v.n || 'HANZZ', 272, 795);
        x.fillStyle = '#b45309'; x.beginPath(); x.arc(386, 787, 15, 0, Math.PI * 2); x.fill();
        x.fillStyle = '#fef08a'; x.font = 'bold 13px Arial'; x.fillText('B', 386, 792);
        x.strokeStyle = '#fff'; x.lineWidth = 2.5; x.strokeRect(425, 775, 18, 24);
        x.fillStyle = '#fff'; x.fillText('➔', 442, 794);

        rr(x, 195, 816, 150, 30, 8, 'rgba(0,0,0,0.55)');
        x.fillStyle = '#e2e8f0'; x.font = '18px Arial';
        x.fillText('🎙️   |   🔊', 270, 837);
      } else {
        x.fillStyle = grad(0, 0, 0, H, [[0, '#061533'], [0.5, '#0b2554'], [1, '#07193d']]);
        x.fillRect(0, 0, W, H);
        x.fillStyle = 'rgba(18, 45, 92, 0.85)';
        x.beginPath(); x.moveTo(0, 0); x.lineTo(210, 0); x.lineTo(175, 56); x.lineTo(0, 56); x.closePath(); x.fill();
        x.strokeStyle = '#38bdf8'; x.lineWidth = 1.5; x.stroke();
        x.strokeStyle = '#60a5fa'; x.lineWidth = 4;
        x.beginPath(); x.moveTo(115, 22); x.lineTo(148, 22); x.arc(148, 30, 8, -Math.PI / 2, Math.PI / 2); x.lineTo(125, 38); x.stroke();
        x.beginPath(); x.moveTo(124, 15); x.lineTo(110, 22); x.lineTo(124, 29); x.stroke();

        x.fillStyle = '#7dd3fc'; x.font = 'bold 26px sans-serif'; x.textAlign = 'left';
        x.fillText('ランキング ドラフト', 212, 39);

        [[-85, 200], [445, 200]].forEach(([bx, by]) => {
          x.fillStyle = 'rgba(15, 38, 78, 0.55)';
          x.strokeStyle = 'rgba(56, 189, 248, 0.35)'; x.lineWidth = 2;
          x.beginPath();
          x.moveTo(bx, by); x.lineTo(bx + 180, by); x.lineTo(bx + 180, by + 400);
          x.lineTo(bx + 90, by + 465); x.lineTo(bx, by + 400); x.closePath();
          x.fill(); x.stroke();
          x.strokeStyle = 'rgba(148, 163, 184, 0.25)';
          x.strokeRect(bx + 25, by + 65, 130, 130);
          x.fillStyle = 'rgba(148, 163, 184, 0.28)'; x.font = 'bold 72px Arial'; x.textAlign = 'center';
          x.fillText('?', bx + 90, by + 155);
        });

        const cx = 270;
        x.fillStyle = grad(165, 190, 375, 760, [[0, 'rgba(13, 33, 68, 0.92)'], [0.5, 'rgba(26, 62, 118, 0.88)'], [1, 'rgba(14, 37, 74, 0.95)']]);
        x.strokeStyle = '#38bdf8'; x.lineWidth = 3;
        x.beginPath();
        x.moveTo(168, 195); x.lineTo(372, 195); x.lineTo(372, 680);
        x.lineTo(270, 755); x.lineTo(168, 680); x.closePath();
        x.fill(); x.stroke();

        x.shadowColor = '#38bdf8'; x.shadowBlur = 18;
        x.strokeRect(168, 260, 204, 390);
        x.shadowBlur = 0;

        x.fillStyle = '#4ade80'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('3 ンス 🏠', cx, 226);

        rr(x, 198, 240, 144, 144, 14, grad(198, 240, 342, 384, [[0, '#fef08a'], [0.5, '#f59e0b'], [1, '#7c2d12']]), '#fff', 2.5);
        rr(x, 208, 250, 124, 124, 8, '#f8fafc');
        if (im.p) {
          drawCoverImage(x, im.p, 208, 250, 124, 124, 8);
        } else {
          x.fillStyle = '#0f172a'; x.font = 'bold 24px Arial'; x.textAlign = 'center';
          x.fillText(v.n || 'HANZZ', cx, 320);
        }

        x.save();
        x.beginPath(); x.arc(212, 254, 19, 0, Math.PI * 2); x.clip();
        x.fillStyle = '#ef4444'; x.fillRect(193, 235, 38, 19);
        x.fillStyle = '#ffffff'; x.fillRect(193, 254, 38, 19);
        x.restore();
        x.strokeStyle = '#cbd5e1'; x.lineWidth = 2;
        x.beginPath(); x.arc(212, 254, 19, 0, Math.PI * 2); x.stroke();

        rr(x, 186, 392, 168, 34, 8, grad(186, 392, 354, 426, [[0, '#4f46e5'], [0.5, '#7c3aed'], [1, '#4338ca']]), '#a5b4fc', 1.5);
        x.fillStyle = '#fde047'; x.font = '18px Arial'; x.textAlign = 'left'; x.fillText('★', 196, 415);
        x.fillStyle = '#ffffff'; x.font = 'bold 20px Arial'; x.textAlign = 'center';
        x.fillText(v.n || 'HANZZ', cx + 8, 416);

        x.shadowColor = '#c084fc'; x.shadowBlur = 22;
        x.fillStyle = grad(210, 450, 330, 560, [[0, '#fef08a'], [0.45, '#e879f9'], [1, '#6d28d9']]);
        x.beginPath();
        x.moveTo(cx, 448); x.lineTo(328, 482); x.lineTo(312, 542); x.lineTo(cx, 570); x.lineTo(228, 542); x.lineTo(212, 482);
        x.closePath(); x.fill();
        x.strokeStyle = '#fef9c3'; x.lineWidth = 2.5; x.stroke();
        x.shadowBlur = 0;

        x.fillStyle = '#7dd3fc'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('トフライシ', cx, 604);

        const playGrad = grad(110, 785, 430, 850, [[0, '#92702a'], [0.5, '#e6c875'], [1, '#8a6822']]);
        x.fillStyle = playGrad; x.strokeStyle = '#fef08a'; x.lineWidth = 2.5;
        x.beginPath();
        x.moveTo(140, 785); x.lineTo(400, 785); x.lineTo(432, 818); x.lineTo(400, 851); x.lineTo(140, 851); x.lineTo(108, 818);
        x.closePath(); x.fill(); x.stroke();
        x.fillStyle = '#ffffff'; x.font = 'bold 34px sans-serif'; x.textAlign = 'center';
        x.fillText('プレイ', cx, 830);

        rr(x, 0, 885, 380, 42, 4, 'rgba(12, 30, 62, 0.85)', 'rgba(96, 165, 250, 0.4)', 1.5);
        x.beginPath(); x.arc(475, 905, 36, 0, Math.PI * 2);
        x.fillStyle = '#0f2952'; x.fill();
        x.strokeStyle = '#fde047'; x.lineWidth = 3; x.stroke();
        x.fillStyle = '#fde047'; x.font = 'bold 24px Arial'; x.fillText('⚑+', 475, 914);
        x.fillStyle = '#4ade80'; x.font = 'bold 13px Arial'; x.fillText('NEW', 498, 876);
      }
    }
  },

  {
    n: 'Fake DANA',
    i: '💙',
    tag: 'E-WALLET',
    badge: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    c: 'Maker',
    d: 'Beranda saldo DANA biru realistis',
    f: [
      ['s', 'Nominal Saldo (contoh: 10.000)', 'text', '10.000'],
      ['p1', 'Teks Feed 1', 'text', 'Feed sambungkan koneksi yang terpercaya!'],
      ['p2', 'Teks Feed 2', 'text', 'Feed berikan 💬,❤️,🎁 biar seru!']
    ],
    draw(x, c, v) {
      const W = (c.width = 450), H = (c.height = 960);
      const topG = x.createLinearGradient(0, 0, 0, 320);
      topG.addColorStop(0, '#118eea'); topG.addColorStop(1, '#0c7cd5');
      x.fillStyle = topG; x.fillRect(0, 0, W, 320);
      x.fillStyle = '#f4f6f9'; x.fillRect(0, 320, W, H - 320);

      x.fillStyle = '#ffffff'; x.beginPath(); x.arc(30, 48, 15, 0, Math.PI * 2); x.fill();
      rr(x, 22, 42, 16, 11, 3, '#118eea');

      x.fillStyle = 'rgba(255,255,255,0.85)'; x.font = '600 15px sans-serif'; x.textAlign = 'left';
      x.fillText('Rp', 56, 53);
      x.fillStyle = '#ffffff'; x.font = 'bold 24px sans-serif';
      x.fillText(v.s || '10.000', 80, 55);
      const balW = x.measureText(v.s || '10.000').width;
      x.strokeStyle = 'rgba(255,255,255,0.85)'; x.lineWidth = 2;
      x.beginPath(); x.arc(96 + balW, 47, 7, 0, Math.PI * 2); x.stroke();
      x.beginPath(); x.moveTo(88 + balW, 54); x.lineTo(104 + balW, 40); x.stroke();

      rr(x, 330, 30, 102, 34, 17, 'rgba(255,255,255,0.2)', 'rgba(255,255,255,0.55)', 1.2);
      x.fillStyle = '#fff'; x.font = 'bold 14px sans-serif'; x.textAlign = 'center';
      x.fillText('DANA +', 381, 52);
      x.fillStyle = '#ef4444'; x.beginPath(); x.arc(426, 34, 5, 0, Math.PI * 2); x.fill();

      [['Isi Saldo', '+'], ['Minta', 'Rp↓'], ['Kirim', 'Rp↗'], ['Pesan', '✉']].forEach(([lbl, ico], idx) => {
        const ax = 68 + idx * 104;
        rr(x, ax - 22, 86, 44, 44, 12, 'rgba(255,255,255,0.12)', 'rgba(255,255,255,0.45)', 1.5);
        x.fillStyle = '#fff'; x.font = 'bold 16px sans-serif'; x.textAlign = 'center';
        x.fillText(ico, ax, 114);
        x.font = '600 13px sans-serif';
        x.fillText(lbl, ax, 152);
        if (idx === 3) { x.fillStyle = '#ef4444'; x.beginPath(); x.arc(ax + 18, 90, 6, 0, Math.PI * 2); x.fill(); }
      });

      x.fillStyle = '#fde047'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
      x.fillText('✨ DANA Ngabuburich ✨', 235, 205);
      x.fillStyle = '#ffffff'; x.font = 'italic bold 16px sans-serif';
      x.fillText('• Hadiah Setiap Hari •', 235, 232);
      rr(x, 155, 245, 160, 32, 16, '#facc15', '#fef08a', 1.5);
      x.fillStyle = '#1e293b'; x.font = 'bold 15px sans-serif';
      x.fillText('SERBU', 235, 266);

      rr(x, 16, 295, 418, 215, 18, '#ffffff', '#e2e8f0', 1);
      [
        ['Pusat\nHadiah', '🎁', '#ef4444'], ['Hadiah\nHarian', '📅', '#f59e0b'],
        ['Klaim\niPhone 17', '📱', '#3b82f6'], ['Google\nPlay Zone', '▶️', '#10b981'],
        ['A+\nRewards', '💎', '#0ea5e9'], ['Pulsa &\nData', '📶', '#f43f5e'],
        ['Listrik', '💡', '#eab308'], ['Lihat\nSemua', '⊞', '#64748b']
      ].forEach(([title, em, col], k) => {
        const sx = 68 + (k % 4) * 104, sy = 335 + Math.floor(k / 4) * 96;
        x.fillStyle = col + '22'; x.beginPath(); x.arc(sx, sy, 22, 0, Math.PI * 2); x.fill();
        x.font = '22px sans-serif'; x.textAlign = 'center'; x.fillText(em, sx, sy + 8);
        x.fillStyle = '#1e293b'; x.font = '600 12px sans-serif';
        title.split('\n').forEach((ln, li) => x.fillText(ln, sx, sy + 38 + li * 15));
      });

      rr(x, 16, 524, 418, 150, 16, '#ffffff', '#e2e8f0', 1);
      [
        v.p1 || 'Feed sambungkan koneksi yang terpercaya!',
        v.p2 || 'Feed berikan 💬,❤️,🎁 biar seru!',
        'Feed hai 👋, siap menjelajah feed?',
        'Feed masuk untuk lihat update terbaru!'
      ].forEach((ft, idx) => {
        const fy = 552 + idx * 33;
        x.fillStyle = '#118eea'; x.beginPath(); x.arc(42, fy - 4, 11, 0, Math.PI * 2); x.fill();
        x.fillStyle = '#fff'; x.font = '10px sans-serif'; x.textAlign = 'center'; x.fillText('♥', 42, fy);
        x.fillStyle = '#334155'; x.font = '12.5px sans-serif'; x.textAlign = 'left'; x.fillText(ft.slice(0, 42), 62, fy);
        x.fillStyle = '#0ea5e9'; x.textAlign = 'right'; x.fillText('📢', 416, fy);
      });

      const banG = x.createLinearGradient(22, 688, 428, 845);
      banG.addColorStop(0, '#0284c7'); banG.addColorStop(1, '#1d4ed8');
      rr(x, 22, 688, 406, 155, 16, banG);
      x.fillStyle = '#fde047'; x.font = 'bold 22px sans-serif'; x.textAlign = 'left'; x.fillText('Penting!', 46, 730);
      x.fillStyle = '#ffffff'; x.font = '600 14px sans-serif';
      x.fillText('Tagihan First Media', 46, 756); x.fillText('Sekarang Dibayar Lewat', 46, 776);
      x.font = 'bold 24px sans-serif'; x.fillText('XL SATU', 46, 814);

      x.fillStyle = '#ffffff'; x.fillRect(0, 882, W, 78);
      x.strokeStyle = '#e2e8f0'; x.lineWidth = 1; x.strokeRect(0, 882, W, 1);
      ['Beranda', 'Aktivitas', '', 'Dompet', 'Saya'].forEach((nv, idx) => {
        if (idx === 2) return;
        const nx = 45 + idx * 90;
        x.fillStyle = idx === 0 ? '#118eea' : '#64748b';
        x.font = '20px sans-serif'; x.textAlign = 'center'; x.fillText(['👛', '🧾', '', '💳', '👤'][idx], nx, 916);
        x.font = '600 11.5px sans-serif'; x.fillText(nv, nx, 942);
      });
      x.fillStyle = '#118eea'; x.beginPath(); x.arc(225, 908, 42, 0, Math.PI * 2); x.fill();
      x.strokeStyle = '#ffffff'; x.lineWidth = 3; x.stroke();
      x.fillStyle = '#ffffff'; x.font = 'bold 14px sans-serif'; x.textAlign = 'center';
      x.fillText('⊞ QR', 225, 904); x.fillText('PAY', 225, 926);
    }
  },

  {
    n: 'Fake OVO',
    i: '💜',
    tag: 'E-WALLET',
    badge: 'bg-purple-500/20 text-purple-300 border-purple-400/40',
    c: 'Maker',
    d: 'Tampilan saldo OVO Cash ungu mewah',
    f: [
      ['s', 'Nominal OVO Cash (contoh: 1.000.000)', 'text', '1.000.000'],
      ['p', 'Teks Banner Info', 'text', 'Top-up OVO sesering mungkin, raih total 40JT OVO Points']
    ],
    draw(x, c, v) {
      const W = (c.width = 450), H = (c.height = 960);
      const bgG = x.createLinearGradient(0, 0, 0, 320);
      bgG.addColorStop(0, '#ede9fe'); bgG.addColorStop(1, '#f8fafc');
      x.fillStyle = bgG; x.fillRect(0, 0, W, H);

      x.fillStyle = '#4c1d95'; x.font = '900 28px sans-serif'; x.textAlign = 'left'; x.fillText('OVO', 20, 52);
      rr(x, 336, 26, 96, 32, 16, '#ddd6fe');
      x.fillStyle = '#5b21b6'; x.font = 'bold 13px sans-serif'; x.textAlign = 'center'; x.fillText('🏷 Promo', 384, 47);

      const cardG = x.createLinearGradient(18, 72, 432, 250);
      cardG.addColorStop(0, '#4338ca'); cardG.addColorStop(0.5, '#6d28d9'); cardG.addColorStop(1, '#3b82f6');
      rr(x, 18, 72, 414, 175, 20, cardG);

      x.fillStyle = '#ffffff'; x.font = 'bold 17px sans-serif'; x.textAlign = 'left'; x.fillText('OVO Cash', 36, 104);
      x.fillStyle = 'rgba(255,255,255,0.8)'; x.font = '12px sans-serif'; x.fillText('Total Saldo 👁', 36, 126);
      x.fillStyle = '#ffffff'; x.font = 'bold 14px sans-serif'; x.fillText('Rp', 36, 152);
      x.font = 'bold 23px sans-serif'; x.fillText(v.s || '1.000.000', 60, 154);

      rr(x, 294, 134, 122, 28, 14, '#ffffff');
      x.fillStyle = '#5b21b6'; x.font = 'bold 11.5px sans-serif'; x.textAlign = 'center'; x.fillText('℗ OVO Points >', 355, 152);

      [['Top Up', '+'], ['Transfer', '↑'], ['Tarik Tunai', '↓'], ['History', '≡']].forEach(([lbl, ic], idx) => {
        const ox = 72 + idx * 102;
        x.fillStyle = '#ffffff'; x.beginPath(); x.arc(ox, 194, 16, 0, Math.PI * 2); x.fill();
        x.fillStyle = '#5b21b6'; x.font = 'bold 16px sans-serif'; x.textAlign = 'center'; x.fillText(ic, ox, 200);
        x.fillStyle = '#ffffff'; x.font = '600 12px sans-serif'; x.fillText(lbl, ox, 228);
      });

      x.fillStyle = '#0369a1'; x.fillRect(0, 265, W, 46);
      x.fillStyle = '#ffffff'; x.font = '12px sans-serif'; x.textAlign = 'left';
      x.fillText('ⓘ  ' + (v.p || 'Top-up OVO sesering mungkin, raih total 40JT OVO Points').slice(0, 46), 18, 293);

      x.fillStyle = '#ffffff'; x.beginPath(); x.arc(395, 276, 38, 0, Math.PI * 2); x.fill();
      x.strokeStyle = '#fbbf24'; x.lineWidth = 2.5; x.stroke();
      x.fillStyle = '#ea580c'; x.font = '900 12px sans-serif'; x.textAlign = 'center';
      x.fillText('OVO', 395, 264); x.fillText('STAMP', 395, 279);
      rr(x, 360, 294, 70, 18, 9, '#16a34a');
      x.fillStyle = '#fff'; x.font = 'bold 10px sans-serif'; x.fillText('Mulai Misi!', 395, 306);

      rr(x, 18, 330, 414, 138, 16, '#ffffff', '#e2e8f0', 1);
      x.fillStyle = '#fde047'; x.beginPath(); x.arc(58, 378, 22, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#7c3aed'; x.beginPath(); x.arc(58, 370, 12, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#fff'; x.font = 'bold 10px sans-serif'; x.fillText('Rp', 58, 374);
      x.fillStyle = '#0f172a'; x.font = 'bold 13px sans-serif'; x.textAlign = 'left';
      x.fillText('Mau bunga 5%? Yuk, upgrade ke OVO Nabung! Mudah,', 95, 372);
      x.fillText('cepet, dan cuan! ✨', 95, 392);
      rr(x, 278, 416, 136, 34, 17, '#5b21b6');
      x.fillStyle = '#ffffff'; x.font = 'bold 12.5px sans-serif'; x.textAlign = 'center'; x.fillText('Cek OVO Nabung', 346, 437);

      ['Favorit', 'Finansial', 'Hiburan', 'Pilihan Lain'].forEach((ct, idx) => {
        const tx = 58 + idx * 106;
        if (idx === 0) { rr(x, 18, 486, 82, 30, 15, '#ede9fe'); x.fillStyle = '#5b21b6'; x.font = 'bold 13px sans-serif'; }
        else { x.fillStyle = '#475569'; x.font = '600 13px sans-serif'; }
        x.textAlign = 'center'; x.fillText(ct, tx, 506);
      });

      [
        ['Nabung by\nSuperbank', '🏦', 'BARU', '#ede9fe'], ['Pinjaman', '🤝', 'BARU', '#ede9fe'],
        ['Uang Elektronik', '💳', 'PROMO', '#ffedd5'], ['Angsuran Kredit', '🧾', '', '#fce7f3'],
        ['Pulsa/Paket Data', '📱', 'PROMO', '#dbeafe'], ['PLN', '⚡', 'PROMO', '#fef3c7'],
        ['Air PDAM', '💧', '', '#e0f2fe'], ['Internet & TV\nKabel', '🖥️', '', '#ffedd5']
      ].forEach(([nm, em, bdg, bgc], k) => {
        const gx = 68 + (k % 4) * 104, gy = 562 + Math.floor(k / 4) * 108;
        x.fillStyle = bgc; x.beginPath(); x.arc(gx, gy, 24, 0, Math.PI * 2); x.fill();
        x.font = '22px sans-serif'; x.textAlign = 'center'; x.fillText(em, gx, gy + 8);
        if (bdg) {
          rr(x, gx - 24, gy - 32, 48, 16, 8, '#dc2626');
          x.fillStyle = '#ffffff'; x.font = 'bold 9px sans-serif'; x.fillText(bdg, gx, gy - 21);
        }
        x.fillStyle = '#1e293b'; x.font = '600 11.5px sans-serif';
        nm.split('\n').forEach((ln, li) => x.fillText(ln, gx, gy + 42 + li * 15));
      });

      x.fillStyle = '#0f172a'; x.font = 'bold 18px sans-serif'; x.textAlign = 'left'; x.fillText('Kenali OVO Lebih Dekat', 20, 815);
      x.fillStyle = '#2563eb'; x.font = 'bold 13px sans-serif'; x.textAlign = 'right'; x.fillText('Tutup', 430, 815);
      x.fillStyle = '#64748b'; x.font = '12.5px sans-serif'; x.textAlign = 'left'; x.fillText('Biar makin akrab, yuk cek tips berikut!', 20, 840);

      x.fillStyle = '#ffffff'; x.fillRect(0, 882, W, 78);
      x.strokeStyle = '#e2e8f0'; x.strokeRect(0, 882, W, 1);
      ['Home', 'Finance', '', 'Inbox', 'Profile'].forEach((nv, idx) => {
        if (idx === 2) return;
        const nx = 45 + idx * 90;
        x.fillStyle = idx === 0 ? '#5b21b6' : '#64748b';
        x.font = '20px sans-serif'; x.textAlign = 'center'; x.fillText(['🏠', '🪙', '', '🔔', '👤'][idx], nx, 916);
        x.font = '600 11.5px sans-serif'; x.fillText(nv, nx, 942);
      });
      const qG = x.createLinearGradient(195, 868, 255, 932);
      qG.addColorStop(0, '#7c3aed'); qG.addColorStop(1, '#4c1d95');
      x.fillStyle = qG; x.beginPath(); x.arc(225, 898, 28, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#ffffff'; x.font = 'bold 11px sans-serif'; x.textAlign = 'center'; x.fillText('QRIS', 225, 902);
      x.fillStyle = '#64748b'; x.font = '600 11.5px sans-serif'; x.fillText('Pay', 225, 942);
    }
  },

  {
    n: 'FakeDev',
    i: '👨‍💻',
    tag: 'DEV CARD',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
    c: 'Maker',
    d: 'Kartu profil developer verified + latar VS Code',
    f: [
      ['t', 'Nama Developer', 'text', 'HANZZ'],
      ['b', 'Role / Bio Bawah', 'text', 'Full Stack Developer'],
      ['p', 'Foto Profil', 'file']
    ],
    draw(x, c, v, im) {
      const W = (c.width = 800), H = (c.height = 800);
      x.fillStyle = '#0d1017'; x.fillRect(0, 0, W, H);
      x.fillStyle = '#141821'; x.fillRect(0, 0, 68, H);
      x.strokeStyle = '#222834'; x.lineWidth = 2; x.strokeRect(0, 0, 68, H);
      ['📄', '🔍', '🌿', '🐞', '🧩', '⚙️'].forEach((ic, idx) => {
        x.fillStyle = idx === 0 ? '#ffffff' : '#64748b';
        x.font = '26px sans-serif'; x.textAlign = 'center'; x.fillText(ic, 34, 70 + idx * 75);
      });

      const codeLines = [
        ['1', '#64748b', 'import ', '#c084fc', 'java.util.List;', '#e2e8f0'],
        ['2', '#64748b', 'import ', '#c084fc', 'java.util.concurrent.ExecutorService;', '#e2e8f0'],
        ['3', '#64748b', 'import ', '#c084fc', 'java.util.concurrent.Executors;', '#e2e8f0'],
        ['5', '#64748b', 'public class ', '#38bdf8', 'ShadowEngine {', '#fde047'],
        ['6', '#64748b', '  // Run | Debug', '#4ade80', '', '#fff'],
        ['7', '#64748b', '  public static void ', '#38bdf8', 'main(String[] args) {', '#f472b6'],
        ['8', '#64748b', '    var list = ', '#c084fc', 'List.of("HANZZ", "PRO");', '#a3e635'],
        ['12', '#64748b', '    ExecutorService pool = ', '#e2e8f0', 'Executors.newFixedThreadPool(8);', '#38bdf8'],
        ['15', '#64748b', '    pool.submit(() -> ', '#c084fc', 'System.out.println("Ready!");', '#fb923c'],
        ['20', '#64748b', '  } catch (Exception e) {', '#f43f5e', ' e.printStackTrace(); }', '#94a3b8'],
        ['24', '#64748b', '}', '#fde047', '', '#fff']
      ];
      x.font = '19px "JetBrains Mono", monospace'; x.textAlign = 'left';
      codeLines.forEach(([ln, c1, t1, c2, t2, c3], idx) => {
        const y = 45 + idx * 66;
        x.fillStyle = c1; x.fillText(ln, 92, y);
        x.fillStyle = c2; x.fillText(t1, 138, y);
        const w1 = x.measureText(t1).width;
        x.fillStyle = c3; x.fillText(t2, 138 + w1, y);
      });

      const vig = x.createRadialGradient(400, 400, 120, 400, 400, 520);
      vig.addColorStop(0, 'rgba(10, 12, 20, 0.25)'); vig.addColorStop(1, 'rgba(5, 6, 12, 0.72)');
      x.fillStyle = vig; x.fillRect(0, 0, W, H);

      x.strokeStyle = 'rgba(255, 255, 255, 0.28)'; x.lineWidth = 4;
      x.beginPath(); x.arc(400, 410, 244, 0, Math.PI * 2); x.stroke();

      x.shadowColor = 'rgba(255, 255, 255, 0.75)'; x.shadowBlur = 22;
      x.strokeStyle = '#ffffff'; x.lineWidth = 14;
      x.beginPath(); x.arc(400, 410, 224, 0, Math.PI * 2); x.stroke();
      x.shadowBlur = 0;

      circ(x, im.p, 400, 410, 214, '#1e1b4b');

      x.fillStyle = '#ffffff';
      x.beginPath(); x.arc(116, 410, 6.5, 0, Math.PI * 2); x.fill();
      x.beginPath(); x.arc(684, 410, 6.5, 0, Math.PI * 2); x.fill();

      const titleText = v.t || 'HANZZ';
      x.font = '900 54px "Plus Jakarta Sans", Arial, sans-serif';
      const tw = x.measureText(titleText).width;
      const startX = 400 - (tw + 44) / 2;

      x.fillStyle = '#ffffff'; x.textAlign = 'left';
      x.shadowColor = 'rgba(0,0,0,0.85)'; x.shadowBlur = 12;
      x.fillText(titleText, startX, 134);
      x.shadowBlur = 0;

      const bx = startX + tw + 24, by = 115;
      x.fillStyle = '#1d9bf0'; x.beginPath(); x.arc(bx, by, 17, 0, Math.PI * 2); x.fill();
      x.strokeStyle = '#ffffff'; x.lineWidth = 3.5; x.lineCap = 'round'; x.lineJoin = 'round';
      x.beginPath(); x.moveTo(bx - 7, by); x.lineTo(bx - 2, by + 6); x.lineTo(bx + 8, by - 6); x.stroke();

      x.fillStyle = '#ffffff'; x.font = '900 44px "Plus Jakarta Sans", Arial, sans-serif'; x.textAlign = 'center';
      x.shadowColor = 'rgba(0,0,0,0.9)'; x.shadowBlur = 14;
      x.fillText(v.b || 'Full Stack Developer', 400, 715);
      x.shadowBlur = 0;
    }
  },

  {
    n: 'BRAT Generator',
    i: '💚',
    tag: 'MEME',
    badge: 'bg-lime-500/20 text-lime-300 border-lime-400/40',
    c: 'Maker',
    d: 'Teks album cover BRAT autentik (Putih / Hijau)',
    f: [
      ['t', 'Teks BRAT', 'area', 'Contoh'],
      ['bg', 'Warna Background', 'sel', 'Putih|Hijau']
    ],
    draw(x, c, v) {
      const S = (c.width = c.height = 700);
      x.fillStyle = v.bg === 'Hijau' ? '#8ace00' : '#ffffff';
      x.fillRect(0, 0, S, S);
      x.save();
      x.filter = 'blur(2.4px)';
      x.fillStyle = '#080808';
      x.textAlign = 'left'; x.textBaseline = 'top';
      x.scale(0.82, 1.04);
      const maxW = (S - 90) / 0.82;
      let fontSize = 185, wrapped = [];
      do {
        x.font = `500 ${fontSize}px Arial, Helvetica, sans-serif`;
        wrapped = lines(x, v.t || 'Contoh', maxW);
        if (wrapped.length * fontSize * 1.12 <= S - 90) break;
        fontSize -= 6;
      } while (fontSize > 36);
      wrapped.forEach((lineStr, idx) => x.fillText(lineStr, 54, 48 + idx * fontSize * 1.12));
      x.restore();
    }
  },

  {
    n: 'iQC (iPhone Chat)',
    i: '📱',
    tag: 'IOS UI',
    badge: 'bg-zinc-500/25 text-zinc-200 border-zinc-400/40',
    c: 'Maker',
    d: 'Popup long-press WhatsApp iPhone Dark Mode',
    f: [
      ['t', 'Isi Chat', 'area', 'Hai'],
      ['tm', 'Jam Chat', 'text', '12'],
      ['op', 'Operator Sinyal', 'text', 'Axis'],
      ['bt', 'Persentase Baterai (%)', 'text', '65']
    ],
    draw(x, c, v) {
      const W = (c.width = 450), H = (c.height = 840);
      x.fillStyle = '#0b1014'; x.fillRect(0, 0, W, H);
      x.save();
      x.filter = 'blur(16px)';
      x.fillStyle = '#1f2c34'; x.fillRect(0, 35, W, 55);
      x.fillStyle = '#334155'; x.beginPath(); x.arc(100, 62, 20, 0, Math.PI * 2); x.fill();
      rr(x, 235, 95, 195, 75, 16, '#0d4a3e');
      rr(x, 25, 205, 160, 48, 14, '#242f36');
      rr(x, 95, 290, 330, 85, 16, '#0d4a3e');
      rr(x, 180, 440, 245, 70, 16, '#0d4a3e');
      rr(x, 220, 560, 205, 80, 16, '#0d4a3e');
      x.restore();

      x.fillStyle = 'rgba(0, 0, 0, 0.38)'; x.fillRect(0, 0, W, H);
      x.fillStyle = '#ffffff';
      [7, 10, 13, 16].forEach((bh, idx) => rr(x, 16 + idx * 5, 26 - bh, 3.2, bh, 1, idx < 3 ? '#fff' : 'rgba(255,255,255,0.4)'));
      x.font = '600 13px -apple-system, BlinkMacSystemFont, sans-serif'; x.textAlign = 'left';
      x.fillText(v.op || 'Axis', 42, 25);
      x.textAlign = 'center'; x.fillText(v.tm || '12', 225, 25);
      x.textAlign = 'right'; x.fillText(`ᯤ  ${v.bt || '65'}%`, 400, 25);
      rr(x, 405, 14, 26, 13, 3.5, null, 'rgba(255,255,255,0.65)', 1.2);
      const pct = Math.min(100, Math.max(10, parseInt(v.bt) || 65)) / 100;
      rr(x, 407, 16, 22 * pct, 9, 2, '#34c759');

      rr(x, 12, 265, 342, 62, 31, 'rgba(42, 42, 45, 0.94)', 'rgba(255,255,255,0.08)', 1);
      x.font = '30px Apple Color Emoji, Segoe UI Emoji, sans-serif'; x.textAlign = 'center';
      ['👍', '❤️', '😂', '😮', '😢', '🙏'].forEach((em, idx) => x.fillText(em, 48 + idx * 54, 307));

      x.font = '18px -apple-system, BlinkMacSystemFont, sans-serif';
      const msgLines = lines(x, v.t || 'Hai', 260);
      const maxLineW = Math.max(...msgLines.map(l => x.measureText(l).width), 38);
      const bubW = Math.min(310, Math.max(76, maxLineW + 46));
      const bubH = Math.max(60, msgLines.length * 24 + 34);
      const bubY = 342;

      rr(x, 12, bubY, bubW, bubH, 14, 'rgba(46, 46, 49, 0.96)');
      x.fillStyle = '#ffffff'; x.textAlign = 'left';
      msgLines.forEach((ln, idx) => x.fillText(ln, 24, bubY + 26 + idx * 24));
      x.fillStyle = 'rgba(255,255,255,0.55)'; x.font = '12px -apple-system, sans-serif'; x.textAlign = 'right';
      x.fillText(v.tm || '12', 12 + bubW - 12, bubY + bubH - 10);

      const menuY = bubY + bubH + 10, menuW = 324, rowH = 54;
      const items = [
        ['Beri Bintang', '☆', '#ffffff'], ['Balas', '↩', '#ffffff'], ['Teruskan', '↪', '#ffffff'],
        ['Salin', '❐', '#ffffff'], ['Ucapkan', '💬', '#ffffff'], ['Laporkan', '⚠', '#ffffff'], ['Hapus', '🗑', '#ff453a']
      ];
      rr(x, 12, menuY, menuW, items.length * rowH, 16, 'rgba(38, 38, 40, 0.95)');
      items.forEach(([label, icon, col], idx) => {
        const ry = menuY + idx * rowH;
        if (idx > 0) { x.fillStyle = 'rgba(255,255,255,0.12)'; x.fillRect(12, ry, menuW, 1); }
        x.fillStyle = col; x.font = '17px -apple-system, BlinkMacSystemFont, sans-serif'; x.textAlign = 'left';
        x.fillText(label, 30, ry + 34);
        x.font = '19px sans-serif'; x.textAlign = 'right'; x.fillText(icon, 12 + menuW - 22, ry + 34);
      });
    }
  },

  {
    n: 'Fake e-KTP',
    i: '🪪',
    tag: 'ID CARD',
    badge: 'bg-cyan-500/20 text-cyan-200 border-cyan-400/40',
    c: 'Maker',
    d: 'Kartu e-KTP parodi lengkap dengan pas foto',
    f: [
      ['prov', 'Provinsi', 'text', 'PROVINSI DKI JAKARTA'],
      ['kota', 'Kabupaten / Kota', 'text', 'KOTA JAKARTA TIMUR'],
      ['nik', 'NIK (16 Digit)', 'text', '3175000000000001'],
      ['nama', 'Nama Lengkap', 'text', 'HANZZ'],
      ['ttl', 'Tempat/Tgl Lahir', 'text', 'JAKARTA, 01-01-2005'],
      ['jk', 'Jenis Kelamin', 'text', 'LAKI-LAKI'],
      ['gol', 'Gol. Darah', 'text', 'O'],
      ['alm', 'Alamat', 'text', 'JL. CYBER SHADOW NO. 01'],
      ['rt', 'RT/RW', 'text', '001/002'],
      ['kel', 'Kel/Desa', 'text', 'CIPINANG'],
      ['kec', 'Kecamatan', 'text', 'JATINEGARA'],
      ['agm', 'Agama', 'text', 'ISLAM'],
      ['st', 'Status Perkawinan', 'text', 'BELUM KAWIN'],
      ['pk', 'Pekerjaan', 'text', 'DEVELOPER'],
      ['ttd', 'Kota & Tgl Dibuat', 'text', 'JAKARTA TIMUR, 01-01-2026'],
      ['p', 'Pas Foto (Opsional)', 'file']
    ],
    draw(x, c, v, im) {
      const W = (c.width = 960), H = (c.height = 605);
      const ktpG = x.createLinearGradient(0, 0, W, H);
      ktpG.addColorStop(0, '#c8edf9'); ktpG.addColorStop(0.5, '#b2e4f6'); ktpG.addColorStop(1, '#93d7f0');
      rr(x, 8, 8, W - 16, H - 16, 26, ktpG, '#5ba9c7', 3);

      x.save();
      x.beginPath(); x.roundRect(10, 10, W - 20, H - 20, 24); x.clip();
      [[180, 140, 110], [420, 90, 95], [710, 130, 120], [260, 340, 130], [560, 310, 140], [820, 440, 115], [140, 490, 105]].forEach(([cx, cy, cr]) => {
        x.fillStyle = 'rgba(255, 255, 255, 0.22)'; x.beginPath(); x.arc(cx, cy, cr, 0, Math.PI * 2); x.fill();
      });

      x.fillStyle = '#0f172a'; x.textAlign = 'center';
      x.font = '800 30px Arial, sans-serif'; x.fillText((v.prov || 'PROVINSI DKI JAKARTA').toUpperCase(), W / 2, 54);
      x.font = '800 26px Arial, sans-serif'; x.fillText((v.kota || 'KOTA JAKARTA TIMUR').toUpperCase(), W / 2, 88);

      x.textAlign = 'left'; x.font = '800 32px "JetBrains Mono", Arial, sans-serif';
      x.fillText('NIK', 48, 142); x.fillText(': ' + (v.nik || '3175000000000001'), 136, 142);

      [
        ['Nama', v.nama || 'HANZZ'], ['Tempat/Tgl Lahir', v.ttl || 'JAKARTA, 01-01-2005'],
        ['Jenis Kelamin', `${(v.jk || 'LAKI-LAKI').toUpperCase()}    GOL. DARAH: ${(v.gol || '-').toUpperCase()}`],
        ['Alamat', v.alm || 'JL. CYBER SHADOW NO. 01'], ['RT/RW', v.rt || '001/002'],
        ['Kel/Desa', v.kel || 'CIPINANG'], ['Kecamatan', v.kec || 'JATINEGARA'],
        ['Agama', v.agm || 'ISLAM'], ['Status Perkawinan', v.st || 'BELUM KAWIN'],
        ['Pekerjaan', v.pk || 'DEVELOPER'], ['Kewarganegaraan', 'WNI'], ['Berlaku Hingga', 'SEUMUR HIDUP']
      ].forEach(([lbl, val], idx) => {
        const y = 194 + idx * 31.5;
        const indent = (lbl === 'RT/RW' || lbl === 'Kel/Desa' || lbl === 'Kecamatan') ? 76 : 48;
        x.fillStyle = '#0f172a'; x.font = '600 20px Arial, sans-serif'; x.fillText(lbl, indent, y);
        x.font = '700 20px Arial, sans-serif'; x.fillText(': ' + String(val).toUpperCase(), 256, y);
      });

      const px = 732, py = 172, pw = 166, ph = 208;
      rr(x, px, py, pw, ph, 12, '#f8fafc', '#e2e8f0', 2);
      if (im.p) {
        drawCoverImage(x, im.p, px + 6, py + 6, pw - 12, ph - 12, 8);
      } else {
        rr(x, px + 7, py + 7, pw - 14, ph - 14, 8, '#cbd5e1');
        x.fillStyle = '#64748b'; x.beginPath(); x.arc(px + pw / 2, py + 74, 38, 0, Math.PI * 2); x.fill();
        x.beginPath(); x.arc(px + pw / 2, py + 175, 64, Math.PI, 0); x.fill();
      }

      const cityShort = (v.kota || 'KOTA JAKARTA').replace(/^KOTA\s+|^KABUPATEN\s+/i, '').toUpperCase();
      x.fillStyle = '#0f172a'; x.textAlign = 'center';
      x.font = '700 18px Arial, sans-serif'; x.fillText(cityShort, px + pw / 2, 412);
      x.font = '600 15px Arial, sans-serif'; x.fillText((v.ttd || 'JAKARTA, 01-01-2026').toUpperCase(), px + pw / 2, 438);
      x.font = 'italic bold 22px Georgia, serif'; x.fillText((v.nama || 'HANZZ').split(' ')[0], px + pw / 2, 495);

      x.save();
      x.translate(W / 2, H / 2 + 15); x.rotate(-0.42);
      x.fillStyle = 'rgba(100, 116, 139, 0.24)'; x.font = '800 44px Arial, sans-serif'; x.textAlign = 'center';
      x.fillText('PARODI - BUKAN DOKUMEN RESMI', 0, 0);
      x.restore();
      x.restore();
    }
  },

  {
    n: 'Windows Quotes',
    i: '🪟',
    tag: 'RETRO',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    c: 'Maker',
    d: 'Quote klasik Windows Media Player XP + figur 3D',
    f: [['t', 'Teks Quote', 'area', 'ngapain\ncemburu\nkan\ncuman\nsebatas\nteman']],
    draw(x, c, v) {
      const W = (c.width = 900), H = (c.height = 1080);
      const bgG = x.createLinearGradient(0, 0, 0, H);
      bgG.addColorStop(0, '#c7d8f0'); bgG.addColorStop(0.65, '#8bb4e8'); bgG.addColorStop(0.85, '#3b6ea5'); bgG.addColorStop(1, '#1e4273');
      x.fillStyle = bgG; x.fillRect(0, 0, W, H);

      x.save(); x.filter = 'blur(8px)'; x.fillStyle = 'rgba(255,255,255,0.6)';
      [60, 160, 260, 360].forEach(ix => x.fillRect(ix, 35, 52, 48));
      x.fillStyle = '#245edb'; x.fillRect(0, H - 55, W, 55);
      x.fillStyle = '#3c9d36'; x.fillRect(0, H - 55, 130, 55);
      x.restore();

      const wx = 20, wy = 115, ww = 860, wh = 855;
      rr(x, wx, wy, ww, wh, 14, '#0055ea', '#003399', 3);
      const tbG = x.createLinearGradient(0, wy, 0, wy + 68);
      tbG.addColorStop(0, '#3b82f6'); tbG.addColorStop(0.25, '#0058e6'); tbG.addColorStop(1, '#003399');
      rr(x, wx + 2, wy + 2, ww - 4, 66, [12, 12, 0, 0], tbG);

      x.fillStyle = '#ffffff'; x.beginPath(); x.arc(wx + 38, wy + 35, 18, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#f97316'; x.beginPath(); x.arc(wx + 35, wy + 32, 8, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#2563eb'; x.beginPath(); x.moveTo(wx + 34, wy + 27); x.lineTo(wx + 46, wy + 35); x.lineTo(wx + 34, wy + 43); x.fill();

      x.fillStyle = '#ffffff'; x.font = 'bold 28px Tahoma, Arial, sans-serif'; x.textAlign = 'left';
      x.fillText('Windows Media Player', wx + 68, wy + 45);

      [[wx + ww - 165, '#2563eb', '_'], [wx + ww - 112, '#2563eb', '□'], [wx + ww - 59, '#e11d48', '✕']].forEach(([bx, col, sym]) => {
        rr(x, bx, wy + 13, 44, 42, 6, col, '#ffffff', 1.8);
        x.fillStyle = '#ffffff'; x.font = 'bold 22px Arial'; x.textAlign = 'center'; x.fillText(sym, bx + 22, wy + 41);
      });

      x.fillStyle = '#ece9d8'; x.fillRect(wx + 5, wy + 68, ww - 10, 48);
      x.fillStyle = '#000000'; x.font = '22px Tahoma, Arial, sans-serif'; x.textAlign = 'left';
      ['File', 'View', 'Play', 'Tools', 'Help'].forEach((m, i) => {
        const mx = wx + 24 + i * 86; x.fillText(m, mx, wy + 100); x.fillRect(mx, wy + 103, 13, 1.5);
      });

      x.fillStyle = '#d4d0c8'; x.fillRect(wx + 5, wy + 116, ww - 10, 28);
      rr(x, wx + 560, wy + 118, 290, 24, 4, '#2563eb');
      x.fillStyle = '#ffffff'; x.fillRect(wx + 6, wy + 144, ww - 12, 560);

      x.fillStyle = '#111111'; x.textAlign = 'left';
      const qLines = lines(x, v.t || 'ngapain\ncemburu\nkan\ncuman\nsebatas\nteman', 380);
      let fs = 54;
      while (qLines.length * fs * 1.18 > 480 && fs > 26) fs -= 3;
      x.font = `bold ${fs}px Arial, sans-serif`;
      qLines.forEach((ln, idx) => x.fillText(ln, wx + 82, wy + 225 + idx * fs * 1.18));

      const figX = wx + 635, figY = wy + 340;
      const bodyGrad = x.createRadialGradient(figX - 18, figY - 25, 10, figX, figY, 130);
      bodyGrad.addColorStop(0, '#ffffff'); bodyGrad.addColorStop(0.65, '#e2e8f0'); bodyGrad.addColorStop(1, '#94a3b8');

      x.fillStyle = 'rgba(0,0,0,0.16)'; x.beginPath(); x.ellipse(figX, figY + 265, 95, 16, 0, 0, Math.PI * 2); x.fill();
      x.fillStyle = bodyGrad;
      rr(x, figX - 42, figY + 110, 34, 145, 17, bodyGrad);
      rr(x, figX + 8, figY + 110, 34, 145, 17, bodyGrad);
      x.beginPath(); x.ellipse(figX - 32, figY + 255, 28, 14, -0.15, 0, Math.PI * 2); x.fill();
      x.beginPath(); x.ellipse(figX + 32, figY + 255, 28, 14, 0.15, 0, Math.PI * 2); x.fill();
      rr(x, figX - 46, figY - 10, 92, 140, 42, bodyGrad);

      x.strokeStyle = '#cbd5e1'; x.lineWidth = 24; x.lineCap = 'round'; x.lineJoin = 'round';
      x.beginPath(); x.moveTo(figX - 40, figY + 12); x.lineTo(figX - 88, figY + 62); x.lineTo(figX - 135, figY + 38); x.stroke();
      x.beginPath(); x.moveTo(figX + 40, figY + 12); x.lineTo(figX + 88, figY + 62); x.lineTo(figX + 135, figY + 38); x.stroke();
      x.fillStyle = bodyGrad;
      x.beginPath(); x.ellipse(figX - 144, figY + 34, 22, 10, 0.2, 0, Math.PI * 2); x.fill();
      x.beginPath(); x.ellipse(figX + 144, figY + 34, 22, 10, -0.2, 0, Math.PI * 2); x.fill();

      const headG = x.createRadialGradient(figX - 18, figY - 82, 8, figX, figY - 68, 56);
      headG.addColorStop(0, '#ffffff'); headG.addColorStop(0.7, '#e2e8f0'); headG.addColorStop(1, '#94a3b8');
      x.fillStyle = headG; x.beginPath(); x.arc(figX, figY - 68, 54, 0, Math.PI * 2); x.fill();

      const deckY = wy + 704;
      const deckG = x.createLinearGradient(0, deckY, 0, deckY + 145);
      deckG.addColorStop(0, '#60a5fa'); deckG.addColorStop(0.25, '#2563eb'); deckG.addColorStop(1, '#1e3a8a');
      rr(x, wx + 5, deckY, ww - 10, 145, [0, 0, 10, 10], deckG);
      rr(x, wx + 150, deckY + 32, 620, 12, 6, '#1e3a8a', '#93c5fd', 1);
      rr(x, wx + 195, deckY + 21, 18, 34, 4, '#22c55e', '#ffffff', 2);

      const playC = x.createRadialGradient(wx + 66, deckY + 72, 6, wx + 72, deckY + 78, 44);
      playC.addColorStop(0, '#ffffff'); playC.addColorStop(1, '#93c5fd');
      x.fillStyle = playC; x.beginPath(); x.arc(wx + 72, deckY + 78, 42, 0, Math.PI * 2); x.fill();
      x.strokeStyle = '#1e3a8a'; x.lineWidth = 2.5; x.stroke();
      x.fillStyle = '#1e3a8a'; x.beginPath(); x.moveTo(wx + 62, deckY + 60); x.lineTo(wx + 92, deckY + 78); x.lineTo(wx + 62, deckY + 96); x.fill();

      x.fillStyle = '#dbeafe'; x.beginPath(); x.arc(wx + 142, deckY + 78, 22, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#1e3a8a'; x.fillRect(wx + 135, deckY + 71, 14, 14);
      rr(x, wx + 180, deckY + 76, 120, 32, 16, '#dbeafe', '#1e3a8a', 2);
      x.fillStyle = '#1e3a8a'; x.font = 'bold 16px Arial'; x.textAlign = 'center'; x.fillText('⏮   ⏭', wx + 240, deckY + 97);
      x.fillStyle = '#dbeafe'; x.beginPath(); x.arc(wx + 356, deckY + 92, 20, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#1e3a8a'; x.fillText('🔇', wx + 356, deckY + 98);
      x.fillStyle = '#22c55e'; x.beginPath(); x.moveTo(wx + 405, deckY + 104); x.lineTo(wx + 505, deckY + 86); x.lineTo(wx + 505, deckY + 104); x.fill();
      rr(x, wx + 495, deckY + 74, 18, 36, 4, '#22c55e', '#ffffff', 2);
    }
  },

  {
    n: 'NGL Card Maker',
    i: '💌',
    tag: 'SOCIAL',
    badge: 'bg-pink-500/20 text-pink-300 border-pink-400/40',
    c: 'Maker',
    d: 'Kartu pesan anonim NGL gradasi pink-oranye',
    f: [
      ['h', 'Judul Header NGL', 'text', 'kirim pesan anonim ke aku!'],
      ['t', 'Isi Pesan Anonim', 'area', 'sebenernya aku udah lama suka sama kamu tapi malu bilangnya 🥺']
    ],
    draw(x, c, v) {
      const W = (c.width = 720), H = (c.height = 720);
      x.fillStyle = '#090412'; x.fillRect(0, 0, W, H);
      const cardG = x.createLinearGradient(60, 110, 660, 610);
      cardG.addColorStop(0, '#ec1187'); cardG.addColorStop(1, '#ff8d10');
      rr(x, 60, 120, 600, 480, 42, cardG);
      rr(x, 60, 120, 600, 145, [42, 42, 0, 0], 'rgba(0,0,0,0.14)');
      x.fillStyle = '#ffffff'; x.font = '800 30px "Plus Jakarta Sans", sans-serif'; x.textAlign = 'center';
      lines(x, v.h || 'kirim pesan anonim ke aku!', 520).slice(0, 2).forEach((ln, i) => x.fillText(ln, 360, 185 + i * 38));

      rr(x, 60, 265, 600, 335, [0, 0, 42, 42], '#ffffff');
      x.fillStyle = '#111827'; x.font = '800 34px "Plus Jakarta Sans", sans-serif';
      const bodyL = lines(x, v.t || 'Halo!', 520);
      let sy = 435 - (bodyL.length * 44) / 2;
      bodyL.forEach((ln, i) => x.fillText(ln, 360, sy + i * 44));
    }
  },

  {
    n: 'Stiker WA Maker',
    i: '🏷️',
    tag: 'STICKER',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
    c: 'Maker',
    d: 'Ubah foto jadi stiker WA ber-border putih + teks',
    f: [
      ['p', 'Upload Foto', 'file'],
      ['s', 'Bentuk Stiker', 'sel', 'Bulat|Kotak Rounded'],
      ['t', 'Teks Stiker (Opsional)', 'text', 'MANTAP!']
    ],
    draw(x, c, v, im) {
      const S = (c.width = c.height = 512);
      x.clearRect(0, 0, S, S);
      if (!im.p) {
        rr(x, 40, 160, 432, 192, 24, '#1e1035', '#a855f7', 2);
        x.fillStyle = '#e9d5ff'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('⚠️ Upload foto untuk membuat stiker!', 256, 262);
        return;
      }
      x.save();
      if (v.s === 'Bulat') {
        x.beginPath(); x.arc(256, 256, 224, 0, Math.PI * 2); x.fillStyle = '#ffffff'; x.fill();
        circ(x, im.p, 256, 256, 210);
      } else {
        rr(x, 32, 32, 448, 448, 56, '#ffffff');
        drawCoverImage(x, im.p, 46, 46, 420, 420, 44);
      }
      x.restore();
      if (v.t) {
        x.font = '900 54px Impact, Arial, sans-serif'; x.textAlign = 'center';
        x.lineWidth = 10; x.strokeStyle = '#000000'; x.strokeText(v.t.toUpperCase(), 256, 455, 430);
        x.fillStyle = '#ffffff'; x.fillText(v.t.toUpperCase(), 256, 455, 430);
      }
    }
  },

  {
    n: 'Quote Generator',
    i: '📜',
    tag: 'CANVAS',
    badge: 'bg-purple-500/20 text-purple-300 border-purple-400/40',
    c: 'Maker',
    d: 'Gambar quote estetika gaya halaman buku',
    f: [
      ['t', 'Teks Quote', 'area', 'Hidup itu hanya satu kali jadi berusahalah menjadi orang yang baik.'],
      ['a', 'Nama Bawah', 'text', 'HANZZ']
    ],
    draw(x, c, v) {
      c.width = 736; c.height = 920;
      const g = x.createLinearGradient(0, 0, 0, 920);
      g.addColorStop(0, '#dfd5c9'); g.addColorStop(1, '#cbbdae');
      x.fillStyle = g; x.fillRect(0, 0, 736, 920);
      for (let k = 0; k < 4500; k++) {
        x.fillStyle = `rgba(90,70,50,${Math.random() * 0.06})`;
        x.fillRect(Math.random() * 736, Math.random() * 920, 2, 2);
      }
      x.fillStyle = '#1a1a1a'; x.font = '46px Georgia, serif'; x.textAlign = 'center';
      const l = lines(x, v.t, 540);
      let y = 450 - l.length * 31;
      l.forEach(s => x.fillText(s, 368, (y += 62)));
      x.font = 'italic 24px Georgia, serif';
      x.fillText('— ' + (v.a || 'HANZZ'), 368, 860);
    }
  },

  {
    n: 'Nokia Message',
    i: '📟',
    tag: 'RETRO',
    badge: 'bg-teal-500/20 text-teal-300 border-teal-400/40',
    c: 'Maker',
    d: 'Gambar SMS layar Nokia jadul',
    f: [
      ['t', 'Isi Pesan', 'area', 'kata-kata hari ini'],
      ['a', 'Pengirim', 'text', 'HANZZ']
    ],
    draw(x, c, v) {
      c.width = 543; c.height = 720;
      const [d, t] = now();
      x.fillStyle = '#d3e0ea'; x.fillRect(0, 0, 543, 720);
      x.fillStyle = '#078a80'; x.fillRect(0, 0, 543, 140);
      x.fillStyle = '#fff'; x.font = 'bold 54px monospace'; x.textAlign = 'center';
      x.fillText('Pesan', 272, 105);
      x.font = 'bold 30px monospace'; x.fillText('▮▮▮▮', 60, 35); x.fillText('🔋', 500, 35);
      x.fillStyle = '#000'; x.textAlign = 'left'; x.font = 'bold 34px monospace';
      lines(x, v.t, 470).forEach((s, k) => x.fillText(s, 28, 215 + k * 42));
      ['Dari:', v.a || 'HANZZ', d, t].forEach((s, k) => x.fillText(s, 28, 505 + k * 40));
      x.fillRect(0, 650, 543, 70);
      x.fillStyle = '#d3e0ea'; x.font = 'bold 36px monospace';
      x.fillText('Pilihan', 10, 698); x.textAlign = 'right'; x.fillText('Kembali', 533, 698);
    }
  },

  {
    n: 'Sertifikasi Tolol',
    i: '🧠',
    tag: 'PARODI',
    badge: 'bg-rose-500/20 text-rose-300 border-rose-400/40',
    c: 'Maker',
    d: 'Sertifikat parodi lucu dari nama',
    f: [['t', 'Nama Target', 'text', 'Nama Contoh']],
    draw(x, c, v) {
      c.width = 800; c.height = 450;
      x.fillStyle = '#22222e'; x.fillRect(0, 0, 800, 450);
      x.fillStyle = '#b01e3c';
      [[0, 260], [500, 450]].forEach(([a, b]) => {
        x.beginPath(); x.moveTo(a, 450); x.lineTo(a + 150, 450 - (b - 250) / 1.2); x.lineTo(a + 300, 450); x.fill();
      });
      x.fillStyle = '#000'; x.fillRect(278, 12, 244, 70);
      x.fillStyle = '#fff'; x.font = 'bold 56px Arial'; x.textAlign = 'left'; x.fillText('To', 290, 66);
      rr(x, 372, 22, 140, 52, 8, '#ff9900');
      x.fillStyle = '#000'; x.fillText('LoL', 382, 66);
      x.textAlign = 'center'; x.fillStyle = '#fff';
      x.font = 'bold 24px Impact, Arial'; x.fillText('SERTIFIKAT INI MENYATAKAN BAHWA', 400, 145);
      x.font = '40px Arial'; x.fillText(v.t, 400, 205);
      x.font = 'bold 46px Impact, Arial'; x.fillText('TERBUKTI TOLOL', 400, 290);
      x.font = 'bold 28px Impact, Arial'; x.fillText('DAN TAK BEROTAK', 400, 345);
      x.font = '75px serif'; x.fillText('🚫🧠', 95, 380); x.fillText('⭐', 700, 370);
    }
  },

  {
    n: 'Fake Tweet',
    i: '🐦',
    tag: 'SOCIAL',
    badge: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    c: 'Maker',
    d: 'Postingan X / Twitter palsu dark mode',
    f: [
      ['n', 'Nama Tampilan', 'text', 'HANZZ'],
      ['u', 'Username', 'text', 'hanzz_dev'],
      ['t', 'Isi Tweet', 'area', 'Shadow All Tools resmi rilis! 🔥'],
      ['p', 'Foto Profil', 'file']
    ],
    draw(x, c, v, im) {
      c.width = 900; c.height = 420;
      x.fillStyle = '#000000'; x.fillRect(0, 0, 900, 420);
      circ(x, im.p, 80, 80, 48);
      x.fillStyle = '#fff'; x.textAlign = 'left'; x.font = 'bold 32px Arial';
      x.fillText(v.n || 'HANZZ', 148, 72);
      const nw = x.measureText(v.n || 'HANZZ').width;
      x.fillStyle = '#1d9bf0'; x.beginPath(); x.arc(166 + nw, 62, 13, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#fff'; x.font = 'bold 16px Arial'; x.textAlign = 'center'; x.fillText('✓', 166 + nw, 68);
      x.textAlign = 'left'; x.fillStyle = '#71767b'; x.font = '25px Arial';
      x.fillText('@' + (v.u || 'hanzz_dev'), 148, 108);
      x.fillStyle = '#fff'; x.font = '34px Arial';
      lines(x, v.t, 820).forEach((s, k) => x.fillText(s, 40, 185 + k * 46));
      const [d, t] = now();
      x.fillStyle = '#71767b'; x.font = '23px Arial';
      x.fillText(t + ' · ' + d + ' · X for iPhone', 40, 380);
    }
  },

  {
    n: 'Meme Maker',
    i: '😂',
    tag: 'MEME',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
    c: 'Maker',
    d: 'Tambah teks meme klasik atas & bawah',
    f: [
      ['p', 'Upload Gambar', 'file'],
      ['a', 'Teks Atas', 'text', 'KETIKA'],
      ['b', 'Teks Bawah', 'text', 'CODING JAM 3 PAGI']
    ],
    draw(x, c, v, im) {
      if (!im.p) {
        c.width = 480; c.height = 240;
        x.fillStyle = '#1e1035'; x.fillRect(0, 0, 480, 240);
        x.fillStyle = '#e9d5ff'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('⚠️ Silakan upload gambar terlebih dahulu!', 240, 125);
        return;
      }
      const s = Math.min(1, 800 / im.p.width);
      const w = (c.width = im.p.width * s), h = (c.height = im.p.height * s);
      x.drawImage(im.p, 0, 0, w, h);
      x.font = 'bold ' + Math.round(w / 10) + 'px Impact, Arial';
      x.textAlign = 'center'; x.fillStyle = '#fff'; x.strokeStyle = '#000'; x.lineWidth = w / 75;
      [[v.a, w / 9], [v.b, h - w / 25]].forEach(([t, y]) => {
        x.strokeText((t || '').toUpperCase(), w / 2, y, w - 24);
        x.fillText((t || '').toUpperCase(), w / 2, y, w - 24);
      });
    }
  },

  // ======================== DOWNLOADER (SOSMED & APK) ========================
  {
    n: 'YT Downloader',
    i: '▶️',
    tag: 'MP4 / MP3',
    badge: 'bg-red-500/20 text-red-300 border-red-400/40',
    c: 'Downloader',
    d: 'Download video & musik YouTube HD + thumbnail',
    f: [
      ['u', 'Link Video / Shorts YouTube', 'text', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'],
      ['q', 'Format Unduhan', 'sel', 'MP4 Video HD (1080p/720p)|MP3 Audio (320kbps)']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      const vid = getYTId(url);
      if (!vid) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link YouTube yang valid (contoh: youtube.com/watch?v=... atau youtu.be/...)</div>`;
        return;
      }
      const thumb = `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`;
      let title = `YouTube Video (${vid})`;
      let author = 'YouTube Creator';
      try {
        const metaRes = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${vid}`);
        if (metaRes.ok) {
          const meta = await metaRes.json();
          if (meta.title) title = meta.title;
          if (meta.author_name) author = meta.author_name;
        }
      } catch {}

      const isAudio = (v.q || '').includes('MP3');
      const cobalt = await queryCobalt(url, isAudio);
      const encUrl = encodeURIComponent(url);

      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-red-500/30">
          <div class="flex gap-3 items-center">
            <img src="${thumb}" class="w-28 h-20 object-cover rounded-xl border border-white/15 shrink-0" alt="Thumbnail">
            <div class="min-w-0">
              <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-red-500/20 text-red-300">YOUTUBE READY</span>
              <h4 class="font-bold text-sm text-white line-clamp-2 mt-1">${title}</h4>
              <p class="text-xs text-purple-300 mt-0.5">Channel: ${author}</p>
            </div>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            ${cobalt && cobalt.url ? `<a href="${cobalt.url}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Langsung (${isAudio ? 'MP3' : 'MP4'})</a>` : ''}
            <a href="https://ssyoutube.com/watch?v=${vid}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download MP4 HD (Server 1)</a>
            <a href="https://y2mate.nu/en-yt/?url=${encUrl}" target="_blank" rel="noopener" class="btn-sec text-xs">🎵 Download MP3 Audio (Server 2)</a>
            <a href="${thumb}" download="yt_thumb_${vid}.jpg" target="_blank" class="btn-sec text-xs">🖼️ Download Thumbnail HD</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'TikTok Downloader',
    i: '🎵',
    tag: 'NO WM',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
    c: 'Downloader',
    d: 'Download video TikTok tanpa watermark + MP3',
    f: [
      ['u', 'Link Video / Foto TikTok', 'text', 'https://vt.tiktok.com/']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      if (!url || !url.includes('tiktok.com')) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link TikTok yang valid!</div>`;
        return;
      }
      try {
        const res = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`);
        const json = await res.json();
        if (json && json.code === 0 && json.data) {
          const d = json.data;
          const videoUrl = d.hdplay || d.play;
          const musicUrl = d.music;
          o.innerHTML = `
            <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-cyan-500/35">
              <div class="flex gap-3 items-center">
                <img src="${d.cover}" class="w-20 h-28 object-cover rounded-xl border border-white/15 shrink-0" alt="Cover">
                <div class="min-w-0">
                  <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300">NO WATERMARK HD</span>
                  <h4 class="font-bold text-sm text-white line-clamp-2 mt-1">${d.title || 'TikTok Video'}</h4>
                  <p class="text-xs text-cyan-300 mt-1">@${d.author?.unique_id || 'creator'} • ❤️ ${d.digg_count || 0}</p>
                </div>
              </div>
              <video src="${videoUrl}" controls playsinline class="w-full max-h-64 rounded-xl bg-black"></video>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <a href="${videoUrl}" download="tiktok_nowm_HANZZ.mp4" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download MP4 (No Watermark)</a>
                ${musicUrl ? `<a href="${musicUrl}" download="tiktok_audio_HANZZ.mp3" target="_blank" rel="noopener" class="btn-sec text-xs">🎵 Download Audio MP3</a>` : ''}
              </div>
            </div>
          `;
          return;
        }
      } catch {}

      const enc = encodeURIComponent(url);
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3">
          <p class="text-xs text-purple-200">Link TikTok siap diunduh melalui server mirror cepat tanpa watermark:</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <a href="https://tikwm.com/video/media/hdplay/${enc}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Server 1 (HD No WM)</a>
            <a href="https://snaptik.app/abc?url=${enc}" target="_blank" rel="noopener" class="btn-sec text-xs">⬇ Server 2 (SnapTik)</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'IG Downloader',
    i: '📸',
    tag: 'REELS / POST',
    badge: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-400/40',
    c: 'Downloader',
    d: 'Download Instagram Reels, Video, Foto & Story',
    f: [
      ['u', 'Link Instagram (Reels / Post / Story)', 'text', 'https://www.instagram.com/reel/']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      if (!url || !url.includes('instagram.com')) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link Instagram yang valid!</div>`;
        return;
      }
      const cobalt = await queryCobalt(url, false);
      const enc = encodeURIComponent(url);
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-fuchsia-500/35">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-0.5 text-[10px] font-bold rounded bg-fuchsia-500/20 text-fuchsia-300">INSTAGRAM EXTRACTOR</span>
            <span class="text-[11px] text-purple-300">HD Quality</span>
          </div>
          <p class="text-xs text-purple-200 break-all bg-black/30 p-2.5 rounded-xl">${url}</p>
          ${cobalt && cobalt.url ? `<video src="${cobalt.url}" controls playsinline class="w-full max-h-64 rounded-xl bg-black"></video>` : ''}
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            ${cobalt && cobalt.url ? `<a href="${cobalt.url}" download="instagram_HANZZ.mp4" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Langsung HD</a>` : ''}
            <a href="https://snapinst.app/?url=${enc}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Reels/Post (Server 1)</a>
            <a href="https://fastdl.app/en?url=${enc}" target="_blank" rel="noopener" class="btn-sec text-xs">⬇ Download Foto/Story (Server 2)</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'FB & X Downloader',
    i: '🌐',
    tag: 'VIDEO HD',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-400/40',
    c: 'Downloader',
    d: 'Download video Facebook & X / Twitter HD',
    f: [
      ['p', 'Platform', 'sel', 'Facebook|X / Twitter'],
      ['u', 'Link Video', 'text', 'https://']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      if (!url.startsWith('http')) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link video yang valid!</div>`;
        return;
      }
      const cobalt = await queryCobalt(url, false);
      const enc = encodeURIComponent(url);
      const s1 = v.p === 'Facebook' ? `https://fdown.net/download.php?URLz=${enc}` : `https://twitsave.com/info?url=${enc}`;
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-blue-500/35">
          <span class="px-2.5 py-0.5 text-[10px] font-bold rounded bg-blue-500/20 text-blue-300">${v.p.toUpperCase()} VIDEO READY</span>
          <p class="text-xs text-purple-200 break-all">${url}</p>
          ${cobalt && cobalt.url ? `<video src="${cobalt.url}" controls playsinline class="w-full max-h-64 rounded-xl bg-black"></video>` : ''}
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            ${cobalt && cobalt.url ? `<a href="${cobalt.url}" download="video_HANZZ.mp4" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Langsung MP4</a>` : ''}
            <a href="${s1}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Video HD (Server 1)</a>
            <a href="https://savefrom.net/#url=${enc}" target="_blank" rel="noopener" class="btn-sec text-xs">⬇ Download Mirror (Server 2)</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'Spotify & SoundCloud',
    i: '🎧',
    tag: 'AUDIO MP3',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
    c: 'Downloader',
    d: 'Download lagu Spotify & SoundCloud ke MP3',
    f: [
      ['u', 'Link Lagu Spotify / SoundCloud', 'text', 'https://open.spotify.com/track/']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      if (!url.startsWith('http')) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link lagu Spotify atau SoundCloud!</div>`;
        return;
      }
      let title = 'Track Audio', thumb = '';
      try {
        const res = await fetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`);
        if (res.ok) {
          const d = await res.json();
          title = d.title || title;
          thumb = d.thumbnail_url || '';
        }
      } catch {}
      const cobalt = await queryCobalt(url, true);
      const enc = encodeURIComponent(url);
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-emerald-500/35">
          <div class="flex gap-3 items-center">
            ${thumb ? `<img src="${thumb}" class="w-16 h-16 rounded-xl object-cover border border-white/15" alt="Cover">` : `<div class="w-16 h-16 rounded-xl bg-emerald-900/50 flex items-center justify-center text-2xl">🎵</div>`}
            <div class="min-w-0">
              <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300">320KBPS MP3 READY</span>
              <h4 class="font-bold text-sm text-white truncate mt-1">${title}</h4>
              <p class="text-[11px] text-purple-300 truncate">${url}</p>
            </div>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            ${cobalt && cobalt.url ? `<a href="${cobalt.url}" download="music_HANZZ.mp3" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download MP3 Langsung</a>` : ''}
            <a href="https://spotidownloader.com/?url=${enc}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Spotify MP3 (Server 1)</a>
            <a href="https://sclouddownloader.net/?url=${enc}" target="_blank" rel="noopener" class="btn-sec text-xs">⬇ Download SoundCloud (Server 2)</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'Pinterest & CapCut',
    i: '📌',
    tag: 'MEDIA',
    badge: 'bg-rose-500/20 text-rose-300 border-rose-400/40',
    c: 'Downloader',
    d: 'Download video/foto Pinterest & template CapCut',
    f: [
      ['p', 'Sumber', 'sel', 'Pinterest (Gambar / Video)|CapCut Template (No WM)'],
      ['u', 'Link Pinterest / CapCut', 'text', 'https://']
    ],
    async run(o, v) {
      const url = (v.u || '').trim();
      if (!url.startsWith('http')) {
        o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-rose-300 text-sm">⚠️ Masukkan link Pinterest atau CapCut yang valid!</div>`;
        return;
      }
      const cobalt = await queryCobalt(url, false);
      const enc = encodeURIComponent(url);
      const s1 = v.p.includes('Pinterest') ? `https://pinterestdownloader.com/?url=${enc}` : `https://ssscap.net/?url=${enc}`;
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-rose-500/35">
          <span class="px-2.5 py-0.5 text-[10px] font-bold rounded bg-rose-500/20 text-rose-300">${v.p.toUpperCase()}</span>
          <p class="text-xs text-purple-200 break-all">${url}</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            ${cobalt && cobalt.url ? `<a href="${cobalt.url}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download Media Langsung</a>` : ''}
            <a href="${s1}" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Download HD (Server 1)</a>
            <a href="https://savepin.app/download.php?url=${enc}" target="_blank" rel="noopener" class="btn-sec text-xs">⬇ Download Alternatif (Server 2)</a>
          </div>
        </div>
      `;
    }
  },

  {
    n: 'APK & App Downloader',
    i: '📦',
    tag: 'APK / XAPK',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
    c: 'Downloader',
    d: 'Download APK Android (WhatsApp, FF, ML, CapCut, dll)',
    f: [
      ['q', 'Pilih Aplikasi Populer / Ketik Nama APK', 'sel', 'Custom (Ketik Manual)|WhatsApp Messenger|Free Fire MAX|Mobile Legends: Bang Bang|CapCut Video Editor|Alight Motion|ZArchiver Pro|TikTok|Instagram|Spotify Music|YouTube|Minecraft PE|Roblox|PUBG Mobile|Telegram'],
      ['m', 'Nama APK / Package ID (jika Custom)', 'text', 'com.whatsapp']
    ],
    run(o, v) {
      const db = {
        'WhatsApp Messenger': { pkg: 'com.whatsapp', ver: '2.26.21.78', size: '68.4 MB', cat: 'Komunikasi', ico: '💬' },
        'Free Fire MAX': { pkg: 'com.dts.freefiremax', ver: '2.108.1', size: '640 MB', cat: 'Action / Battle Royale', ico: '🔥' },
        'Mobile Legends: Bang Bang': { pkg: 'com.mobile.legends', ver: '1.9.32', size: '142 MB (Base)', cat: 'MOBA', ico: '⚔️' },
        'CapCut Video Editor': { pkg: 'com.lemon.lvoverseas', ver: '13.4.0', size: '185 MB', cat: 'Video Editor', ico: '🎬' },
        'Alight Motion': { pkg: 'com.alightcreative.motion', ver: '5.0.270', size: '148 MB', cat: 'Motion Graphics', ico: '✨' },
        'ZArchiver Pro': { pkg: 'ru.zdevs.zarchiver', ver: '1.0.10', size: '6.2 MB', cat: 'Alat Arsip', ico: '🗜️' },
        'TikTok': { pkg: 'com.zhiliaoapp.musically', ver: '37.5.4', size: '164 MB', cat: 'Hiburan', ico: '🎵' },
        'Instagram': { pkg: 'com.instagram.android', ver: '358.0.0', size: '82 MB', cat: 'Sosial', ico: '📸' },
        'Spotify Music': { pkg: 'com.spotify.music', ver: '8.9.96', size: '44 MB', cat: 'Musik', ico: '🎧' },
        'YouTube': { pkg: 'com.google.android.youtube', ver: '19.45.38', size: '136 MB', cat: 'Video', ico: '▶️' },
        'Minecraft PE': { pkg: 'com.mojang.minecraftpe', ver: '1.21.50', size: '215 MB', cat: 'Sandbox', ico: '⛏️' },
        'Roblox': { pkg: 'com.roblox.client', ver: '2.651.840', size: '158 MB', cat: 'Petualangan', ico: '🧱' },
        'PUBG Mobile': { pkg: 'com.tencent.ig', ver: '3.5.0', size: '980 MB', cat: 'Battle Royale', ico: '🪂' },
        'Telegram': { pkg: 'org.telegram.messenger', ver: '11.4.2', size: '54 MB', cat: 'Komunikasi', ico: '✈️' }
      };

      const isCustom = (v.q || '').startsWith('Custom');
      const appName = isCustom ? (v.m || 'Android App') : v.q;
      const info = db[appName] || {
        pkg: (v.m || appName).toLowerCase().replace(/\s+/g, '.'),
        ver: 'Latest Release',
        size: 'Auto Detect',
        cat: 'Android APK',
        ico: '🤖'
      };
      const slug = appName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      const qEnc = encodeURIComponent(appName);

      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl text-left space-y-3 border border-emerald-500/35">
          <div class="flex items-center gap-3">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/30 to-cyan-500/30 border border-emerald-400/40 flex items-center justify-center text-3xl shrink-0">
              ${info.ico}
            </div>
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-1.5">
                <h4 class="font-extrabold text-base text-white truncate">${appName}</h4>
                <span class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300">VERIFIED APK</span>
              </div>
              <p class="text-xs font-mono text-cyan-300 truncate">${info.pkg}</p>
              <p class="text-[11px] text-purple-300 mt-0.5">Versi: <b>${info.ver}</b> • Ukuran: <b>${info.size}</b> • ${info.cat}</p>
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <a href="https://d.apkpure.com/b/APK/${info.pkg}?version=latest" target="_blank" rel="noopener" class="btn-neon text-xs">⬇ Direct Download APK (Fast)</a>
            <a href="https://apkpure.com/search?q=${qEnc}" target="_blank" rel="noopener" class="btn-sec text-xs">📦 Download via APKPure</a>
            <a href="https://www.apkmirror.com/?post_type=app_release&searchtype=apk&s=${qEnc}" target="_blank" rel="noopener" class="btn-sec text-xs">🛡️ Download via APKMirror</a>
            <a href="https://en.uptodown.com/android/search/${slug}" target="_blank" rel="noopener" class="btn-sec text-xs">🚀 Download via Uptodown</a>
          </div>
        </div>
      `;
    }
  },

  // ======================== UTILITAS & AI / DEV ========================
  {
    n: 'Remove BG',
    i: '✂️',
    tag: 'AI TOOL',
    badge: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-400/40',
    c: 'Utilitas',
    d: 'Hapus background foto polos otomatis',
    f: [
      ['p', 'Upload Gambar', 'file'],
      ['k', 'Toleransi Warna (10-150)', 'num', '60']
    ],
    draw(x, c, v, im) {
      if (!im.p) {
        c.width = 480; c.height = 240;
        x.fillStyle = '#1e1035'; x.fillRect(0, 0, 480, 240);
        x.fillStyle = '#e9d5ff'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('⚠️ Silakan upload gambar terlebih dahulu!', 240, 125);
        return;
      }
      const s = Math.min(1, 900 / im.p.width, 900 / im.p.height);
      const w = (c.width = Math.round(im.p.width * s)), h = (c.height = Math.round(im.p.height * s));
      x.drawImage(im.p, 0, 0, w, h);
      const d = x.getImageData(0, 0, w, h), D = d.data;
      let R = 0, Gc = 0, B = 0;
      [0, w - 1, (h - 1) * w, h * w - 1].forEach(p => {
        R += D[p * 4] / 4; Gc += D[p * 4 + 1] / 4; B += D[p * 4 + 2] / 4;
      });
      const tol = (+v.k || 60) ** 2, seen = new Uint8Array(w * h), st = [];
      for (let i = 0; i < w; i++) st.push(i, (h - 1) * w + i);
      for (let j = 0; j < h; j++) st.push(j * w, j * w + w - 1);
      while (st.length) {
        const p = st.pop();
        if (seen[p]) continue;
        seen[p] = 1;
        const i = p * 4;
        if ((D[i] - R) ** 2 + (D[i + 1] - Gc) ** 2 + (D[i + 2] - B) ** 2 > tol) continue;
        D[i + 3] = 0;
        const px = p % w;
        if (px > 0) st.push(p - 1);
        if (px < w - 1) st.push(p + 1);
        if (p >= w) st.push(p - w);
        if (p < w * (h - 1)) st.push(p + w);
      }
      x.putImageData(d, 0, 0);
    }
  },

  {
    n: 'Image Enhancer',
    i: '✨',
    tag: 'HD BOOST',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
    c: 'Utilitas',
    d: 'Pertajam detail gambar (Sharpen HD)',
    f: [['p', 'Upload Gambar', 'file']],
    draw(x, c, v, im) {
      if (!im.p) {
        c.width = 480; c.height = 240;
        x.fillStyle = '#1e1035'; x.fillRect(0, 0, 480, 240);
        x.fillStyle = '#e9d5ff'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center';
        x.fillText('⚠️ Silakan upload gambar terlebih dahulu!', 240, 125);
        return;
      }
      const s = Math.min(1, 1400 / im.p.width);
      c.width = Math.round(im.p.width * s); c.height = Math.round(im.p.height * s);
      x.drawImage(im.p, 0, 0, c.width, c.height);
      const d = x.getImageData(0, 0, c.width, c.height), o = new Uint8ClampedArray(d.data), w = c.width;
      const K = [0, -1, 0, -1, 5, -1, 0, -1, 0];
      for (let y = 1; y < c.height - 1; y++) {
        for (let a = 1; a < w - 1; a++) {
          for (let ch = 0; ch < 3; ch++) {
            let r = 0;
            for (let j = 0; j < 9; j++) r += K[j] * o[((y + ((j / 3) | 0) - 1) * w + a + (j % 3) - 1) * 4 + ch];
            d.data[(y * w + a) * 4 + ch] = r;
          }
        }
      }
      x.putImageData(d, 0, 0);
    }
  },

  {
    n: 'Image Compressor',
    i: '🗜️',
    tag: 'OPTIMIZER',
    badge: 'bg-orange-500/20 text-orange-300 border-orange-400/40',
    c: 'Utilitas',
    d: 'Kompres & ubah format gambar (JPG/WEBP/PNG)',
    f: [
      ['p', 'Upload Gambar', 'file'],
      ['fmt', 'Format Output', 'sel', 'image/jpeg|image/webp|image/png'],
      ['q', 'Kualitas (10-100)', 'num', '75'],
      ['w', 'Lebar Maksimal (px)', 'num', '1280']
    ],
    run(o, v, im) {
      if (!im.p) {
        o.innerHTML = '<p class="text-rose-300 text-sm">⚠️ Pilih gambar terlebih dahulu!</p>';
        return;
      }
      const s = Math.min(1, (+v.w || 1280) / im.p.width);
      const cv = document.createElement('canvas');
      cv.width = Math.round(im.p.width * s);
      cv.height = Math.round(im.p.height * s);
      cv.getContext('2d').drawImage(im.p, 0, 0, cv.width, cv.height);
      const ext = (v.fmt || 'image/jpeg').split('/')[1];
      cv.toBlob(b => {
        const u = URL.createObjectURL(b);
        o.innerHTML = `
          <div class="glass-panel p-4 rounded-2xl">
            <p class="text-sm text-purple-200 mb-3">Ukuran hasil: <b class="text-emerald-300 text-base">${(b.size / 1024).toFixed(1)} KB</b> (${cv.width}×${cv.height}px • ${ext.toUpperCase()})</p>
            <a class="btn-neon inline-block w-full" download="compressed_HANZZ.${ext}" href="${u}">⬇ Download ${ext.toUpperCase()}</a>
          </div>`;
      }, v.fmt || 'image/jpeg', (+v.q || 75) / 100);
    }
  },

  {
    n: 'QR Generator',
    i: '▦',
    tag: 'INSTANT',
    badge: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    c: 'Utilitas',
    d: 'Buat kode QR dari link atau teks + download',
    f: [['t', 'Teks / URL', 'text', 'https://hanzz-tools.id']],
    run(o, v) {
      o.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'inline-block bg-white p-3.5 rounded-2xl shadow-lg';
      o.appendChild(box);
      if (v.t && window.QRCode) {
        new QRCode(box, { text: v.t, width: 220, height: 220, colorDark: '#090412', colorLight: '#ffffff' });
        setTimeout(() => {
          const qrCanvas = box.querySelector('canvas');
          if (qrCanvas) {
            const btn = document.createElement('button');
            btn.className = 'btn-neon w-full mt-3';
            btn.textContent = '⬇ Download QR PNG';
            btn.onclick = () => {
              const a = document.createElement('a');
              a.download = 'QR_HANZZ.png';
              a.href = qrCanvas.toDataURL('image/png');
              a.click();
            };
            o.appendChild(btn);
          }
        }, 80);
      }
    }
  },

  {
    n: 'Text to Speech',
    i: '🗣️',
    tag: 'VOICE AI',
    badge: 'bg-sky-500/20 text-sky-300 border-sky-400/40',
    c: 'Utilitas',
    d: 'Ubah teks menjadi suara otomatis (ID / EN)',
    f: [
      ['t', 'Teks yang Dibacakan', 'area', 'Halo semuanya, selamat datang di Shadow All Tools karya HANZZ!'],
      ['l', 'Bahasa Suara', 'sel', 'id-ID|en-US|ja-JP'],
      ['r', 'Kecepatan Bicara (0.5 - 1.5)', 'num', '1']
    ],
    run(o, v) {
      if (!('speechSynthesis' in window)) {
        o.innerHTML = '<p class="text-rose-300 text-sm">Browser tidak mendukung Text-to-Speech.</p>';
        return;
      }
      const speak = () => {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(v.t || 'Halo');
        u.lang = v.l || 'id-ID';
        u.rate = Math.min(2, Math.max(0.5, parseFloat(v.r) || 1));
        window.speechSynthesis.speak(u);
      };
      speak();
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl space-y-3">
          <p class="text-sm text-purple-200">🔊 Sedang membacakan teks (${v.l})...</p>
          <div class="flex gap-2 justify-center">
            <button id="tts-play" class="btn-neon text-xs">▶ Putar Ulang</button>
            <button id="tts-stop" class="btn-sec text-xs">⏹ Berhenti</button>
          </div>
        </div>
      `;
      $('#tts-play').onclick = speak;
      $('#tts-stop').onclick = () => window.speechSynthesis.cancel();
    }
  },

  {
    n: 'Nickname Game Gen',
    i: '⚔️',
    tag: 'FF / ML',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
    c: 'Utilitas',
    d: 'Generator nickname FF & ML keren bersimbol',
    f: [['n', 'Nama Dasar', 'text', 'HANZZ']],
    run(o, v) {
      const base = (v.n || 'HANZZ').trim();
      const styles = [
        `꧁༒☬${base}☬༒꧂`,
        `『ˢʰᵈ』• ${base} 乡`,
        `么 ${base} ツ`,
        `⚡${base}⚡`,
        `★彡[${base}]彡★`,
        `꧁H҉A҉N҉Z҉Z꧂`.replace('HANZZ', base),
        `亗『${base}』亗`,
        `BTR • ${base} ☂`
      ];
      o.innerHTML = `<div class="space-y-2 text-left">${styles
        .map(
          st => `
        <div class="glass-panel px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-2">
          <span class="font-bold text-sm text-white select-all">${st}</span>
          <button class="btn-sec !py-1 !px-3 text-xs copy-nick" data-txt="${st}">Salin</button>
        </div>`
        )
        .join('')}</div>`;
      o.querySelectorAll('.copy-nick').forEach(b => (b.onclick = () => copyText(b.dataset.txt, b)));
    }
  },

  {
    n: 'Password Gen',
    i: '🔐',
    tag: 'SECURE',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
    c: 'Utilitas',
    d: 'Generator password acak super kuat',
    f: [['l', 'Panjang Karakter (8-64)', 'num', '16']],
    run(o, v) {
      const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*';
      const n = Math.min(64, Math.max(8, +v.l || 16));
      const arr = crypto.getRandomValues(new Uint32Array(n));
      const pass = [...arr].map(k => chars[k % chars.length]).join('');
      o.innerHTML = `
        <div class="glass-panel p-4 rounded-2xl space-y-3">
          <code class="block break-all text-lg font-mono text-cyan-300 select-all">${pass}</code>
          <button id="cp-pw" class="btn-neon w-full text-xs">📋 Salin Password</button>
        </div>`;
      $('#cp-pw').onclick = function () { copyText(pass, this); };
    }
  },

  {
    n: 'Morse Code',
    i: '📡',
    tag: 'AUDIO',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
    c: 'Utilitas',
    d: 'Konversi teks ke sandi Morse + suara beep',
    f: [['t', 'Teks', 'text', 'HANZZ']],
    run(o, v) {
      const M = { a: '.-', b: '-...', c: '-.-.', d: '-..', e: '.', f: '..-.', g: '--.', h: '....', i: '..', j: '.---', k: '-.-', l: '.-..', m: '--', n: '-.', o: '---', p: '.--.', q: '--.-', r: '.-.', s: '...', t: '-', u: '..-', v: '...-', w: '.--', x: '-..-', y: '-.--', z: '--..', 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' };
      const r = [...(v.t || '').toLowerCase()].map(k => (k === ' ' ? '/' : M[k] || '')).join(' ');
      o.innerHTML = `<div class="glass-panel p-4 rounded-2xl space-y-3"><div class="text-xl font-mono text-purple-200 break-all">${r}</div><button class="btn-neon w-full text-xs" id="mp">🔊 Putar Audio Morse</button></div>`;
      $('#mp').onclick = () => {
        const A = new (window.AudioContext || window.webkitAudioContext)();
        let t = A.currentTime;
        for (const k of r) {
          if (k === '.' || k === '-') {
            const q = A.createOscillator();
            q.frequency.value = 640; q.connect(A.destination); q.start(t);
            t += k === '.' ? 0.09 : 0.27; q.stop(t); t += 0.09;
          } else t += k === '/' ? 0.35 : 0.18;
        }
      };
    }
  },

  {
    n: 'Base64 & Hash Tool',
    i: '🧬',
    tag: 'DEV TOOL',
    badge: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
    c: 'Utilitas',
    d: 'Encode / Decode Base64 & SHA-256 Hash',
    f: [
      ['m', 'Mode', 'sel', 'Base64 Encode|Base64 Decode|SHA-256 Hash'],
      ['t', 'Input Teks', 'area', 'Shadow All Tools by HANZZ']
    ],
    async run(o, v) {
      let out = '';
      try {
        if (v.m === 'Base64 Encode') {
          out = btoa(unescape(encodeURIComponent(v.t || '')));
        } else if (v.m === 'Base64 Decode') {
          out = decodeURIComponent(escape(atob((v.t || '').trim())));
        } else {
          const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(v.t || ''));
          out = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
        }
      } catch {
        out = 'Error: Format input tidak valid untuk dekode.';
      }
      o.innerHTML = `
        <div class="space-y-2">
          <textarea readonly class="inp font-mono text-xs" rows="4">${out}</textarea>
          <button id="cp-b64" class="btn-neon w-full text-xs">📋 Salin Hasil</button>
        </div>`;
      $('#cp-b64').onclick = function () { copyText(out, this); };
    }
  },

  {
    n: 'Calculator',
    i: '🧮',
    tag: 'MATH',
    badge: 'bg-violet-500/20 text-violet-300 border-violet-400/40',
    c: 'Utilitas',
    d: 'Kalkulator ekspresi matematika cepat',
    f: [['e', 'Ekspresi Matematika', 'text', '128 * (4 + 4)']],
    run(o, v) {
      let r = '—';
      if (/^[0-9+\-*/().%\s]+$/.test(v.e || '')) {
        try { r = Function('return ' + v.e)(); } catch { r = 'Error'; }
      }
      o.innerHTML = `<div class="glass-panel p-4 rounded-2xl text-3xl font-extrabold text-cyan-300">${r}</div>`;
    }
  },

  {
    n: 'Web Encryption',
    i: '🛡️',
    tag: 'SECURITY',
    badge: 'bg-pink-500/20 text-pink-300 border-pink-400/40',
    c: 'Utilitas',
    d: 'Enkripsi (obfuscate) kode sumber HTML',
    f: [['h', 'Kode HTML', 'area', '<h1>Halo dari HANZZ</h1>']],
    run(o, v) {
      const encoded = btoa(unescape(encodeURIComponent(v.h || '')));
      const r = `<script>document.write(decodeURIComponent(escape(atob("${encoded}"))))<\/script>`;
      o.innerHTML = `
        <div class="space-y-2">
          <textarea readonly class="inp font-mono text-xs" rows="5">${r}</textarea>
          <button id="cp-enc" class="btn-neon w-full text-xs">📋 Salin Kode Terenkripsi</button>
        </div>`;
      $('#cp-enc').onclick = function () { copyText(r, this); };
    }
  }
];

// Update tool count badge
$('#t-count').textContent = `${T.length} Tools`;

// ===== RENDER CATEGORIES & GRID =====
let activeCat = 'All';
const cats = ['All', 'Maker', 'Downloader', 'Utilitas'];
$('#tabs').innerHTML = cats
  .map(k => `<button class="tab-btn glass-panel rounded-full px-4 py-1.5 text-xs sm:text-sm ${k === 'All' ? 'on' : 'text-purple-200'}" data-c="${k}">${k}</button>`)
  .join('');

$('#tabs').onclick = e => {
  const btn = e.target.closest('[data-c]');
  if (!btn) return;
  activeCat = btn.dataset.c;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('on', b.dataset.c === activeCat));
  renderGrid();
};

$('#q').oninput = renderGrid;

function renderGrid() {
  const q = $('#q').value.toLowerCase().trim();
  const grid = $('#grid');
  grid.innerHTML = '';

  T.forEach(tool => {
    if (activeCat !== 'All' && tool.c !== activeCat) return;
    if (q && !(tool.n + ' ' + tool.d + ' ' + tool.tag + ' ' + tool.c).toLowerCase().includes(q)) return;

    const card = document.createElement('div');
    card.className = 'tool-card rounded-2xl p-3.5 flex flex-col justify-between';
    card.innerHTML = `
      <div>
        <div class="flex items-center justify-between gap-1">
          <span class="text-2xl sm:text-3xl drop-shadow">${tool.i}</span>
          <span class="px-2 py-0.5 text-[10px] font-bold rounded-full border ${tool.badge}">${tool.tag}</span>
        </div>
        <h3 class="font-bold text-sm sm:text-base text-white mt-2.5 leading-snug">${tool.n}</h3>
        <p class="text-[11px] sm:text-xs text-purple-200/75 mt-1 leading-relaxed">${tool.d}</p>
      </div>
      <div class="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-purple-300 font-semibold">
        <span>Buka Tool</span>
        <span>→</span>
      </div>
    `;
    card.onclick = () => openTool(tool);
    grid.appendChild(card);
  });
}

// ===== MODAL WORKFLOW: INPUT -> KLIK GENERATE -> LOADING UI -> HASIL & DOWNLOAD =====
function openTool(t) {
  modal.classList.remove('hidden');
  $('#mt').textContent = `${t.i} ${t.n}`;
  $('#md').textContent = t.d;
  const F = $('#mf');
  const O = $('#mo');
  F.innerHTML = '';
  O.innerHTML = '';

  const values = {};
  const images = {};

  const executeGenerate = () => {
    // Tampilkan UI Loading / Tunggu yang keren saat tombol Generate ditekan
    O.innerHTML = `
      <div class="glass-panel p-5 rounded-2xl border border-purple-400/40 space-y-3">
        <div class="spinner"></div>
        <div class="text-sm font-bold text-white">⏳ Sedang Memproses ${t.n}...</div>
        <p class="text-xs text-purple-300">Mohon tunggu sebentar, menyiapkan hasil terbaik untukmu</p>
        <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden border border-purple-500/30">
          <div class="prog-bar"></div>
        </div>
      </div>
    `;

    setTimeout(async () => {
      O.innerHTML = '';
      if (t.draw) {
        const cv = document.createElement('canvas');
        const ctx = cv.getContext('2d');
        t.draw(ctx, cv, values, images);
        O.appendChild(cv);

        const dlBtn = document.createElement('button');
        dlBtn.className = 'btn-neon mt-3.5 w-full flex items-center justify-center gap-2';
        dlBtn.innerHTML = '<span>⬇</span> <span>Download Hasil PNG</span>';
        dlBtn.onclick = () => {
          const a = document.createElement('a');
          a.download = `${t.n.replace(/[^a-z0-9]/gi, '_')}_HANZZ.png`;
          a.href = cv.toDataURL('image/png');
          a.click();
        };
        O.appendChild(dlBtn);
      } else if (t.run) {
        await t.run(O, values, images);
      }
    }, 950);
  };

  t.f.forEach(([id, label, type, defVal]) => {
    const wrap = document.createElement('div');
    wrap.innerHTML = `<label class="block text-xs font-semibold text-purple-200 mb-1">${label}</label>`;

    if (type === 'file') {
      const drop = document.createElement('label');
      drop.className = 'file-drop';
      drop.innerHTML = `
        <img id="prev-${id}" class="w-11 h-11 rounded-lg object-cover bg-purple-950 border border-purple-500/40 hidden" alt="Preview">
        <div id="ico-${id}" class="w-11 h-11 rounded-lg bg-purple-900/50 border border-purple-500/40 flex items-center justify-center text-lg">🖼️</div>
        <div class="flex-1 min-w-0">
          <div id="fn-${id}" class="text-xs font-bold text-white truncate">Pilih Gambar dari Galeri / File</div>
          <div id="st-${id}" class="text-[11px] text-purple-300">Mendukung JPG, PNG, WEBP</div>
        </div>
        <span class="px-2.5 py-1 rounded-lg bg-purple-600/40 text-xs font-semibold text-purple-100">Browse</span>
      `;
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.className = 'hidden';

      input.addEventListener('change', ev => {
        const file = ev.target.files && ev.target.files[0];
        if (!file) return;
        const stEl = drop.querySelector(`#st-${id}`);
        const fnEl = drop.querySelector(`#fn-${id}`);
        const prevEl = drop.querySelector(`#prev-${id}`);
        const icoEl = drop.querySelector(`#ico-${id}`);

        stEl.textContent = '⏳ Membaca file gambar...';
        fnEl.textContent = file.name;

        const reader = new FileReader();
        reader.onload = loadEv => {
          const img = new Image();
          img.onload = () => {
            images[id] = img;
            prevEl.src = loadEv.target.result;
            prevEl.classList.remove('hidden');
            icoEl.classList.add('hidden');
            stEl.innerHTML = `<span class="text-emerald-300 font-semibold">✅ Siap (${img.width}×${img.height}px) — Klik Generate</span>`;
          };
          img.onerror = () => {
            stEl.innerHTML = '<span class="text-rose-400">❌ Format gambar tidak didukung</span>';
          };
          img.src = loadEv.target.result;
        };
        reader.readAsDataURL(file);
      });

      drop.appendChild(input);
      wrap.appendChild(drop);
    } else {
      let el;
      if (type === 'sel') {
        el = document.createElement('select');
        defVal.split('|').forEach(opt => el.add(new Option(opt, opt)));
        values[id] = el.value;
      } else if (type === 'area') {
        el = document.createElement('textarea');
        el.rows = 3;
        el.value = defVal;
        values[id] = defVal;
      } else {
        el = document.createElement('input');
        el.type = type === 'num' ? 'number' : 'text';
        el.value = defVal;
        values[id] = defVal;
      }
      el.className = 'inp';
      el.addEventListener('input', () => { values[id] = el.value; });
      el.addEventListener('change', () => { values[id] = el.value; });
      wrap.appendChild(el);
    }

    F.appendChild(wrap);
  });

  const genBtn = document.createElement('button');
  genBtn.className = 'btn-neon w-full mt-2 flex items-center justify-center gap-2 text-sm';
  genBtn.innerHTML = '<span>⚡</span> <span>Generate Sekarang</span>';
  genBtn.onclick = executeGenerate;
  F.appendChild(genBtn);
}

// ===== REAL WEB AUDIO API SYNTH BEAT FOR TOP BAR VISUALIZER =====
let audioCtx = null;
let beatTimer = null;
let isPlaying = false;
let step = 0;

function toggleSynthBeat() {
  isPlaying = !isPlaying;
  $('#pp-ico').textContent = isPlaying ? '⏸' : '▶';
  $('#viz').className = (isPlaying ? 'pl' : 'pa') + ' flex items-end gap-1 h-6';

  if (isPlaying) {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const notes = [130.81, 155.56, 196.00, 233.08, 261.63, 196.00, 155.56, 174.61];
    beatTimer = setInterval(() => {
      if (!isPlaying) return;
      const nowT = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = step % 4 === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(notes[step % notes.length], nowT);
      gain.gain.setValueAtTime(0.06, nowT);
      gain.gain.exponentialRampToValueAtTime(0.0008, nowT + 0.22);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(nowT);
      osc.stop(nowT + 0.23);
      step++;
    }, 240);
  } else {
    clearInterval(beatTimer);
  }
}
$('#pp').onclick = toggleSynthBeat;

// Battery API Status
if (navigator.getBattery) {
  navigator.getBattery().then(b => {
    const updBat = () => ($('#bat').textContent = Math.round(b.level * 100) + '%');
    updBat();
    b.addEventListener('levelchange', updBat);
  }).catch(() => {});
}

// Initial Grid Render
renderGrid();
