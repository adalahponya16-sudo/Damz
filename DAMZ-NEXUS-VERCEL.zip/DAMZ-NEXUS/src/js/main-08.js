
var GAMES_LIST=[
{id:"ttt",n:"Tic Tac Toe",d:"3x3 klasik",max:2,ico:"X",color:"#00ff88"},
{id:"c4",n:"Connect 4",d:"Susun 4 sejajar",max:2,ico:"4",color:"#fbbf24"},
{id:"rps",n:"RPS Battle",d:"Best of 3",max:2,ico:"R",color:"#22c55e"},
{id:"quiz",n:"Quiz Battle",d:"Kuis 5 soal",max:4,ico:"?",color:"#a855f7"},
{id:"mathrace",n:"Math Race",d:"Hitungan cepat",max:4,ico:"+",color:"#06b6d4"},
{id:"ular",n:"Ular Tangga",d:"Papan 100 kotak",max:4,ico:"U",color:"#22d3ee"},
{id:"memory",n:"Memory Battle",d:"Cocokkan kartu",max:2,ico:"M",color:"#f43f5e"},
{id:"tebak_angka",n:"Tebak Angka",d:"1-100",max:2,ico:"1",color:"#f59e0b"},
{id:"tebak_kata",n:"Tebak Kata",d:"Tebak huruf",max:4,ico:"K",color:"#22c55e"}
];
var SOLO_GAMES=[
{id:"s_2048",n:"2048",ico:"2",cat:"puzzle",color:"#00ff88"},
{id:"s_memory",n:"Memory",ico:"M",cat:"puzzle",color:"#22d3ee"},
{id:"s_hangman",n:"Hangman",ico:"H",cat:"puzzle",color:"#fbbf24"},
{id:"s_snake",n:"Snake",ico:"S",cat:"arcade",color:"#00ff88"},
{id:"s_quiz",n:"Quiz Umum",ico:"?",cat:"edu",color:"#06b6d4"},
{id:"s_reaction",n:"Reaction",ico:"!",cat:"sim",color:"#fbbf24"},
{id:"s_clicker",n:"Clicker",ico:"C",cat:"sim",color:"#22c55e"}
];

function renderGames(){
var el=$("gamesMain");if(!el)return;
if($("gamesCount"))$("gamesCount").textContent=GAMES_LIST.length+SOLO_GAMES.length;
var h='<div class="chips" id="gameTabBar" style="margin-bottom:12px">'+
'<button class="chip on" data-gtab="mabar">🎮 MABAR ('+GAMES_LIST.length+')</button>'+
'<button class="chip" data-gtab="solo">🎯 SENDIRI ('+SOLO_GAMES.length+')</button>'+
'</div><div id="gameTabContent"></div>';
el.innerHTML=h;
document.querySelectorAll("#gameTabBar .chip").forEach(function(btn){
btn.onclick=function(){
document.querySelectorAll("#gameTabBar .chip").forEach(function(b){b.classList.remove("on");});
btn.classList.add("on");
renderGameTab(btn.getAttribute("data-gtab"));
};
});
renderGameTab("mabar");
}
window.renderGames=renderGames;

function renderGameTab(tab){
var c=$("gameTabContent");if(!c)return;
if(tab==="mabar"){
var h='<div class="game-cat-title"><i class="fas fa-users"></i> MAIN BARENG</div><div class="mp-grid">';
GAMES_LIST.forEach(function(g){
h+='<div class="mp-card" onclick="openMpGame(\''+g.id+'\')" style="border-color:'+g.color+'33"><span class="mp-badge" style="background:linear-gradient(135deg,'+g.color+',var(--c))">'+g.max+'P</span><div class="mp-ico" style="color:'+g.color+'">'+g.ico+'</div><div class="mp-name">'+g.n+'</div><div class="mp-desc">'+g.d+'</div></div>';
});
h+='</div>';
c.innerHTML=h;
}else{
var cats=[{key:"puzzle",name:"PUZZLE",ico:"fa-puzzle-piece",color:"#00ff88"},{key:"arcade",name:"ARCADE",ico:"fa-gamepad",color:"#22d3ee"},{key:"edu",name:"EDUKASI",ico:"fa-graduation-cap",color:"#fbbf24"},{key:"sim",name:"SIMULASI",ico:"fa-flask",color:"#22c55e"}];
var h="";
cats.forEach(function(ct){
var items=SOLO_GAMES.filter(function(g){return g.cat===ct.key;});
if(!items.length)return;
h+='<div class="game-cat-title" style="color:'+ct.color+'"><i class="fas '+ct.ico+'"></i> '+ct.name+'</div>';
h+='<div class="solo-grid" style="grid-template-columns:repeat(auto-fill,minmax(85px,1fr))">';
items.forEach(function(g){
h+='<div class="solo-card" onclick="openSoloGame(\''+g.id+'\')" style="border-color:'+g.color+'33"><div style="font-size:24px;font-weight:900;color:'+g.color+';line-height:1;font-family:var(--fd)">'+g.ico+'</div><span style="color:'+g.color+'">'+esc(g.n)+'</span></div>';
});
h+='</div>';
});
c.innerHTML=h;
}
}
window.renderGameTab=renderGameTab;

function SA(){return $("soloGameArea");}
function openSoloGame(id){
$("viewer").classList.add("on");
$("viewerBody").innerHTML='<button class="btn sec" style="margin-bottom:12px" onclick="closeTool()"><i class="fas fa-arrow-left"></i> KEMBALI</button><div class="viewer-lbl">GAME</div><div class="viewer-h">Solo Game</div><div class="viewer-d">'+esc(id)+'</div><div id="soloGameArea"></div>';
setTimeout(function(){
if(id==="s_2048")run2048();
else if(id==="s_memory")runMemory();
else if(id==="s_hangman")runHangman();
else if(id==="s_snake")runSnake();
else if(id==="s_quiz")runQuizGame();
else if(id==="s_reaction")runReactionTest();
else if(id==="s_clicker")runClicker();
},80);
}
window.openSoloGame=openSoloGame;

function openMpGame(id){
var g=GAMES_LIST.filter(function(x){return x.id===id;})[0];if(!g)return;
var h='<div style="text-align:left"><div style="font-size:.72rem;color:var(--t2);margin-bottom:12px;line-height:1.6">Main bareng <b style="color:'+g.color+'">'+g.n+'</b> dengan '+g.max+' orang!</div><div class="info-box">Buat room, bagikan kode ke teman, tunggu mereka join, lalu mulai main.</div></div>';
showModal("fa-gamepad","MAIN BARENG",h,"BUAT ROOM",function(){createRoom(id);},g.color);
setTimeout(function(){var cancel=$("modalCancel");if(cancel){cancel.textContent="JOIN ROOM";cancel.onclick=function(e){e.preventDefault();closeModal();promptJoinRoom(id);};}},80);
}
window.openMpGame=openMpGame;

function promptJoinRoom(gameId){
showModal("fa-right-to-bracket","JOIN ROOM","<label class='lbl'>Kode Room</label><input class='inp' id='joinCode' placeholder='ABC123' style='text-transform:uppercase;font-family:var(--fm);font-weight:900;letter-spacing:4px;text-align:center;font-size:1.1rem'>","JOIN",function(){var code=$("joinCode").value.trim().toUpperCase();if(!code||code.length<4){toast("Kode invalid","err");return;}joinRoom(code,gameId);},"var(--n)");
}
window.promptJoinRoom=promptJoinRoom;

function genRoomCode(){var c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",s="";for(var i=0;i<6;i++)s+=c.charAt(Math.floor(Math.random()*c.length));return s;}
function createRoom(gameId){
var g=GAMES_LIST.filter(function(x){return x.id===gameId;})[0];if(!g)return;
var code=genRoomCode();
var room={code:code,game:gameId,gameName:g.n,maxPlayers:g.max,host:CURRENT_USER,players:[CURRENT_USER],status:"waiting",createdAt:Date.now(),state:null};
db.ref("gameRooms/"+code).set(room).then(function(){logAction("create_room",gameId+" "+code);openRoom(code);toast("Room: "+code,"ok");});
}
window.createRoom=createRoom;

function joinRoom(code,gameId){
db.ref("gameRooms/"+code).once("value").then(function(snap){
var room=snap.val();
if(!room){toast("Room tidak ditemukan","err");return;}
if(gameId&&room.game!==gameId){toast("Room untuk game lain","err");return;}
if(room.status!=="waiting"){toast("Game sudah mulai","err");return;}
if(room.players.length>=room.maxPlayers){toast("Room penuh","err");return;}
if(room.players.indexOf(CURRENT_USER)>=0){openRoom(code);return;}
db.ref("gameRooms/"+code+"/players").set(room.players.concat([CURRENT_USER])).then(function(){openRoom(code);toast("Joined!","ok");});
});
}
window.joinRoom=joinRoom;

var ROOM={code:null,game:null,data:null,ref:null,handler:null};
function openRoom(code){
$("gameRoom").style.display="flex";ROOM.code=code;
$("gameRoom").innerHTML='<div style="padding:40px;text-align:center;color:var(--t2)">'+loading()+'</div>';
stopWatchingRoom();
ROOM.ref=db.ref("gameRooms/"+code);
ROOM.handler=ROOM.ref.on("value",function(snap){
var room=snap.val();
if(!room){toast("Room bubar","err");closeRoom();return;}
ROOM.data=room;
if(room.status==="waiting")renderWaitingRoom(room);
else if(room.status==="playing")renderGameBoard(room);
else if(room.status==="ended")renderGameEnd(room);
});
}
window.openRoom=openRoom;
function stopWatchingRoom(){if(ROOM.ref&&ROOM.handler){try{ROOM.ref.off("value",ROOM.handler);}catch(e){}}ROOM.ref=null;ROOM.handler=null;}
function closeRoom(){stopWatchingRoom();ROOM.code=null;ROOM.game=null;ROOM.data=null;$("gameRoom").style.display="none";$("gameRoom").innerHTML="";renderGames();}
window.closeRoom=closeRoom;
function leaveRoom(){
if(!ROOM.code){closeRoom();return;}
var room=ROOM.data;
if(!room){closeRoom();return;}
if(room.status==="waiting"&&room.players.indexOf(CURRENT_USER)>=0){
var newPlayers=room.players.filter(function(p){return p!==CURRENT_USER;});
if(newPlayers.length===0){db.ref("gameRooms/"+ROOM.code).remove();}
else if(room.host===CURRENT_USER){db.ref("gameRooms/"+ROOM.code).update({players:newPlayers,host:newPlayers[0]});}
else{db.ref("gameRooms/"+ROOM.code+"/players").set(newPlayers);}
}
closeRoom();
toast("Keluar room","ok");
}
window.leaveRoom=leaveRoom;

function renderWaitingRoom(room){
var isHost=room.host===CURRENT_USER;
var playerCells="";
for(var i=0;i<room.maxPlayers;i++){
var pu=room.players[i];
if(pu){
var pp=getUserPP(pu);var disp=getUserDisplay(pu);
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
var avText=pp?'':disp.charAt(0).toUpperCase();
playerCells+='<div class="room-player ready'+(pu===room.host?' host':'')+'"><div class="room-player-av" style="'+avStyle+'">'+avText+'</div><div class="room-player-name">'+esc(disp)+'</div><div class="room-player-status">READY</div></div>';
}else{
playerCells+='<div class="room-player empty"><div class="room-player-av">+</div><div class="room-player-name">Menunggu...</div><div class="room-player-status">KOSONG</div></div>';
}
}
var canStart=isHost&&room.players.length>=2;
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">'+esc(room.gameName||"Room")+'</div><button class="room-code" onclick="copyText(\''+room.code+'\')">'+room.code+'</button></div><div style="font-family:var(--fm);font-size:.5rem;color:var(--t3);text-align:center">'+room.players.length+' / '+room.maxPlayers+' pemain</div></div>';
h+='<div class="room-body"><div class="room-players">'+playerCells+'</div>';
h+='<div class="room-actions"><button class="btn sec" onclick="invitePlayer()"><i class="fas fa-user-plus"></i> UNDANG</button><button class="btn cyan" onclick="copyText(\''+room.code+'\')"><i class="fas fa-copy"></i> SALIN KODE</button></div>';
h+=(isHost?'<button class="btn green" '+(canStart?'':'disabled')+' onclick="startGame()"><i class="fas fa-play"></i> '+(canStart?'MULAI GAME':'BUTUH MIN 2 PEMAIN')+'</button>':'<div class="info-box">Menunggu host memulai...</div>');
h+='<button class="btn red" onclick="leaveRoom()"><i class="fas fa-sign-out-alt"></i> KELUAR ROOM</button></div>';
$("gameRoom").innerHTML=h;
}
window.renderWaitingRoom=renderWaitingRoom;

function invitePlayer(){
var m=getMembers();var room=ROOM.data;
var contacts=chatGetContacts();
var others=contacts.filter(function(c){var u=c.u;return u!==CURRENT_USER&&room.players.indexOf(u)<0&&m[u]&&!m[u].banned;});
var h='<div style="text-align:left;max-height:400px;overflow-y:auto">';
if(!others.length)h+='<div class="info-box orange">Tidak ada kontak untuk diundang</div>';
else others.forEach(function(c){var u=c.u;var disp=chatDisplayName(u);h+='<div class="pick-invite" data-user="'+esc(u)+'" style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(0,0,0,.3);border:1.5px solid var(--b);border-radius:12px;margin-bottom:8px;cursor:pointer">'+avatarHTML(u,42)+'<div style="flex:1"><div style="color:#fff;font-weight:700;font-size:.78rem">'+esc(disp)+'</div></div><i class="fas fa-paper-plane" style="color:var(--n)"></i></div>';});
h+='</div>';
showModal("fa-user-plus","UNDANG PEMAIN",h,"TUTUP",null,"var(--n)");
setTimeout(function(){document.querySelectorAll(".pick-invite").forEach(function(el){el.onclick=function(){var u=this.getAttribute("data-user");sendInvite(u);toast("Undangan terkirim","ok");closeModal();};});},80);
}
window.invitePlayer=invitePlayer;
function sendInvite(to){if(!ROOM.code)return;db.ref("gameInvites/"+to).push({from:CURRENT_USER,code:ROOM.code,game:ROOM.data.gameName,time:Date.now()});}
window.sendInvite=sendInvite;
var INVITE_WATCH=false;
function watchInvites(){
if(!db||!CURRENT_USER||INVITE_WATCH)return;
INVITE_WATCH=true;
db.ref("gameInvites/"+CURRENT_USER).on("child_added",function(snap){
var inv=snap.val();if(!inv||!inv.from)return;
if(Date.now()-inv.time>120000){snap.ref.remove();return;}
showModal("fa-gamepad","UNDANGAN GAME","<div><div style='font-size:.72rem;color:var(--t2);line-height:1.7'><b style='color:var(--n)'>"+esc(getUserDisplay(inv.from))+"</b> mengajak main <b style='color:var(--g)'>"+esc(inv.game||"game")+"</b>!<br>Room: <b style='font-family:var(--fm);color:var(--c)'>"+esc(inv.code)+"</b></div></div>","JOIN",function(){closeModal();joinRoom(inv.code);snap.ref.remove();},"var(--n)");
setTimeout(function(){var c=$("modalCancel");if(c)c.textContent="TOLAK";},80);
});
}
window.watchInvites=watchInvites;

function startGame(){if(!ROOM.code||!ROOM.data)return;var game=ROOM.data.game,players=ROOM.data.players;var initial=initGameState(game,players);db.ref("gameRooms/"+ROOM.code).update({status:"playing",state:initial});logAction("start_game",game);}
window.startGame=startGame;

function initGameState(game,players){
if(game==="ttt")return{board:["","","","","","","","",""],turn:players[0],winner:null};
if(game==="c4")return{board:emptyC4(),turn:players[0],winner:null};
if(game==="ular")return{positions:{},turn:players[0],dice:0,rolling:false,winner:null};
if(game==="rps")return{round:1,picks:{},scores:{},roundWinner:null,winner:null};
if(game==="quiz")return{questions:genQuiz(),qIdx:0,answers:{},scores:{},winner:null};
if(game==="mathrace")return{q:genMathQ(),answers:{},scores:{},round:1,winner:null};
if(game==="memory")return{cards:genMemory(),flipped:[],matched:[],scores:{},turn:players[0],winner:null};
if(game==="tebak_angka")return{target:null,guesses:{},scores:{},winner:null};
if(game==="tebak_kata")return{word:"",revealed:[],guesses:{},scores:{},winner:null};
return{turn:players[0],scores:{},winner:null};
}
function emptyC4(){var b=[];for(var r=0;r<6;r++)b.push(["","","","","","",""]);return b;}

function renderGameBoard(room){
var game=room.game;
if(game==="ttt")renderTTT(room);
else if(game==="c4")renderC4(room);
else if(game==="ular")renderUlar(room);
else if(game==="rps")renderRps(room);
else if(game==="quiz")renderQuiz(room);
else if(game==="mathrace")renderMathRace(room);
else if(game==="memory")renderMemoryMp(room);
else if(game==="tebak_angka")renderTebakAngka(room);
else if(game==="tebak_kata")renderTebakKata(room);
else renderSimpleGame(room);
}
window.renderGameBoard=renderGameBoard;

function renderSimpleGame(room){
var g=GAMES_LIST.filter(function(x){return x.id===room.game;})[0];
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">'+esc(g?g.n:"Game")+'</div><button class="room-code" onclick="leaveRoom()">X</button></div></div><div class="room-body"><div class="gboard-wrap" style="text-align:center;padding:30px 20px"><div style="font-size:4rem;margin-bottom:14px">'+(g?g.ico:"")+'</div><div style="font-family:var(--fd);font-size:1rem;color:#fff;margin-bottom:10px">'+esc(g?g.n:"Game")+'</div><div class="info-box">Game ini sedang dikembangkan.</div><button class="btn green" onclick="leaveRoom()">KELUAR</button></div></div>';
$("gameRoom").innerHTML=h;
}

function renderTTT(room){
var s=room.state,players=room.players;
var sym=players[0]===CURRENT_USER?"X":(players[1]===CURRENT_USER?"O":"?");
var isMyTurn=s.turn===CURRENT_USER&&!s.winner;
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Tic Tac Toe</div><button class="room-code" onclick="leaveRoom()">X</button></div><div class="gboard-turn'+(isMyTurn?' you':'')+'">'+(s.winner?"SELESAI":(isMyTurn?"GILIRANMU":"Giliran "+esc(getUserDisplay(s.turn))))+'</div></div>';
h+='<div class="room-body"><div class="gboard-wrap"><div class="ttt-board">';
for(var i=0;i<9;i++){var v=s.board[i];var cls="ttt-cell";if(v==="X")cls+=" x";if(v==="O")cls+=" o";h+='<div class="'+cls+'" onclick="'+(isMyTurn&&!v&&!s.winner?'tttMove('+i+')':'')+'">'+esc(v||"")+'</div>';}
h+='</div></div><div class="info-box">Kamu: <b style="color:var(--n)">'+sym+'</b></div><button class="btn red" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
function tttMove(idx){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state;
if(s.turn!==CURRENT_USER||s.winner||s.board[idx])return;
var players=ROOM.data.players;
var sym=players[0]===CURRENT_USER?"X":"O";
var board=s.board.slice();board[idx]=sym;
var winner=checkTTT(board);
var nextTurn=players[0]===CURRENT_USER?players[1]:players[0];
db.ref("gameRooms/"+ROOM.code+"/state").update({board:board,turn:nextTurn,winner:winner});
if(winner)endGame(winner);
}
window.tttMove=tttMove;
function checkTTT(b){var w=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];for(var i=0;i<w.length;i++){var a=w[i];if(b[a[0]]&&b[a[0]]===b[a[1]]&&b[a[1]]===b[a[2]])return b[a[0]];}if(b.every(function(c){return c;}))return "DRAW";return null;}

function renderC4(room){
var s=room.state;
var isMyTurn=s.turn===CURRENT_USER&&!s.winner;
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Connect 4</div><button class="room-code" onclick="leaveRoom()">X</button></div><div class="gboard-turn'+(isMyTurn?' you':'')+'">'+(s.winner?"SELESAI":(isMyTurn?"GILIRANMU":"Giliran "+esc(getUserDisplay(s.turn))))+'</div></div>';
h+='<div class="room-body"><div class="gboard-wrap"><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px;margin-bottom:6px">';
for(var c=0;c<7;c++)h+='<button class="btn" style="padding:8px 0;font-size:.7rem;margin:0" '+(isMyTurn?'':'disabled')+' onclick="c4Drop('+c+')">v</button>';
h+='</div><div class="c4-board">';
for(var r=0;r<6;r++)for(var col=0;col<7;col++){var v=s.board[r][col];var cls="c4-cell";if(v==="1")cls+=" p1";if(v==="2")cls+=" p2";h+='<div class="'+cls+'"></div>';}
h+='</div></div><button class="btn red" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
function c4Drop(col){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state,players=ROOM.data.players;
if(s.turn!==CURRENT_USER||s.winner)return;
var board=s.board.map(function(r){return r.slice();});
var placed=false;
for(var r=5;r>=0;r--){if(!board[r][col]){board[r][col]=players[0]===CURRENT_USER?"1":"2";placed=true;break;}}
if(!placed)return;
var w=checkC4(board);
var nextTurn=players[0]===CURRENT_USER?players[1]:players[0];
db.ref("gameRooms/"+ROOM.code+"/state").update({board:board,turn:nextTurn,winner:w});
if(w)endGame(players[w==="1"?0:1]);
}
window.c4Drop=c4Drop;
function checkC4(b){for(var r=0;r<6;r++)for(var c=0;c<7;c++){var v=b[r][c];if(!v)continue;if(c+3<7&&b[r][c+1]===v&&b[r][c+2]===v&&b[r][c+3]===v)return v;if(r+3<6&&b[r+1][c]===v&&b[r+2][c]===v&&b[r+3][c]===v)return v;if(r+3<6&&c+3<7&&b[r+1][c+1]===v&&b[r+2][c+2]===v&&b[r+3][c+3]===v)return v;if(r+3<6&&c-3>=0&&b[r+1][c-1]===v&&b[r+2][c-2]===v&&b[r+3][c-3]===v)return v;}return null;}
function endGame(winner){if(!ROOM.code)return;setTimeout(function(){db.ref("gameRooms/"+ROOM.code).update({status:"ended",finalWinner:winner});logAction("game_end",winner);},1500);}
function renderGameEnd(room){
var winner=room.finalWinner;
var h='<div class="room-body" style="text-align:center;padding:40px 20px">';
if(winner==="DRAW"||!winner)h+='<div class="game-end"><div style="font-size:5rem">=</div><div class="winner">SERI!</div></div>';
else if(winner===CURRENT_USER)h+='<div class="game-end"><div style="font-size:5rem">🏆</div><div class="winner">KAMU MENANG!</div></div>';
else h+='<div class="game-end"><div style="font-size:5rem">X</div><div class="winner">'+esc(getUserDisplay(winner))+' MENANG</div></div>';
h+='<button class="btn green" onclick="rematchGame()"><i class="fas fa-redo"></i> MAIN LAGI</button>';
h+='<button class="btn sec" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
window.renderGameEnd=renderGameEnd;
function rematchGame(){if(!ROOM.code||!ROOM.data)return;db.ref("gameRooms/"+ROOM.code).update({status:"waiting",state:null,finalWinner:null});toast("Siap main lagi!","ok");}
window.rematchGame=rematchGame;

var ULAR_SNAKES={16:6,47:26,49:11,56:53,62:19,64:60,87:24,93:73,95:75,98:78};
var ULAR_LADDERS={1:38,4:14,9:31,21:42,28:84,36:44,51:67,71:91,80:100};
function genUlarOrder(){var o=[];for(var row=9;row>=0;row--){var start=row*10+1,end=start+9;if(row%2===0)for(var i=start;i<=end;i++)o.push(i);else for(var j=end;j>=start;j--)o.push(j);}return o;}
function renderUlar(room){
var s=room.state,players=room.players;
var myTurn=s.turn===CURRENT_USER&&!s.winner;
var dispOrder=genUlarOrder();
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Ular Tangga</div><button class="room-code" onclick="leaveRoom()">X</button></div><div class="gboard-turn'+(myTurn?' you':'')+'">'+(s.winner?"SELESAI":(myTurn?"GILIRANMU":"Giliran "+esc(getUserDisplay(s.turn))))+'</div></div>';
h+='<div class="room-body"><div class="ular-board">';
dispOrder.forEach(function(num){var cls="ular-cell";if(ULAR_LADDERS[num])cls+=" ladder";if(ULAR_SNAKES[num])cls+=" snake";if(num===1)cls+=" start";if(num===100)cls+=" end";var tokens="";players.forEach(function(p,i){if((s.positions[p]||0)===num)tokens+='<div class="ular-token t'+(i+1)+'">'+(i+1)+'</div>';});h+='<div class="'+cls+'"><span style="position:absolute;top:1px;left:2px;font-size:.4rem">'+num+'</span><div class="ular-tokens">'+tokens+'</div></div>';});
h+='</div><div class="dice-area"><div class="dice" id="diceBox">?</div><button class="dice-btn" id="diceBtn" '+(myTurn?'':'disabled')+' onclick="ularRoll()">'+(myTurn?'LEMPAR':'TUNGGU')+'</button></div><button class="btn red" style="margin-top:14px" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
function ularRoll(){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state,players=ROOM.data.players;
if(s.turn!==CURRENT_USER||s.winner||s.rolling)return;
db.ref("gameRooms/"+ROOM.code+"/state").update({rolling:true});
var dice=Math.floor(Math.random()*6)+1;
var el=$("diceBox");if(el){el.textContent=dice;}
setTimeout(function(){
var pos=s.positions[CURRENT_USER]||0;
var newPos=pos+dice;
if(newPos>100)newPos=pos;
if(ULAR_LADDERS[newPos])newPos=ULAR_LADDERS[newPos];
else if(ULAR_SNAKES[newPos])newPos=ULAR_SNAKES[newPos];
var positions=Object.assign({},s.positions);positions[CURRENT_USER]=newPos;
var winner=newPos>=100?CURRENT_USER:null;
var nextTurn=winner?null:nextPlayer(s.turn,players);
db.ref("gameRooms/"+ROOM.code+"/state").update({positions:positions,dice:dice,rolling:false,turn:nextTurn,winner:winner});
if(winner)endGame(winner);
},800);
}
window.ularRoll=ularRoll;
function nextPlayer(cur,players){var i=players.indexOf(cur);return players[(i+1)%players.length];}

function rpsEmoji(p){return{rock:"X",paper:"P",scissors:"S"}[p]||"?";}
function renderRps(room){
var s=room.state,players=room.players;
var myPick=s.picks[CURRENT_USER];
var op=players.filter(function(p){return p!==CURRENT_USER;})[0];
var opPick=s.picks[op];
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">RPS Battle</div><button class="room-code" onclick="leaveRoom()">X</button></div></div>';
h+='<div class="room-body"><div class="rps-scores"><div class="rps-score-card"><div class="name">'+esc(getUserDisplay(CURRENT_USER))+'</div><div class="score">'+(s.scores[CURRENT_USER]||0)+'</div></div><div class="rps-score-card"><div class="name">'+esc(getUserDisplay(op))+'</div><div class="score">'+(s.scores[op]||0)+'</div></div></div>';
h+='<div class="rps-picks"><div class="rps-side"><div class="label">KAMU</div><div class="pick" style="color:var(--n)">'+(myPick?rpsEmoji(myPick):"?")+'</div></div><div class="rps-side"><div class="label">'+esc(getUserDisplay(op).toUpperCase())+'</div><div class="pick" style="color:var(--c)">'+(opPick?rpsEmoji(opPick):"?")+'</div></div></div>';
if(s.roundWinner)h+='<div class="info-box" style="text-align:center"><b>'+esc(getUserDisplay(s.roundWinner))+'</b> menang ronde!</div>';
h+='<div class="rps-buttons"><button class="rps-btn'+(myPick==="rock"?" picked":"")+'" onclick="rpsPick(\'rock\')" '+(myPick?'disabled':'')+'>Batu</button><button class="rps-btn'+(myPick==="paper"?" picked":"")+'" onclick="rpsPick(\'paper\')" '+(myPick?'disabled':'')+'>Kertas</button><button class="rps-btn'+(myPick==="scissors"?" picked":"")+'" onclick="rpsPick(\'scissors\')" '+(myPick?'disabled':'')+'>Gunting</button></div>';
h+='<button class="btn red" style="margin-top:14px" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
function rpsPick(pick){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state,players=ROOM.data.players;
if(s.picks[CURRENT_USER]||s.winner)return;
var picks=Object.assign({},s.picks);picks[CURRENT_USER]=pick;
var op=players.filter(function(p){return p!==CURRENT_USER;})[0];
if(picks[op]){
var opPick=picks[op];
var roundWinner=null;
if(opPick!==pick){
if((pick==="rock"&&opPick==="scissors")||(pick==="paper"&&opPick==="rock")||(pick==="scissors"&&opPick==="paper"))roundWinner=CURRENT_USER;
else roundWinner=op;
}
var scores=Object.assign({},s.scores);
if(roundWinner)scores[roundWinner]=(scores[roundWinner]||0)+1;
var finished=Object.keys(scores).some(function(k){return scores[k]>=2;});
var gw=finished?Object.keys(scores).filter(function(k){return scores[k]>=2;})[0]:null;
setTimeout(function(){db.ref("gameRooms/"+ROOM.code+"/state").set({round:s.round+1,picks:{},scores:scores,roundWinner:roundWinner||"SERI",winner:gw});if(gw)endGame(gw);},1500);
}else db.ref("gameRooms/"+ROOM.code+"/state/picks").set(picks);
}
window.rpsPick=rpsPick;

var QUIZ_POOL=[
{q:"Ibu kota Indonesia?",o:["Jakarta","Bandung","Surabaya","Medan"],a:0},
{q:"2 + 2 x 2 = ?",o:["6","8","4","10"],a:0},
{q:"Planet terdekat matahari?",o:["Merkurius","Venus","Bumi","Mars"],a:0},
{q:"Pemain bola 1 tim?",o:["11","10","9","12"],a:0},
{q:"Warna bendera Indonesia?",o:["Merah Putih","Merah Biru","Putih Biru","Kuning Merah"],a:0},
{q:"Hewan tercepat darat?",o:["Cheetah","Singa","Kuda","Macan"],a:0},
{q:"7 x 8 = ?",o:["56","54","58","60"],a:0},
{q:"Lambang negara Indonesia?",o:["Garuda","Elang","Merpati","Rajawali"],a:0},
{q:"Jumlah provinsi Indonesia 2024?",o:["38","34","36","40"],a:0},
{q:"Siapa penemu lampu?",o:["Thomas Edison","Einstein","Newton","Tesla"],a:0}
];
function genQuiz(){var q=QUIZ_POOL.slice().sort(function(){return Math.random()-0.5;}).slice(0,5);return q.map(function(x){var opts=x.o.slice().sort(function(){return Math.random()-0.5;});return{q:x.q,o:opts,a:opts.indexOf(x.o[x.a])};});}
function renderQuiz(room){
var s=room.state,players=room.players;
var q=s.questions[s.qIdx];
if(!q){$("gameRoom").innerHTML='<div class="room-body"><div class="info-box">Kuis selesai</div></div>';return;}
var myAns=s.answers[CURRENT_USER+"_"+s.qIdx];
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Quiz Battle</div><button class="room-code" onclick="leaveRoom()">X</button></div></div>';
h+='<div class="room-body"><div class="quiz-scorebar">';
players.forEach(function(p){h+='<div class="quiz-pscore"><div class="n">'+esc(getUserDisplay(p).slice(0,8))+'</div><div class="s">'+(s.scores[p]||0)+'</div></div>';});
h+='</div><div class="quiz-wrap"><div class="quiz-q-num">SOAL '+(s.qIdx+1)+' / '+s.questions.length+'</div><div class="quiz-question">'+esc(q.q)+'</div><div class="quiz-options">';
q.o.forEach(function(opt,i){var cls="quiz-opt";if(myAns!==undefined){cls+=" disabled";if(i===q.a)cls+=" correct";else if(i===myAns)cls+=" wrong";}h+='<button type="button" class="'+cls+'" '+(myAns!==undefined?'disabled':'')+' onclick="quizAns('+i+')"><span class="opt-letter">'+String.fromCharCode(65+i)+'</span>'+esc(opt)+'</button>';});
h+='</div></div><button class="btn red" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
if(myAns!==undefined)setTimeout(quizNext,2500);
}
function quizAns(i){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state;
if(s.answers[CURRENT_USER+"_"+s.qIdx]!==undefined)return;
var q=s.questions[s.qIdx];
var answers=Object.assign({},s.answers);answers[CURRENT_USER+"_"+s.qIdx]=i;
var scores=Object.assign({},s.scores);if(i===q.a)scores[CURRENT_USER]=(scores[CURRENT_USER]||0)+10;
db.ref("gameRooms/"+ROOM.code+"/state").update({answers:answers,scores:scores});
setTimeout(quizNext,2500);
}
window.quizAns=quizAns;
function quizNext(){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state,players=ROOM.data.players;
var next=s.qIdx+1;
if(next>=s.questions.length){
var best=0,winner=null;
players.forEach(function(p){if((s.scores[p]||0)>best){best=s.scores[p];winner=p;}});
endGame(winner||"DRAW");
return;
}
db.ref("gameRooms/"+ROOM.code+"/state").update({qIdx:next});
}
function genMathQ(){var a=Math.floor(Math.random()*20)+5;var b=Math.floor(Math.random()*20)+5;var ops=["+","-","x"];var op=ops[Math.floor(Math.random()*3)];var ans;if(op==="+")ans=a+b;else if(op==="-")ans=a-b;else ans=a*b;return{text:a+" "+op+" "+b+" = ?",ans:ans};}
function renderMathRace(room){
var s=room.state,players=room.players;
var myAns=s.answers[CURRENT_USER+"_"+s.round];
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Math Race</div><button class="room-code" onclick="leaveRoom()">X</button></div></div>';
h+='<div class="room-body"><div class="quiz-scorebar">';
players.forEach(function(p){h+='<div class="quiz-pscore"><div class="n">'+esc(getUserDisplay(p).slice(0,8))+'</div><div class="s">'+(s.scores[p]||0)+'</div></div>';});
h+='</div><div class="quiz-wrap"><div class="quiz-q-num">SOAL '+s.round+'</div><div class="quiz-question" style="font-size:1.5rem;text-align:center;font-family:var(--fd)">'+esc(s.q.text)+'</div>';
h+='<input type="number" class="inp" id="mrInput" placeholder="Jawaban" '+(myAns!==undefined?'disabled':'')+' style="font-size:1.2rem;text-align:center"><button class="btn green" onclick="mrSubmit()" '+(myAns!==undefined?'disabled':'')+'>KIRIM</button>';
h+='</div><button class="btn red" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
window.mrSubmit=function(){
var v=parseInt($("mrInput").value);
if(isNaN(v)){toast("Isi angka","err");return;}
var s=ROOM.data.state,players=ROOM.data.players;
if(s.answers[CURRENT_USER+"_"+s.round]!==undefined)return;
var answers=Object.assign({},s.answers);answers[CURRENT_USER+"_"+s.round]=v;
var scores=Object.assign({},s.scores);
if(v===s.q.ans)scores[CURRENT_USER]=(scores[CURRENT_USER]||0)+10;
db.ref("gameRooms/"+ROOM.code+"/state").update({answers:answers,scores:scores});
setTimeout(function(){
if(s.round>=5){
var best=0,w=null;Object.keys(scores).forEach(function(p){if(scores[p]>best){best=scores[p];w=p;}});
endGame(w||"DRAW");return;
}
db.ref("gameRooms/"+ROOM.code+"/state").update({q:genMathQ(),round:s.round+1});
},1500);
};
function genMemory(){var icons=["A","B","C","D","E","F","G","H"];var cards=[];icons.forEach(function(ic,i){cards.push({id:i,icon:ic});cards.push({id:i,icon:ic});});return cards.sort(function(){return Math.random()-0.5;});}
function renderMemoryMp(room){
var s=room.state,players=room.players;
var isMyTurn=s.turn===CURRENT_USER&&!s.winner;
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Memory Battle</div><button class="room-code" onclick="leaveRoom()">X</button></div><div class="gboard-turn'+(isMyTurn?' you':'')+'">'+(isMyTurn?"GILIRANMU":"Giliran "+esc(getUserDisplay(s.turn)))+'</div></div>';
h+='<div class="room-body">';
h+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;max-width:360px;margin:0 auto 14px">';
s.cards.forEach(function(c,i){var flipped=s.flipped.indexOf(i)>=0||s.matched.indexOf(i)>=0;h+='<div onclick="'+(isMyTurn&&!flipped?'memoryFlip('+i+')':'')+'" style="aspect-ratio:1;background:'+(flipped?'linear-gradient(135deg,var(--n),var(--c))':'rgba(15,36,22,.7)')+';border:2px solid var(--b);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:28px;cursor:pointer">'+(flipped?c.icon:"?")+'</div>';});
h+='</div>';
players.forEach(function(p){h+='<div class="info-box">'+esc(getUserDisplay(p))+': <b>'+(s.scores[p]||0)+'</b> pasang</div>';});
h+='<button class="btn red" onclick="leaveRoom()">KELUAR</button></div>';
$("gameRoom").innerHTML=h;
}
function memoryFlip(i){
if(!ROOM.code||!ROOM.data)return;
var s=ROOM.data.state;
if(s.turn!==CURRENT_USER||s.winner)return;
if(s.flipped.indexOf(i)>=0||s.matched.indexOf(i)>=0)return;
var flipped=s.flipped.slice();flipped.push(i);
if(flipped.length===2){
var a=flipped[0],b=flipped[1];
if(s.cards[a].id===s.cards[b].id){
var matched=s.matched.slice();matched.push(a,b);
var scores=Object.assign({},s.scores);scores[CURRENT_USER]=(scores[CURRENT_USER]||0)+1;
var allMatched=matched.length===s.cards.length;
db.ref("gameRooms/"+ROOM.code+"/state").update({flipped:[],matched:matched,scores:scores});
if(allMatched){var mx=0,w=null;Object.keys(scores).forEach(function(p){if(scores[p]>mx){mx=scores[p];w=p;}});endGame(w);}
}else{
setTimeout(function(){var players=ROOM.data.players;var nextTurn=players[0]===CURRENT_USER?players[1]:players[0];db.ref("gameRooms/"+ROOM.code+"/state").update({flipped:[],turn:nextTurn});},1000);
}
}else db.ref("gameRooms/"+ROOM.code+"/state/flipped").set(flipped);
}
window.memoryFlip=memoryFlip;

function renderTebakAngka(room){
var s=room.state||{},players=room.players;
var myGuess=s.guesses&&s.guesses[CURRENT_USER];
var target=s.target;
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Tebak Angka 1-100</div><button class="room-code" onclick="leaveRoom()">X</button></div></div>';
h+='<div class="room-body"><div class="gboard-wrap" style="text-align:center;padding:30px 20px">';
h+='<div style="font-size:4rem;margin-bottom:14px">1</div>';
if(!target){
if(room.host===CURRENT_USER){h+='<div class="info-box">Pilih angka rahasia 1-100:</div><input type="number" class="inp" id="secretInput" min="1" max="100" style="font-size:1.5rem;text-align:center"><button class="btn green" onclick="setTebakAngkaTarget()">SET ANGKA</button>';}
else{h+='<div class="info-box orange">Menunggu host memilih angka...</div>';}
}else{
if(myGuess===undefined||myGuess===null){h+='<div class="info-box">Tebak angka 1-100:</div><input type="number" class="inp" id="guessInput" min="1" max="100" style="font-size:1.5rem;text-align:center"><button class="btn green" onclick="submitGuess()">TEBAK</button>';}
else{
if(myGuess===target){h+='<div class="info-box"><b>BENAR! Angka = '+target+'</b></div>';}
else if(myGuess<target){h+='<div class="info-box orange">Tebakanmu '+myGuess+' - Terlalu KECIL</div><input type="number" class="inp" id="guessInput" min="1" max="100" style="font-size:1.5rem;text-align:center"><button class="btn green" onclick="submitGuess()">TEBAK LAGI</button>';}
else{h+='<div class="info-box orange">Tebakanmu '+myGuess+' - Terlalu BESAR</div><input type="number" class="inp" id="guessInput" min="1" max="100" style="font-size:1.5rem;text-align:center"><button class="btn green" onclick="submitGuess()">TEBAK LAGI</button>';}
}
}
h+='<button class="btn red" style="margin-top:14px" onclick="leaveRoom()">KELUAR</button></div></div>';
$("gameRoom").innerHTML=h;
}
window.setTebakAngkaTarget=function(){var v=parseInt($("secretInput").value);if(isNaN(v)||v<1||v>100){toast("1-100 aja","err");return;}db.ref("gameRooms/"+ROOM.code+"/state").update({target:v,guesses:{}});toast("Angka diset!","ok");};
window.submitGuess=function(){var v=parseInt($("guessInput").value);if(isNaN(v)||v<1||v>100){toast("1-100 aja","err");return;}var s=ROOM.data.state;var guesses=Object.assign({},s.guesses||{});guesses[CURRENT_USER]=v;db.ref("gameRooms/"+ROOM.code+"/state/guesses").set(guesses).then(function(){if(v===s.target){toast("BENAR!","gold");showConfetti();endGame(CURRENT_USER);}});};

function renderTebakKata(room){
var s=room.state||{},players=room.players;
var word=s.word||"";
var guesses=s.guesses||{};
var revealed=word.split("").map(function(c){return c===" "?" ":(s.revealed&&s.revealed.indexOf(c)>=0?c:"_");}).join(" ");
var h='<div class="room-head"><div class="room-head-top"><div class="room-title">Tebak Kata</div><button class="room-code" onclick="leaveRoom()">X</button></div></div>';
h+='<div class="room-body">';
h+='<div class="gboard-wrap" style="text-align:center;padding:30px 20px">';
h+='<div style="font-size:3rem;letter-spacing:8px;font-family:var(--fm);color:var(--n);font-weight:900;margin-bottom:20px">'+esc(revealed)+'</div>';
if(!word){
if(room.host===CURRENT_USER){h+='<div class="info-box">Masukkan kata rahasia:</div><input class="inp" id="secretWordInput" style="text-align:center;text-transform:uppercase" maxlength="20"><button class="btn green" onclick="setSecretWord()">SET KATA</button>';}
else{h+='<div class="info-box orange">Menunggu host memilih kata...</div>';}
}else{
h+='<div class="info-box">Tebak huruf (A-Z):</div>';
h+='<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px;margin-bottom:14px">';
for(var i=65;i<=90;i++){
var ch=String.fromCharCode(i);
var used=Object.values(guesses).indexOf(ch)>=0||(s.revealed&&s.revealed.indexOf(ch)>=0);
h+='<button onclick="guessLetter(\''+ch+'\')" '+(used?'disabled':'')+' style="padding:10px 4px;background:'+(used?'rgba(10,26,16,.3)':'rgba(0,255,136,.1)')+';border:1.5px solid var(--b);border-radius:8px;color:'+(used?'#4a7059':'var(--n)')+';font-weight:900;cursor:pointer;font-family:var(--fm)">'+ch+'</button>';
}
h+='</div>';
}
h+='<button class="btn red" onclick="leaveRoom()">KELUAR</button></div></div>';
$("gameRoom").innerHTML=h;
}
window.setSecretWord=function(){var v=$("secretWordInput").value.trim().toUpperCase();if(!v||v.length<3){toast("Min 3 huruf","err");return;}db.ref("gameRooms/"+ROOM.code+"/state").update({word:v,revealed:[],guesses:{}});toast("Kata diset!","ok");};
window.guessLetter=function(ch){var s=ROOM.data.state;var word=s.word;var guesses=Object.assign({},s.guesses||{});guesses[CURRENT_USER]=ch;var revealed=s.revealed||[];if(word.indexOf(ch)>=0){if(revealed.indexOf(ch)<0)revealed.push(ch);}db.ref("gameRooms/"+ROOM.code+"/state").update({guesses:guesses,revealed:revealed}).then(function(){var solved=word.split("").every(function(c){return c===" "||revealed.indexOf(c)>=0;});if(solved){toast("KATA TERBACA!","gold");showConfetti();endGame(CURRENT_USER);}});};

function run2048(){
var board=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]];var score=0;
function addTile(){var empty=[];for(var r=0;r<4;r++)for(var c=0;c<4;c++)if(!board[r][c])empty.push({r:r,c:c});if(!empty.length)return;var p=empty[Math.floor(Math.random()*empty.length)];board[p.r][p.c]=Math.random()<0.9?2:4;}
function render(){var h='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;background:rgba(15,36,22,.5);padding:8px;border-radius:14px;max-width:300px;margin:0 auto">';var colors={2:"#a7f3d0",4:"#6ee7b7",8:"#34d399",16:"#10b981",32:"#059669",64:"#047857",128:"#065f46",256:"#064e3b",512:"#22d3ee",1024:"#06b6d4",2048:"#fbbf24"};for(var r=0;r<4;r++)for(var c=0;c<4;c++){var v=board[r][c];var bg=v?colors[v]||"var(--n)":"rgba(0,0,0,.5)";var col=v>=128?"#fff":"#000";h+='<div style="aspect-ratio:1;background:'+bg+';border-radius:8px;display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:900;font-size:'+(v>=1024?'.9rem':v>=128?'1.1rem':v>=16?'1.2rem':'1.4rem')+';color:'+col+'">'+(v||"")+'</div>';}h+='</div><div style="text-align:center;color:var(--n);font-family:var(--fd);font-weight:900;margin-top:12px">SKOR: '+score+'</div>';h+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;max-width:220px;margin:14px auto 0"><div></div><button class="btn sec" style="margin:0" onclick="g2048move(\'up\')">UP</button><div></div><button class="btn sec" style="margin:0" onclick="g2048move(\'left\')">LEFT</button><button class="btn sec" style="margin:0" onclick="g2048move(\'down\')">DOWN</button><button class="btn sec" style="margin:0" onclick="g2048move(\'right\')">RIGHT</button></div>';SA().innerHTML=h;}
function slide(row){row=row.filter(function(v){return v;});for(var i=0;i<row.length-1;i++)if(row[i]===row[i+1]){row[i]*=2;score+=row[i];row.splice(i+1,1);}while(row.length<4)row.push(0);return row;}
window.g2048move=function(dir){var old=JSON.stringify(board);if(dir==="left")for(var r=0;r<4;r++)board[r]=slide(board[r]);else if(dir==="right")for(var r2=0;r2<4;r2++)board[r2]=slide(board[r2].reverse()).reverse();else if(dir==="up")for(var c=0;c<4;c++){var col=[board[0][c],board[1][c],board[2][c],board[3][c]];col=slide(col);for(var i=0;i<4;i++)board[i][c]=col[i];}else if(dir==="down")for(var c2=0;c2<4;c2++){var col2=[board[3][c2],board[2][c2],board[1][c2],board[0][c2]];col2=slide(col2);for(var i2=0;i2<4;i2++)board[3-i2][c2]=col2[i2];}if(JSON.stringify(board)!==old)addTile();render();};
addTile();addTile();render();
}
function runMemory(){
var icons=["A","B","C","D","E","F","G","H"];var cards=[];
icons.forEach(function(ic,i){cards.push({id:i,icon:ic});cards.push({id:i,icon:ic});});
cards.sort(function(){return Math.random()-0.5;});
var flipped=[],matched=[],tries=0;
function render(){var h='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;max-width:320px;margin:0 auto">';cards.forEach(function(c,i){var isFlipped=flipped.indexOf(i)>=0||matched.indexOf(i)>=0;h+='<div onclick="memoryFlipCard('+i+')" style="aspect-ratio:1;background:'+(isFlipped?'linear-gradient(135deg,var(--n),var(--c))':'rgba(15,36,22,.7)')+';border:2px solid var(--b);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:28px;cursor:pointer">'+(isFlipped?c.icon:"?")+'</div>';});h+='</div><div style="text-align:center;color:var(--n);font-family:var(--fd);margin-top:12px">TRIES: '+tries+'</div>';SA().innerHTML=h;}
window.memoryFlipCard=function(i){if(flipped.indexOf(i)>=0||matched.indexOf(i)>=0)return;if(flipped.length>=2)return;flipped.push(i);if(flipped.length===2){tries++;var a=flipped[0],b=flipped[1];if(cards[a].id===cards[b].id){matched.push(a,b);flipped=[];render();if(matched.length===cards.length){toast("Menang! "+tries+" tries","gold");showConfetti();}}else{render();setTimeout(function(){flipped=[];render();},800);}}else render();};
render();
}
function runHangman(){
var words=["KUCING","ANJING","MOBIL","BUNGA","PISANG","LANGIT","BUMI","MATAHARI"];
var word=words[Math.floor(Math.random()*words.length)];
var guessed=[],tries=6;
function render(){var display=word.split("").map(function(c){return guessed.indexOf(c)>=0?c:"_";}).join(" ");var won=word.split("").every(function(c){return guessed.indexOf(c)>=0;});var h='<div style="text-align:center;padding:20px">';h+='<div style="font-family:var(--fd);font-size:1.8rem;color:var(--n);letter-spacing:6px;font-weight:900;margin-bottom:14px">'+esc(display)+'</div>';h+='<div style="font-size:.7rem;color:'+(tries>2?"var(--n)":"var(--r)")+';margin-bottom:14px">TRIES: '+tries+'</div>';if(won)h+='<div class="info-box">MENANG! Kata: '+word+'</div><button class="btn cyan" onclick="runHangman()">ULANG</button>';else if(tries<=0)h+='<div class="info-box red">KALAH! Kata: '+word+'</div><button class="btn cyan" onclick="runHangman()">ULANG</button>';else{h+='<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;max-width:340px;margin:0 auto">';for(var i=65;i<=90;i++){var ch=String.fromCharCode(i);var used=guessed.indexOf(ch)>=0;h+='<button onclick="hangmanGuess(\''+ch+'\')" '+(used?'disabled':'')+' style="width:36px;height:36px;background:'+(used?'rgba(10,26,16,.3)':'linear-gradient(135deg,var(--n),var(--c))')+';color:'+(used?'#666':'#000')+';border-radius:8px;font-weight:900;font-family:var(--fd);cursor:pointer;border:none">'+ch+'</button>';}h+='</div>';}SA().innerHTML=h;}
window.hangmanGuess=function(c){if(guessed.indexOf(c)>=0)return;guessed.push(c);if(word.indexOf(c)<0){tries--;toast("Salah!","err");}render();};
render();
}
function runSnake(){
SA().innerHTML='<div style="text-align:center"><canvas id="snakeCanvas" width="320" height="320" style="border:2px solid var(--n);border-radius:14px;background:#000;max-width:100%"></canvas><div id="snakeScore" style="font-family:var(--fd);color:var(--n);margin-top:10px;font-size:1.1rem;font-weight:900">SKOR: 0</div><button class="btn cyan" style="margin-top:10px" onclick="snakeStart()">MULAI</button></div>';
window.snakeStart=function(){
var cv=$("snakeCanvas"),ctx=cv.getContext("2d");
var size=16,grid=20;
var snake=[{x:10,y:10}],dir={x:1,y:0},food=randFood(),score=0,alive=true;
function randFood(){return{x:Math.floor(Math.random()*grid),y:Math.floor(Math.random()*grid)};}
function draw(){ctx.fillStyle="#000";ctx.fillRect(0,0,cv.width,cv.height);ctx.fillStyle="#00ff88";snake.forEach(function(s){ctx.fillRect(s.x*size,s.y*size,size-1,size-1);});ctx.fillStyle="#ef4444";ctx.fillRect(food.x*size,food.y*size,size-1,size-1);}
function tick(){if(!alive)return;var head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(head.x<0||head.x>=grid||head.y<0||head.y>=grid){alive=false;toast("Game Over! Skor: "+score,"err");return;}if(snake.some(function(s){return s.x===head.x&&s.y===head.y;})){alive=false;toast("Game Over! Skor: "+score,"err");return;}snake.unshift(head);if(head.x===food.x&&head.y===food.y){score+=10;food=randFood();var el=$("snakeScore");if(el)el.textContent="SKOR: "+score;}else snake.pop();draw();}
cv.onclick=function(e){var rect=cv.getBoundingClientRect();var x=e.clientX-rect.left,y=e.clientY-rect.top;var cx=cv.width/2,cy=cv.height/2;if(Math.abs(x-cx)>Math.abs(y-cy))dir=x>cx?{x:1,y:0}:{x:-1,y:0};else dir=y>cy?{x:0,y:1}:{x:0,y:-1};};
var int=setInterval(function(){if(!alive){clearInterval(int);return;}tick();},150);
draw();
};
}
function runQuizGame(){
var pool=[{q:"Ibu kota Indonesia?",o:["Jakarta","Bandung","Surabaya"],a:0},{q:"2+2x2=?",o:["6","8","4"],a:0},{q:"Planet terdekat matahari?",o:["Merkurius","Venus","Bumi"],a:0},{q:"7x8=?",o:["56","54","58"],a:0},{q:"Air membeku pada?",o:["0C","10C","100C"],a:0}];
var idx=0,score=0;
function render(){
if(idx>=pool.length){
SA().innerHTML='<div style="text-align:center;padding:30px"><div style="font-family:var(--fd);color:var(--n);font-size:1.3rem">SKOR: '+score+'/'+pool.length+'</div><button class="btn cyan" style="margin-top:14px" onclick="runQuizGame()">ULANG</button></div>';
return;
}
var q=pool[idx];
var h='<div class="quiz-wrap"><div class="quiz-q-num">SOAL '+(idx+1)+' / '+pool.length+'</div><div class="quiz-question">'+esc(q.q)+'</div><div class="quiz-options">';
q.o.forEach(function(opt,i){h+='<button class="quiz-opt" onclick="soloQuizAns('+i+')"><span class="opt-letter">'+String.fromCharCode(65+i)+'</span>'+esc(opt)+'</button>';});
h+='</div></div><div class="info-box" style="text-align:center">SKOR: <b>'+score+'</b></div>';
SA().innerHTML=h;
}
window.soloQuizAns=function(i){var q=pool[idx];if(i===q.a){score++;toast("Benar","ok");}else toast("Salah","err");idx++;setTimeout(render,600);};
render();
}
function runReactionTest(){
SA().innerHTML='<div style="text-align:center;padding:30px 20px"><div class="info-box">Test refleks. Tunggu hijau lalu tap cepat!</div><button class="btn green" onclick="reactionStart()" style="font-size:1.2rem;padding:20px">SIAP</button><div id="reactionSolo" style="margin-top:14px;min-height:100px"></div></div>';
window.reactionStart=function(){var box=$("reactionSolo");box.innerHTML='<div style="padding:30px;background:rgba(251,191,36,.2);border-radius:14px;color:var(--g)">TUNGGU...</div>';var delay=Math.random()*3000+1500;setTimeout(function(){box.innerHTML='<div onclick="reactionClick()" style="padding:40px;background:linear-gradient(135deg,var(--n),var(--n2));border-radius:14px;color:#000;font-size:1.5rem;font-weight:900;cursor:pointer">TAP!</div>';window._rStart=Date.now();},delay);};
window.reactionClick=function(){var t=Date.now()-window._rStart;$("reactionSolo").innerHTML='<div style="padding:30px;background:rgba(0,255,136,.2);border-radius:14px;color:var(--n);font-size:1.2rem">'+t+'ms</div>';};
}
function runClicker(){
var count=0,perSec=1;
function render(){SA().innerHTML='<div style="text-align:center;padding:30px 20px"><div style="font-family:var(--fd);font-size:2rem;color:var(--n);font-weight:900">'+count+'</div><div style="font-size:.7rem;color:var(--t2);margin-bottom:14px">'+perSec+' per detik</div><button class="btn green" onclick="clickerAdd()" style="font-size:1.2rem;padding:20px">TAP</button><button class="btn gold" style="margin-top:8px" onclick="clickerUpgrade()">Upgrade ('+(perSec*10)+')</button></div>';}
window.clickerAdd=function(){count++;render();};
window.clickerUpgrade=function(){if(count>=perSec*10){count-=perSec*10;perSec++;render();}};
setInterval(function(){count+=perSec;render();},1000);
render();
}
