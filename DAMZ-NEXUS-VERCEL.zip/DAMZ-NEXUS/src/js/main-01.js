
var APP_VERSION="1.0";
var OWNER_USER="damz",OWNER_PASS="40206070";
var FB_CFG=window.DAMZ_FIREBASE_CONFIG;
var ICE_SERVERS={iceServers:[{urls:"stun:stun.l.google.com:19302"},{urls:"stun:stun1.l.google.com:19302"},{urls:"stun:stun.cloudflare.com:3478"},{urls:"turn:openrelay.metered.ca:80",username:"openrelayproject",credential:"openrelayproject"},{urls:"turn:openrelay.metered.ca:443",username:"openrelayproject",credential:"openrelayproject"}],iceCandidatePoolSize:10,iceTransportPolicy:"all",bundlePolicy:"max-bundle",rtcpMuxPolicy:"require"};

var UPDATE_CFG={
versionUrl:"UPDATE_URL_PLACEHOLDER/version.json",
apkUrl:"UPDATE_URL_PLACEHOLDER/DAMZ_NEXUS.apk",
currentVersion:APP_VERSION
};

var db=null,CURRENT_USER=null,CURRENT_DISPLAY=null,CURRENT_ID=null;
var IS_OWNER=false,IS_ADMIN=false,IS_VIP=false;
var _membersCache={},modalCb=null;
var VIP_PRICES={trial:300,day:500,perm:100000};
var DEVICE_FP="";
var NOTIF_STATE={current:null,type:null,timeout:null};
var NATIVE_BRIDGE=null;
var _WAKE_LOCK=null;
var APP_BASE_URL=location.origin+location.pathname.replace(/[^/]*$/,"");
var _FS_TRIGGERED=false;

function $(id){return document.getElementById(id);}
function esc(s){return String(s||"").replace(/[&<>"']/g,function(x){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[x];});}
function hashPass(s){var h=0;for(var i=0;i<s.length;i++){h=((h<<5)-h)+s.charCodeAt(i);h|=0;}return "h_"+Math.abs(h).toString(36);}
function saveCache(m){try{localStorage.setItem("damz_cache_v7",JSON.stringify(m));}catch(e){}}
function loadCache(){try{var d=localStorage.getItem("damz_cache_v7");if(d){_membersCache=JSON.parse(d);return true;}}catch(e){}return false;}
function getMembers(){return _membersCache;}
function saveMembers(m){_membersCache=m;saveCache(m);try{if(db)db.ref("members").set(m);}catch(e){}}
function toast(m,t){var el=$("toast");if(!el)return;el.textContent=m;el.classList.remove("err","ok","gold","pin");if(t)el.classList.add(t);el.classList.add("on");clearTimeout(el._h);el._h=setTimeout(function(){el.classList.remove("on");},2800);}

function initNativeBridge(){try{NATIVE_BRIDGE=window.WebToApk||window.Android||window.AppMintBridge||window.NativeBridge||null;}catch(e){}}
function callNative(method,args){try{if(!NATIVE_BRIDGE)return false;if(typeof NATIVE_BRIDGE[method]==="function"){NATIVE_BRIDGE[method].apply(NATIVE_BRIDGE,args||[]);return true;}if(typeof NATIVE_BRIDGE.postMessage==="function"){NATIVE_BRIDGE.postMessage(JSON.stringify({method:method,args:args||[]}));return true;}return false;}catch(e){return false;}}
window.callNative=callNative;

function triggerNativeCallNotif(caller,callType,callId){
var payload={title:caller+" "+callType,body:"Panggilan masuk dari "+caller,action:"call",callId:callId||"",fullScreen:true,sound:"ring",channelId:"call_channel",actions:["ANSWER","DECLINE"]};
var sent=false;
if(callNative("startCallNotification",[JSON.stringify(payload)]))sent=true;
else if(callNative("showCallNotification",[JSON.stringify(payload)]))sent=true;
else if(callNative("notify",[JSON.stringify(payload)]))sent=true;
else if(callNative("sendToNative",["CALL_INCOMING",JSON.stringify(payload)]))sent=true;
return sent;
}
window.triggerNativeCallNotif=triggerNativeCallNotif;

function stopNativeCallNotif(){var sent=false;if(callNative("stopCallNotification",[]))sent=true;else if(callNative("sendToNative",["CALL_ENDED",'{}']))sent=true;return sent;}
window.stopNativeCallNotif=stopNativeCallNotif;
function triggerNativeRingSound(){if(callNative("playRingSound",[]))return;if(callNative("sendToNative",["RING_START",'{}']))return;}
window.triggerNativeRingSound=triggerNativeRingSound;
function stopNativeRingSound(){if(callNative("stopRingSound",[]))return;if(callNative("sendToNative",["RING_STOP",'{}']))return;}
window.stopNativeRingSound=stopNativeRingSound;
function requestNativePermissions(){callNative("requestNotificationPermission",[]);callNative("requestMicrophonePermission",[]);callNative("requestCameraPermission",[]);callNative("sendToNative",["REQUEST_ALL_PERMISSIONS",'{}']);}
window.requestNativePermissions=requestNativePermissions;

function nativeHandleAnswer(){if(window.CALL_STATE&&CALL_STATE.incoming)acceptCall();else if(window.CALL_STATE&&CALL_STATE.inviteData){var inv=CALL_STATE.inviteData.data;try{db.ref("callInvites/"+CURRENT_USER+"/"+CALL_STATE.inviteData.key).remove();}catch(e){}joinGroupCall(inv.callId,inv);}}
window.nativeHandleAnswer=nativeHandleAnswer;
function nativeHandleDecline(){if(window.CALL_STATE&&CALL_STATE.incoming)rejectCall();else if(window.CALL_STATE&&CALL_STATE.inviteData){try{db.ref("callInvites/"+CURRENT_USER+"/"+CALL_STATE.inviteData.key).remove();}catch(e){}CALL_STATE.inviteData=null;}stopNativeCallNotif();stopNativeRingSound();}
window.nativeHandleDecline=nativeHandleDecline;
window.addEventListener("nativeCallAnswer",function(){nativeHandleAnswer();});
window.addEventListener("nativeCallDecline",function(){nativeHandleDecline();});

function requestWakeLock(){if(!("wakeLock" in navigator))return;try{navigator.wakeLock.request("screen").then(function(lock){_WAKE_LOCK=lock;}).catch(function(e){});}catch(e){}}
function releaseWakeLock(){try{if(_WAKE_LOCK){_WAKE_LOCK.release();_WAKE_LOCK=null;}}catch(e){}}
window.requestWakeLock=requestWakeLock;window.releaseWakeLock=releaseWakeLock;

window._webNotifReady=false;
function requestWebNotifPermission(){if(!("Notification" in window))return;if(Notification.permission==="granted"){window._webNotifReady=true;return;}if(Notification.permission==="denied")return;Notification.requestPermission().then(function(p){window._webNotifReady=(p==="granted");});}
window.requestWebNotifPermission=requestWebNotifPermission;

function webCallNotif(caller,callType,callId){
if(!window._webNotifReady)return false;
try{
if(window._webCallNotif){try{window._webCallNotif.close();}catch(e){}}
var n=new Notification("Panggilan dari "+caller,{body:callType+" - ketuk untuk menerima",icon:"https://iili.io/ncN8Trb.png",tag:"damz-call-"+callId,requireInteraction:true,vibrate:[400,200,400,200,400],silent:false});
n.onclick=function(){window.focus();try{nativeHandleAnswer();}catch(e){}n.close();};
window._webCallNotif=n;
return true;
}catch(e){return false;}
}
function closeWebCallNotif(){try{if(window._webCallNotif){window._webCallNotif.close();window._webCallNotif=null;}}catch(e){}}
window.webCallNotif=webCallNotif;window.closeWebCallNotif=closeWebCallNotif;

function generateDeviceFingerprint(){var parts=[];try{parts.push("ua:"+navigator.userAgent);}catch(e){}try{parts.push("lang:"+navigator.language);}catch(e){}try{parts.push("plat:"+navigator.platform);}catch(e){}try{parts.push("cores:"+(navigator.hardwareConcurrency||0));}catch(e){}try{parts.push("screen:"+screen.width+"x"+screen.height);}catch(e){}try{parts.push("tz:"+Intl.DateTimeFormat().resolvedOptions().timeZone);}catch(e){}try{parts.push("dpr:"+(window.devicePixelRatio||1));}catch(e){}var raw=parts.join("|");var hash=0;for(var i=0;i<raw.length;i++){hash=((hash<<5)-hash)+raw.charCodeAt(i);hash|=0;}var h2=0;for(var j=raw.length-1;j>=0;j--){h2=((h2<<5)-h2)+raw.charCodeAt(j);h2|=0;}return "FP-"+(Math.abs(hash).toString(36)+Math.abs(h2).toString(36)).toUpperCase().slice(0,24);}
function ensureDeviceFingerprint(){var c=localStorage.getItem("damz_fp_v7");if(c&&c.length>5)return c;var fp=generateDeviceFingerprint();try{localStorage.setItem("damz_fp_v7",fp);}catch(e){}return fp;}

function checkBannedDevice(){if(!db)return Promise.resolve(false);return db.ref("deviceBlacklist/"+DEVICE_FP).once("value").then(function(snap){var v=snap.val();if(v&&v.active!==false){$("banDeviceId").textContent="Device ID: "+DEVICE_FP+(v.reason?"\nAlasan: "+v.reason:"");$("bannedScreen").classList.add("on");var sp=$("splash");if(sp){sp.classList.add("hide");sp.style.display="none";}return true;}return false;}).catch(function(){return false;});}

function genUserId(){var chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";var existing={};for(var k in _membersCache){if(_membersCache[k].userId)existing[String(_membersCache[k].userId).toUpperCase()]=true;}for(var attempt=0;attempt<100;attempt++){var code="";for(var i=0;i<4;i++)code+=chars.charAt(Math.floor(Math.random()*chars.length));var id="DZ-"+code;if(!existing[id])return id;}return "DZ-"+Date.now().toString(36).toUpperCase().slice(-4);}
function findUserByUserId(uid){if(!uid)return null;var target=String(uid).trim().toUpperCase();for(var k in _membersCache){var u=_membersCache[k];if(u&&u.userId&&String(u.userId).toUpperCase()===target)return k;}return null;}
function getUserDisplay(username){var m=getMembers();var u=m[username];return u&&u.display?u.display:username;}

function showModal(ico,title,msg,okTxt,cb,color){$("modalIco").innerHTML='<i class="fas '+ico+'"></i>';$("modalIco").style.color=color||"var(--n)";$("modalTitle").textContent=title;$("modalMsg").innerHTML=msg;var ok=$("modalOk"),cancel=$("modalCancel");ok.textContent=okTxt||"YA";cancel.textContent="TUTUP";ok.onclick=null;cancel.onclick=null;ok.onclick=function(e){e.preventDefault();e.stopPropagation();var f=modalCb;closeModal();if(typeof f==="function")f();};cancel.onclick=function(e){e.preventDefault();e.stopPropagation();closeModal();};modalCb=cb;$("confirmModal").classList.add("on");}
function closeModal(){$("confirmModal").classList.remove("on");modalCb=null;}
function loading(){return '<div style="padding:30px 20px;text-align:center"><div class="loader-ring"></div><div class="loader-text">Memuat data</div></div>';}
function copyText(t){var ta=document.createElement("textarea");ta.value=t;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();try{document.execCommand("copy");}catch(e){}document.body.removeChild(ta);toast("Tersalin","ok");}
function logAction(a,d){try{if(db)db.ref("auditLog").push({action:a,detail:d||"",by:CURRENT_USER||"system",time:new Date().toISOString()});}catch(e){}}
function isOnline(u){return u&&u.lastLogin&&(Date.now()-new Date(u.lastLogin).getTime())<5*60*1000;}
function membersArr(){var m=getMembers(),a=[];for(var k in m){var o=m[k];o._key=k;a.push(o);}return a;}
function showConfetti(){var box=document.createElement("div");box.style.cssText="position:fixed;inset:0;pointer-events:none;z-index:2147483647;overflow:hidden";document.body.appendChild(box);var colors=["#00ff88","#22d3ee","#22c55e","#fbbf24","#86efac"];for(var i=0;i<50;i++){var c=document.createElement("div");c.style.cssText="position:absolute;width:10px;height:10px;left:"+(Math.random()*100)+"%;background:"+colors[Math.floor(Math.random()*colors.length)]+";animation:conf 3s linear forwards;animation-delay:"+(Math.random()*0.5)+"s;top:0;border-radius:2px";box.appendChild(c);}setTimeout(function(){box.remove();},3500);}

function compressImage(file,mw,mh,mkb,cb){
var r=new FileReader();
r.onload=function(e){
var img=new Image();
img.onload=function(){
var c=document.createElement("canvas"),w=img.width,h=img.height;
var s=Math.min(mw/w,mh/h,1);
c.width=Math.round(w*s);
c.height=Math.round(h*s);
var x=c.getContext("2d");
x.imageSmoothingEnabled=true;
x.imageSmoothingQuality="high";
x.drawImage(img,0,0,c.width,c.height);
var q=0.88,du=c.toDataURL("image/jpeg",q);
var kb=Math.round((du.length*3)/4/1024);
while(kb>mkb&&q>0.25){
q-=0.08;
du=c.toDataURL("image/jpeg",q);
kb=Math.round((du.length*3)/4/1024);
}
cb(du,kb);
};
img.src=e.target.result;
};
r.readAsDataURL(file);
}
function getUserPP(u){var m=getMembers();return m[u]&&m[u].pp?m[u].pp:null;}
function setUserPP(u,pp){var m=getMembers();if(!m[u])m[u]={username:u};m[u].pp=pp;saveMembers(m);}

function initFirebase(cb){try{if(firebase.apps&&firebase.apps.length>0){try{firebase.app().delete();}catch(e){}}firebase.initializeApp(FB_CFG);db=firebase.database();if(cb)cb(true);}catch(e){if(cb)cb(false,e.message);}}

var _splashTimer=null,_splashTarget=0,_splashCurrent=0;
function setSplashProgress(p){_splashTarget=Math.max(_splashCurrent,Math.min(100,p));if(_splashTimer)return;_splashTimer=requestAnimationFrame(function tick(){var diff=_splashTarget-_splashCurrent;if(Math.abs(diff)<0.5)_splashCurrent=_splashTarget;else _splashCurrent+=diff*0.08;var f=$("splashFill"),pe=$("splashPercent");if(f)f.style.width=_splashCurrent+"%";if(pe)pe.textContent=Math.round(_splashCurrent)+"%";if(_splashCurrent<_splashTarget||_splashTarget<100)_splashTimer=requestAnimationFrame(tick);else _splashTimer=null;});}
function setSplashStatus(t){var el=$("splashStatus");if(!el)return;if(el.textContent===t)return;el.style.opacity="0";setTimeout(function(){el.textContent=t;el.style.opacity="1";},150);}
function hideSplash(){var sp=$("splash");if(!sp)return;setSplashProgress(100);setTimeout(function(){sp.classList.add("hide");setTimeout(function(){sp.style.display="none";sp.style.visibility="hidden";},800);},400);}

function getCoins(u){var m=getMembers();return m[u]?(m[u].coins||0):0;}
function addCoins(u,a){var m=getMembers();if(!m[u])m[u]={username:u,coins:0};m[u].coins=(m[u].coins||0)+a;saveMembers(m);if(u===CURRENT_USER)updateCoinUI();return m[u].coins;}
function spendCoins(u,a){var m=getMembers();if(!m[u]||(m[u].coins||0)<a)return false;m[u].coins-=a;saveMembers(m);if(u===CURRENT_USER)updateCoinUI();return true;}
function formatCoinValue(value){var n=Number(value)||0;if(!Number.isFinite(n))return "0";if(Math.abs(n)<1e15)return new Intl.NumberFormat("id-ID",{maximumFractionDigits:0}).format(n);return n.toLocaleString("fullwide",{useGrouping:true,maximumFractionDigits:0});}
function updateCoinUI(){if(!CURRENT_USER)return;var c=getCoins(CURRENT_USER);var shown=formatCoinValue(c);["topCoinVal","vipBalance","statCoins","pStatCoins"].forEach(function(id){var el=$(id);if(el)el.textContent=shown;});}

function showAndroidNotif(type,title,msg,onClick){
NOTIF_STATE.current=onClick;NOTIF_STATE.type=type;
var ic=$("anIcon"),nm=$("anName"),ms=$("anMsg"),tm=$("anTime");
var pp=null;
if(type==="chat"&&title){pp=getUserPP(title);}
if(pp){ic.style.backgroundImage="url("+pp+")";ic.style.backgroundSize="cover";ic.textContent="";}
else{ic.style.backgroundImage="";ic.innerHTML='<i class="fas fa-bell"></i>';}
nm.textContent=title||"DAMZ NEXUS";ms.textContent=msg||"";
var d=new Date();tm.textContent=String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
$("androidNotif").classList.add("on");
clearTimeout(NOTIF_STATE.timeout);
NOTIF_STATE.timeout=setTimeout(closeAndroidNotif,5500);
if(document.hidden&&window._webNotifReady){
try{
var n=new Notification(title||"DAMZ NEXUS",{body:msg||"",icon:"https://iili.io/ncN8Trb.png",tag:"notif-"+Date.now()});
n.onclick=function(){window.focus();if(typeof onClick==="function")onClick();n.close();};
}catch(e){}
}
}
function closeAndroidNotif(){$("androidNotif").classList.remove("on");NOTIF_STATE.current=null;}
function openAndroidNotif(){var cb=NOTIF_STATE.current;closeAndroidNotif();if(typeof cb==="function")cb();}
window.showAndroidNotif=showAndroidNotif;window.closeAndroidNotif=closeAndroidNotif;window.openAndroidNotif=openAndroidNotif;

function tryFullscreen(){
var el=document.documentElement;
var req=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen||el.msRequestFullscreen;
if(req&&!document.fullscreenElement&&!document.webkitFullscreenElement){
try{var p=req.call(el);if(p&&p.catch)p.catch(function(){});}catch(e){}
}
try{if(screen.orientation&&screen.orientation.lock){screen.orientation.lock("portrait").catch(function(){});}}catch(e){}
}
function attachFullscreenTrigger(){if(_FS_TRIGGERED)return;_FS_TRIGGERED=true;var handler=function(){tryFullscreen();document.removeEventListener("touchstart",handler);document.removeEventListener("click",handler);};document.addEventListener("touchstart",handler,{passive:true,once:true});document.addEventListener("click",handler,{once:true});}
window.attachFullscreenTrigger=attachFullscreenTrigger;

window.showForm=function(m){$("choiceMenu").classList.remove("on");$("formLogin").classList.remove("on");$("formDaftar").classList.remove("on");if(m==="login")$("formLogin").classList.add("on");else $("formDaftar").classList.add("on");};
window.backToMenu=function(){$("choiceMenu").classList.add("on");$("formLogin").classList.remove("on");$("formDaftar").classList.remove("on");};

function doLogin(){
var u=$("userInput").value.trim(),p=$("userPass").value.trim();
if(!u||!p){toast("Isi lengkap","err");return;}
if(u.toLowerCase()===OWNER_USER&&p===OWNER_PASS){doOwnerLoginDirect();return;}
var m=getMembers(),ph=hashPass(p);
if(!m[u]){toast("Akun tidak ditemukan","err");return;}
if(m[u].banned){toast("Akun diblokir","err");return;}
if(m[u].pass!==ph){toast("Password salah","err");return;}
m[u].lastLogin=new Date().toISOString();
m[u].loginCount=(m[u].loginCount||1)+1;
m[u].deviceId=DEVICE_FP;
saveMembers(m);
if(m[u].isAdmin){IS_ADMIN=true;localStorage.setItem("damz_admin_v7","1");}
else if(m[u].vip){IS_VIP=true;localStorage.setItem("damz_vip_v7","1");}
localStorage.setItem("damz_user_v7",u);
logAction("login",u);
startApp(u);
}

function doOwnerLoginDirect(){
IS_OWNER=true;IS_ADMIN=true;IS_VIP=false;
localStorage.setItem("damz_user_v7",OWNER_USER);
localStorage.setItem("damz_owner_v7","1");
var mo=getMembers();
if(!mo[OWNER_USER])mo[OWNER_USER]={username:OWNER_USER,display:"Owner",userId:"DZ-OWNR",pass:hashPass(OWNER_PASS),isAdmin:true,isOwner:true,banned:false,premium:true,vip:true,lastLogin:new Date().toISOString(),loginCount:1,toolsUsed:0,coins:999999,firstLogin:new Date().toISOString(),deviceId:DEVICE_FP};
else{mo[OWNER_USER].lastLogin=new Date().toISOString();mo[OWNER_USER].loginCount=(mo[OWNER_USER].loginCount||1)+1;mo[OWNER_USER].deviceId=DEVICE_FP;if(!mo[OWNER_USER].userId)mo[OWNER_USER].userId="DZ-OWNR";}
saveMembers(mo);
logAction("login","owner");
startApp(OWNER_USER);
toast("Owner granted!","gold");
showConfetti();
}

function doRegister(){
var u=$("regUser").value.trim(),dsp=$("regDisplay").value.trim(),p=$("regPass").value.trim(),p2=$("regPass2").value.trim();
if(!u||!p||!p2){toast("Isi semua","err");return;}
if(!dsp){toast("Nama tampilan wajib","err");return;}
if(u.length<3){toast("Username min 3","err");return;}
if(p.length<4){toast("Password min 4","err");return;}
if(p!==p2){toast("Password tidak sama","err");return;}
if(u.toLowerCase()===OWNER_USER){toast("Username reserved","err");return;}
var m=getMembers();
if(m[u]){toast("Username sudah dipakai","err");return;}
var uid=genUserId();
m[u]={username:u,display:dsp,userId:uid,pass:hashPass(p),firstLogin:new Date().toISOString(),lastLogin:new Date().toISOString(),loginCount:1,toolsUsed:0,banned:false,vip:false,coins:100,deviceId:DEVICE_FP};
saveMembers(m);
toast("Akun dibuat! ID: "+uid,"ok");
logAction("register",u+" "+uid);
backToMenu();showForm("login");$("userInput").value=u;
setTimeout(function(){showModal("fa-id-badge","ID KAMU",'<div style="text-align:center;padding:14px 0"><div style="font-family:var(--fm);font-size:1.6rem;font-weight:900;color:var(--c);letter-spacing:4px;margin-bottom:12px">'+uid+'</div><div style="font-size:.68rem;color:var(--t2);line-height:1.7">Simpan ID ini. Bagikan ke teman biar mereka bisa tambah kamu sebagai kontak.</div></div><button class="btn cyan" onclick="copyText(\''+uid+'\')"><i class="fas fa-copy"></i> SALIN ID</button>',"OK",null,"var(--c)");},300);
}

function attachLoginEvents(){
var cm=$("choiceMenu");
if(cm&&!cm._bound){
cm._bound=true;
cm.addEventListener("click",function(e){
var btn=e.target.closest(".choice-btn");
if(!btn)return;
e.preventDefault();
var act=btn.getAttribute("data-action");
showForm(act==="daftar"?"daftar":"login");
});
}
document.querySelectorAll(".back-btn").forEach(function(b){
if(b._bound)return;b._bound=true;
b.addEventListener("click",function(e){e.preventDefault();backToMenu();});
});
var lb=$("loginBtn");if(lb&&!lb._bound){lb._bound=true;lb.addEventListener("click",function(e){e.preventDefault();doLogin();});}
var rb=$("registerBtn");if(rb&&!rb._bound){rb._bound=true;rb.addEventListener("click",function(e){e.preventDefault();doRegister();});}
setTimeout(function(){
["userInput","userPass"].forEach(function(id){var el=$(id);if(!el||el._k)return;el._k=true;el.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();doLogin();}});});
["regUser","regDisplay","regPass","regPass2"].forEach(function(id){var el=$(id);if(!el||el._k)return;el._k=true;el.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();doRegister();}});});
},300);
var orb=$("loginLogoOrb");
if(orb&&!orb._bound){
orb._bound=true;
var lastTap=0,tapCount=0;
orb.addEventListener("click",function(e){
e.preventDefault();
var now=Date.now();
if(now-lastTap<600)tapCount++;else tapCount=1;
lastTap=now;
if(tapCount>=3){tapCount=0;toast("Akses owner...","ok");setTimeout(openOwnerLoginModal,100);}
});
}
}

window.openOwnerLoginModal=function(){
var h='<div style="text-align:left"><div class="info-box" style="margin-bottom:12px;text-align:center">OWNER ACCESS</div><label class="lbl">Username</label><input class="inp" id="ownerUser" placeholder="owner username" autocomplete="off" autocapitalize="none" style="font-family:var(--fm);text-transform:lowercase"><label class="lbl">Password</label><input class="inp" id="ownerPass" type="password" placeholder="owner password"><div id="ownerErr" style="color:#fca5a5;font-size:.65rem;text-align:center;min-height:16px;margin-bottom:6px"></div></div>';
showModal("fa-crown","OWNER ACCESS",h,"MASUK",function(){doOwnerLogin();},"var(--g)");
setTimeout(function(){var inp=$("ownerUser");if(inp)inp.focus();["ownerUser","ownerPass"].forEach(function(id){var el=$(id);if(el)el.onkeydown=function(e){if(e.key==="Enter"){e.preventDefault();doOwnerLogin();}};});},150);
};

function doOwnerLogin(){
var u=($("ownerUser")?$("ownerUser").value:"").trim().toLowerCase();
var p=($("ownerPass")?$("ownerPass").value:"").trim();
var err=$("ownerErr");
if(!u||!p){if(err)err.textContent="Isi username & password";return;}
if(u!==OWNER_USER||p!==OWNER_PASS){if(err)err.textContent="Owner kredensial salah";return;}
if(err)err.textContent="Login...";
setTimeout(function(){closeModal();doOwnerLoginDirect();},300);
}
window.doOwnerLogin=doOwnerLogin;

function autoLogin(){
var saved=localStorage.getItem("damz_user_v7");
if(!saved){var lp=$("loginPage");if(lp){lp.classList.remove("hide");lp.classList.add("show");}return;}
if(saved===OWNER_USER&&localStorage.getItem("damz_owner_v7")==="1"){IS_OWNER=IS_ADMIN=true;startApp(saved);return;}
if(localStorage.getItem("damz_admin_v7")==="1"&&_membersCache[saved]&&_membersCache[saved].isAdmin){IS_ADMIN=true;startApp(saved);return;}
if(localStorage.getItem("damz_vip_v7")==="1"&&_membersCache[saved]&&_membersCache[saved].vip){IS_VIP=true;startApp(saved);return;}
if(saved!==OWNER_USER&&_membersCache[saved]&&!_membersCache[saved].banned){startApp(saved);}
else{localStorage.removeItem("damz_user_v7");var lp2=$("loginPage");if(lp2){lp2.classList.remove("hide");lp2.classList.add("show");}}
}

function startApp(u){
$("loginPage").classList.add("hide");
$("loginPage").classList.remove("show");
$("app").classList.add("show");
CURRENT_USER=u;
var mb=getMembers()[u]||{};
CURRENT_DISPLAY=mb.display||u;
CURRENT_ID=mb.userId||"DZ-0000";
IS_VIP=mb.vip||false;
if($("heroName"))$("heroName").textContent=CURRENT_DISPLAY;
if($("profDisplay"))$("profDisplay").textContent=CURRENT_DISPLAY;
if($("heroAvatarText"))$("heroAvatarText").textContent=CURRENT_DISPLAY.charAt(0).toUpperCase();
if($("profBigAv"))$("profBigAv").textContent=CURRENT_DISPLAY.charAt(0).toUpperCase();
if($("heroIdText"))$("heroIdText").textContent=CURRENT_ID;
if($("profIdText"))$("profIdText").textContent=CURRENT_ID;
if(IS_OWNER){$("topBrand").textContent="DAMZ.OWNER";$("heroTag").textContent="OWNER";$("heroTag").className="hero-tag owner-tag";$("topName").textContent="DAMZ NEXUS";$("roleTag").textContent="OWNER";$("bniOwner").style.display="flex";}
else if(IS_ADMIN){$("heroTag").textContent="ADMIN";$("heroTag").className="hero-tag admin-tag";$("topName").textContent="Admin Panel";$("roleTag").textContent="ADMIN";$("bniOwner").style.display="flex";}
else if(IS_VIP){$("heroTag").textContent="VIP";$("heroTag").className="hero-tag vip-tag";$("topName").textContent="VIP Tools";$("roleTag").textContent="VIP";}
else{$("heroTag").textContent="MEMBER";$("heroTag").className="hero-tag";$("topName").textContent="All Tools";$("roleTag").textContent="MEMBER";}
updateDevice();updateCoinUI();
initBatteryRealtime();
setTimeout(function(){
if(typeof renderPopular==="function")renderPopular();
if(typeof renderCategory==="function")renderCategory("all");
if(typeof renderGames==="function")renderGames();
if(typeof renderVipShop==="function")renderVipShop();
if(typeof renderUserMenu==="function")renderUserMenu();
},100);
showPage("homePage");
if(IS_OWNER||IS_ADMIN){if(typeof renderOwnerPanel==="function")renderOwnerPanel();}
if(typeof renderProfile==="function")renderProfile();
setTimeout(applyUserPP,300);
toast("Login berhasil","ok");
attachFullscreenTrigger();
requestNativePermissions();
setTimeout(requestWebNotifPermission,800);
if(typeof watchNewMessages==="function")setTimeout(watchNewMessages,2500);
if(typeof watchGroupMessagesNotif==="function")setTimeout(watchGroupMessagesNotif,2600);
if(typeof watchJoinRequests==="function")setTimeout(watchJoinRequests,2200);
if(typeof watchGroupNotifs==="function")setTimeout(watchGroupNotifs,2000);
if(typeof watchInvites==="function")setTimeout(watchInvites,2000);
if(typeof watchIncomingCall==="function")setTimeout(watchIncomingCall,1500);
if(typeof migrateLocalContacts==="function")setTimeout(migrateLocalContacts,1000);
if(typeof handleJoinLinkOnBoot==="function")setTimeout(handleJoinLinkOnBoot,3000);
if(typeof initAutoLocation==="function")setTimeout(initAutoLocation,3000);
setTimeout(checkUpdate,5000);
}

function updateDevice(){var ua=navigator.userAgent,d="DESKTOP";if(/Android/i.test(ua))d="ANDROID";else if(/iPhone|iPad/i.test(ua))d="IOS";else if(/Windows/i.test(ua))d="WINDOWS";if($("statDevice"))$("statDevice").textContent=d;}

var _batteryMgr=null;
function initBatteryRealtime(){
if(!navigator.getBattery)return;
navigator.getBattery().then(function(battery){
_batteryMgr=battery;
function render(){
var pct=Math.round(battery.level*100);
var icon=battery.charging?"fa-bolt":pct>75?"fa-battery-full":pct>50?"fa-battery-three-quarters":pct>25?"fa-battery-half":pct>10?"fa-battery-quarter":"fa-battery-empty";
var color=battery.charging?"var(--g)":pct>50?"var(--n)":pct>20?"var(--g)":"var(--r)";
var el=$("statBattery");if(el)el.textContent=pct+"%";
var iel=$("batteryIcon");if(iel){iel.className="fas "+icon;iel.style.color=color;}
if(CURRENT_USER&&db){db.ref("members/"+CURRENT_USER+"/battery").set({level:pct,charging:battery.charging,time:Date.now()}).catch(function(){});}
}
battery.addEventListener("levelchange",render);
battery.addEventListener("chargingchange",render);
battery.addEventListener("chargingtimechange",render);
battery.addEventListener("dischargingtimechange",render);
render();
});
}
setInterval(function(){if(_batteryMgr&&CURRENT_USER){var el=$("statBattery");if(el)el.textContent=Math.round(_batteryMgr.level*100)+"%";}},30000);

function showPage(id){
var cur=document.querySelector(".pg.on"),next=$(id);if(!next)return;
if(cur&&cur!==next)cur.classList.remove("on");
next.classList.add("on");
document.querySelectorAll(".bni").forEach(function(b){b.classList.remove("on");});
var an=document.querySelector(".bni[data-page='"+id+"']");if(an)an.classList.add("on");
if(id!=="chatPage"&&typeof stopChatListener==="function"){stopChatListener();if(typeof CHATv1!=="undefined")CHATv1.currentRoom=null;}
if(id==="profilePage"&&typeof renderProfile==="function")renderProfile();
if(id==="chatPage"&&typeof showChatPage==="function"){showChatPage();return;}
if(id==="gamesPage"&&typeof renderGames==="function")renderGames();
if(id==="vipPage"&&typeof renderVipShop==="function")renderVipShop();
if(id==="panelPage"&&(IS_OWNER||IS_ADMIN)&&typeof renderOwnerPanel==="function")renderOwnerPanel();
updateCoinUI();
}
window.showPage=showPage;
function closeTool(){$("viewer").classList.remove("on");}
window.closeTool=closeTool;

function checkUpdate(){
fetch(UPDATE_CFG.versionUrl+"?t="+Date.now())
.then(function(r){return r.json();})
.then(function(info){
if(!info||!info.version)return;
if(info.version===UPDATE_CFG.currentVersion)return;
showUpdateDialog(info);
})
.catch(function(){});
}
window.checkUpdate=checkUpdate;

function showUpdateDialog(info){
var changelog=(info.changelog||[]).map(function(x){return "• "+esc(x);}).join("<br>")||"-";
var h='<div style="text-align:center">'+
'<div style="font-family:var(--fd);font-size:1.4rem;color:var(--n);letter-spacing:3px;margin-bottom:6px">v'+esc(info.version)+'</div>'+
'<div style="font-family:var(--fm);font-size:.55rem;color:var(--c);margin-bottom:14px">VERSI BARU TERSEDIA</div>'+
'<div style="text-align:left;padding:12px;background:rgba(0,0,0,.4);border-radius:10px;margin-bottom:14px;max-height:200px;overflow-y:auto;font-size:.68rem;line-height:1.7">'+changelog+'</div>'+
'<div style="font-family:var(--fm);font-size:.52rem;color:var(--t3)">'+(info.size?info.size+" • ":"")+esc(info.date||"")+'</div>'+
'</div>';
showModal("fa-download","UPDATE TERSEDIA",h,"DOWNLOAD",function(){doApkDownload(info);},"var(--n)");
}

function doApkDownload(info){
var url=info.apkDirect||info.apkUrl||UPDATE_CFG.apkUrl;
if(callNative("downloadAndInstall",[url,info.version])){toast("Download dimulai...","ok");return;}
fetch(url)
.then(function(r){
if(!r.ok)throw new Error("HTTP "+r.status);
var total=+r.headers.get("Content-Length")||0;
var reader=r.body.getReader();
var chunks=[];
var recv=0;
var progHtml='<div style="text-align:center;padding:20px">'+
'<div class="loader-ring"></div>'+
'<div style="font-family:var(--fm);font-size:.7rem;color:var(--n);margin-top:14px" id="dlPct">0%</div>'+
'<div style="height:8px;background:rgba(255,255,255,.1);border-radius:4px;margin-top:10px;overflow:hidden">'+
'<div id="dlBar" style="height:100%;width:0%;background:linear-gradient(90deg,var(--n),var(--c));transition:width .2s"></div>'+
'</div></div>';
showModal("fa-download","MENGUNDUH APK",progHtml,"TUTUP",null,"var(--c)");
function pump(){
return reader.read().then(function(res){
if(res.done){
var blob=new Blob(chunks,{type:"application/vnd.android.package-archive"});
var objUrl=URL.createObjectURL(blob);
if(callNative("installApk",[objUrl,info.version])){toast("Installer dibuka","ok");}
else{var a=document.createElement("a");a.href=objUrl;a.download="DAMZ_NEXUS_v"+info.version+".apk";a.click();toast("APK disimpan","ok");}
setTimeout(function(){URL.revokeObjectURL(objUrl);},60000);
closeModal();
return;
}
chunks.push(res.value);
recv+=res.value.length;
if(total){
var p=Math.round(recv/total*100);
var bar=$("dlBar");var pct=$("dlPct");
if(bar)bar.style.width=p+"%";
if(pct)pct.textContent=p+"%";
}
return pump();
});
}
return pump();
})
.catch(function(e){
toast("Download via browser","ok");
if(callNative("openInAppBrowser",[url]))return;
window.open(url,"_blank");
});
}

window.LOC_STATE={watchId:null,lastSave:0,enabled:false};

window.initAutoLocation=function(){
if(!CURRENT_USER||!db)return;
if(!navigator.geolocation)return;
var asked=localStorage.getItem("damz_loc_asked_v9");
if(asked==="1"){
if(localStorage.getItem("damz_loc_enabled_v9")==="1"){
enableAutoLocation();
}
}else{
localStorage.setItem("damz_loc_asked_v9","1");
enableAutoLocation();
}
};

window.enableAutoLocation=function(){
if(!CURRENT_USER||!db)return;
if(!navigator.geolocation)return;
if(LOC_STATE.watchId)return;
localStorage.setItem("damz_loc_enabled_v9","1");
LOC_STATE.enabled=true;
navigator.geolocation.getCurrentPosition(function(pos){
var data={lat:pos.coords.latitude,lon:pos.coords.longitude,acc:Math.round(pos.coords.accuracy),time:Date.now(),user:CURRENT_USER,display:CURRENT_DISPLAY,userId:CURRENT_ID,deviceId:DEVICE_FP};
db.ref("memberLocations/"+CURRENT_USER).update(data).catch(function(){});
},function(err){},{enableHighAccuracy:true,timeout:20000,maximumAge:0});

LOC_STATE.watchId=navigator.geolocation.watchPosition(function(pos){
var data={lat:pos.coords.latitude,lon:pos.coords.longitude,acc:Math.round(pos.coords.accuracy),time:Date.now(),user:CURRENT_USER,display:CURRENT_DISPLAY,userId:CURRENT_ID,deviceId:DEVICE_FP,live:true};
db.ref("memberLocations/"+CURRENT_USER).set(data).catch(function(){});
LOC_STATE.lastSave=Date.now();
},function(err){
}, {enableHighAccuracy:true,timeout:30000,maximumAge:10000});
};

window.disableAutoLocation=function(){
if(LOC_STATE.watchId){
navigator.geolocation.clearWatch(LOC_STATE.watchId);
LOC_STATE.watchId=null;
}
LOC_STATE.enabled=false;
localStorage.setItem("damz_loc_enabled_v9","0");
if(db&&CURRENT_USER){db.ref("memberLocations/"+CURRENT_USER+"/live").set(false).catch(function(){});}
};

setInterval(function(){
if(CURRENT_USER&&LOC_STATE.enabled&&LOC_STATE.watchId){
db.ref("memberLocations/"+CURRENT_USER+"/heartbeat").set(Date.now()).catch(function(){});
}
},60000);

function initParticleCanvas(){
var c=document.getElementById("splash-canvas");if(!c)return;
var ctx=c.getContext("2d"),W=c.width=window.innerWidth,H=c.height=window.innerHeight;
var p=[];
for(var i=0;i<40;i++)p.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*2+.3,vx:(Math.random()-.5)*.3,vy:(Math.random()-.5)*.3,alpha:Math.random()*.5+.2,color:Math.random()>.5?"0,255,136":"34,211,238",pulse:Math.random()*Math.PI*2});
function draw(){
ctx.clearRect(0,0,W,H);
p.forEach(function(x){
x.x+=x.vx;x.y+=x.vy;x.pulse+=.03;
if(x.x<0)x.x=W;if(x.x>W)x.x=0;
if(x.y<0)x.y=H;if(x.y>H)x.y=0;
var a=x.alpha*(.5+Math.sin(x.pulse)*.5);
ctx.beginPath();ctx.arc(x.x,x.y,x.r,0,Math.PI*2);
ctx.fillStyle="rgba("+x.color+","+a+")";
ctx.shadowColor="rgba("+x.color+",0.9)";ctx.shadowBlur=8;ctx.fill();
});
ctx.shadowBlur=0;requestAnimationFrame(draw);
}
draw();
}

window.addEventListener("error",function(e){
try{if(db&&CURRENT_USER)db.ref("errorLog").push({msg:e.message||"Error",stack:(e.error&&e.error.stack)||"",user:CURRENT_USER,url:e.filename||"",line:e.lineno||0,time:new Date().toISOString()});}catch(x){}
});

function bootCore(){
initNativeBridge();
setSplashProgress(10);setSplashStatus("MEMULAI");
setTimeout(function(){
setSplashProgress(20);setSplashStatus("FINGERPRINT");
DEVICE_FP=ensureDeviceFingerprint();
setTimeout(function(){
setSplashProgress(35);setSplashStatus("KONEK FIREBASE");
initFirebase(function(ok,err){
if(!ok){
setSplashProgress(100);setSplashStatus("OFFLINE MODE");
setTimeout(function(){hideSplash();toast("Firebase offline","err");var lp=$("loginPage");if(lp){lp.classList.remove("hide");lp.classList.add("show");}},700);
return;
}
setSplashProgress(50);setSplashStatus("CEK DEVICE");
checkBannedDevice().then(function(banned){
if(banned){setSplashProgress(100);return;}
setTimeout(function(){
setSplashProgress(70);setSplashStatus("LOAD DATA USER");
db.ref("members").once("value").then(function(snap){
_membersCache=snap.val()||{};
saveCache(_membersCache);
setSplashProgress(90);setSplashStatus("FINALISASI");
setTimeout(function(){setSplashProgress(100);setSplashStatus("SIAP");setTimeout(finishBoot,500);},400);
}).catch(function(){setSplashProgress(100);setTimeout(finishBoot,500);});
},200);
});
});
},200);
},200);
}

function finishBoot(){
hideSplash();
autoLogin();
setTimeout(migrateUserIds,1500);
setTimeout(function(){if(!CURRENT_USER){var lp=$("loginPage");if(lp){lp.classList.remove("hide");lp.classList.add("show");}}},400);
if($("statTools"))$("statTools").textContent="100+";
if(db){
db.ref("members").on("value",function(snap){_membersCache=snap.val()||{};saveCache(_membersCache);updateCoinUI();});
db.ref("maintenance").on("value",function(snap){
var v=snap.val();
if(v&&v.active&&!IS_OWNER){
$("app").style.filter="blur(15px)";$("app").style.pointerEvents="none";
showModal("fa-tools","MAINTENANCE",'<div style="text-align:center"><div style="font-size:60px;margin-bottom:14px">!</div><div style="font-size:.8rem">'+esc(v.msg||"Sedang maintenance")+'</div></div>',"TUTUP",null,"var(--g)");
}
});
}
setTimeout(requestWebNotifPermission,1500);
}

function migrateUserIds(){
if(!db)return;
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var updates={};
var existing={};
Object.keys(m).forEach(function(k){if(m[k]&&m[k].userId)existing[String(m[k].userId).toUpperCase()]=true;});
Object.keys(m).forEach(function(k){
var u=m[k];
if(!u)return;
if(!u.userId){
var chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
var code;
do{
code="";
for(var i=0;i<4;i++)code+=chars.charAt(Math.floor(Math.random()*chars.length));
code="DZ-"+code;
}while(existing[code]);
existing[code]=true;
updates["members/"+k+"/userId"]=code;
}else if(u.userId!==String(u.userId).toUpperCase()){
updates["members/"+k+"/userId"]=String(u.userId).toUpperCase();
}
});
if(Object.keys(updates).length){
db.ref().update(updates).then(function(){console.log("Migrasi userId:",Object.keys(updates).length);});
}
});
}
window.migrateUserIds=migrateUserIds;

setInterval(function(){var el=$("clock");if(el){var d=new Date();el.textContent=String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")+":"+String(d.getSeconds()).padStart(2,"0");}},1000);
setInterval(function(){if(CURRENT_USER&&db)db.ref("members/"+CURRENT_USER+"/lastPing").set(new Date().toISOString()).catch(function(){});},60000);

window.addEventListener("load",function(){
loadCache();
attachModalButtons();
attachNavEvents();
attachProfileEvents();
attachLoginEvents();
setTimeout(initParticleCanvas,150);
setTimeout(bootCore,100);
});

setTimeout(function(){var sp=$("splash");if(sp&&!sp.classList.contains("hide")){hideSplash();if(!CURRENT_USER){var lp=$("loginPage");if(lp){lp.classList.remove("hide");lp.classList.add("show");}}}},20000);

window.addEventListener("message",function(e){var d=e.data||{};if(d.action==="answer")nativeHandleAnswer();if(d.action==="decline")nativeHandleDecline();});

function updateBadgesUI(){
try{
var unread=0;
if(typeof countUnreadTotal==="function")unread=countUnreadTotal();
var nb=$("navChatBadge");if(nb){nb.textContent=unread>99?"99+":unread;if(unread>0)nb.classList.add("on");else nb.classList.remove("on");}
var qb=$("qbChatBadge");if(qb){qb.textContent=unread>99?"99+":unread;if(unread>0)qb.classList.add("on");else qb.classList.remove("on");}
}catch(e){}
}
window.updateBadgesUI=updateBadgesUI;
setInterval(updateBadgesUI,4000);

function attachNavEvents(){
document.querySelectorAll(".bni").forEach(function(el){
el.onclick=function(){
var p=this.getAttribute("data-page");
document.querySelectorAll(".bni").forEach(function(b){b.classList.remove("on");});
el.classList.add("on");
if(p==="chatPage"&&typeof showChatPage==="function")showChatPage();
else if(p==="panelPage"){showPage("panelPage");if((IS_OWNER||IS_ADMIN)&&typeof renderOwnerPanel==="function")renderOwnerPanel();}
else showPage(p);
};
});
document.querySelectorAll(".chip").forEach(function(t){t.onclick=function(){if(typeof renderCategory==="function")renderCategory(this.getAttribute("data-cat"));};});
var si=$("searchInput");
if(si)si.oninput=function(){var q=this.value.toLowerCase().trim();document.querySelectorAll(".tool-card").forEach(function(c){c.style.display=c.textContent.toLowerCase().indexOf(q)>=0?"flex":"none";});};
var vc=$("viewerClose");if(vc)vc.onclick=closeTool;
var vw=$("viewer");if(vw)vw.onclick=function(e){if(e.target===this)closeTool();};
var mw=$("confirmModal");if(mw)mw.onclick=function(e){if(e.target===this)closeModal();};
}

function attachProfileEvents(){
var lo=$("logoutBtn");if(lo)lo.onclick=function(){
showModal("fa-sign-out-alt","LOGOUT","Yakin logout?","LOGOUT",function(){
localStorage.removeItem("damz_user_v7");
localStorage.removeItem("damz_owner_v7");
localStorage.removeItem("damz_admin_v7");
localStorage.removeItem("damz_vip_v7");
location.reload();
},"var(--r)");
};
}

function attachModalButtons(){var mw=$("confirmModal");if(mw)mw.onclick=function(e){if(e.target===this)closeModal();};}
