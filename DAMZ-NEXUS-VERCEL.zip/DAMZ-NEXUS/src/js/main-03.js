
window.CHATv1={currentRoom:null,listeners:{},unread:0,pinnedMessage:null};
window.VOICE_REC={rec:null,chunks:[],stream:null,isRec:false,startTime:0,timer:null};
var LAST_MSG_COUNT=0;
var TYPING_TIMEOUT=null;
var GRP_CACHE={};

function chatRoomKey(a,b){var s=[a,b].sort();return "dm_"+s[0]+"__"+s[1];}
function chatGetContacts(){try{return JSON.parse(localStorage.getItem("damz_contacts_v6_"+CURRENT_USER)||"[]");}catch(e){return[];}}
function chatSaveContacts(l){try{localStorage.setItem("damz_contacts_v6_"+CURRENT_USER,JSON.stringify(l));}catch(e){}}
function chatAddContact(username,alias){var c=chatGetContacts();var existing=c.filter(function(x){return x.u===username;})[0];if(existing){if(alias!==undefined)existing.alias=alias;chatSaveContacts(c);return true;}c.unshift({u:username,alias:alias||"",t:Date.now()});chatSaveContacts(c);return true;}
function chatRemoveContact(username){var c=chatGetContacts().filter(function(x){return x.u!==username;});chatSaveContacts(c);}
function chatGetContact(username){var c=chatGetContacts();return c.filter(function(x){return x.u===username;})[0]||null;}
function chatDisplayName(username){var c=chatGetContact(username);if(c&&c.alias)return c.alias;return getUserDisplay(username);}
function chatFmtTime(iso){if(!iso)return"";var d=new Date(iso),t=new Date();if(d.toDateString()===t.toDateString())return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");return d.toLocaleDateString("id-ID",{day:"2-digit",month:"short"})+" "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");}
function avatarHTML(u,s){s=s||46;var pp=getUserPP(u);if(pp)return '<div style="width:'+s+'px;height:'+s+'px;border-radius:14px;background-image:url('+pp+');background-size:cover;background-position:center;flex-shrink:0"></div>';var d=getUserDisplay(u);return '<div style="width:'+s+'px;height:'+s+'px;border-radius:14px;background:linear-gradient(135deg,var(--n),var(--n2));color:#000;display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:900;font-size:'+(s*0.4)+'px;flex-shrink:0">'+String(d||"?").charAt(0).toUpperCase()+'</div>';}
window.avatarHTML=avatarHTML;

function getPinnedChats(){try{return JSON.parse(localStorage.getItem("damz_pinned_chats_v7_"+CURRENT_USER)||"[]");}catch(e){return[];}}
function savePinnedChats(l){try{localStorage.setItem("damz_pinned_chats_v7_"+CURRENT_USER,JSON.stringify(l));}catch(e){}}
function isPinnedChat(id){return getPinnedChats().indexOf(id)>=0;}
function togglePinChat(id){var p=getPinnedChats();var idx=p.indexOf(id);if(idx>=0){p.splice(idx,1);toast("Chat di-unpin","ok");}else{p.unshift(id);toast("Chat di-pin","pin");}savePinnedChats(p);return idx<0;}
window.getPinnedChats=getPinnedChats;window.savePinnedChats=savePinnedChats;window.isPinnedChat=isPinnedChat;window.togglePinChat=togglePinChat;

function getBlockedList(){try{var m=getMembers();return (m[CURRENT_USER]&&m[CURRENT_USER].blocked)||[];}catch(e){return[];}}
function isBlocked(u){return getBlockedList().indexOf(u)>=0;}
function toggleBlock(u){var m=getMembers();if(!m[CURRENT_USER])m[CURRENT_USER]={username:CURRENT_USER};if(!m[CURRENT_USER].blocked)m[CURRENT_USER].blocked=[];var arr=m[CURRENT_USER].blocked.slice();if(arr.indexOf(u)>=0)arr=arr.filter(function(x){return x!==u;});else arr.push(u);m[CURRENT_USER].blocked=arr;saveMembers(m);return arr.indexOf(u)>=0;}
window.getBlockedList=getBlockedList;window.isBlocked=isBlocked;window.toggleBlock=toggleBlock;

window.showBlockedList=function(){
var bl=getBlockedList();
var h='<div style="text-align:left;max-height:400px;overflow-y:auto">';
if(!bl.length)h+='<div class="empty-box"><i class="fas fa-user-check"></i>Tidak ada kontak diblokir</div>';
else bl.forEach(function(u){var m=getMembers();h+='<div class="member-item"><div class="member-av">'+getUserDisplay(u).charAt(0).toUpperCase()+'</div><div class="member-info"><div class="member-name">'+esc(getUserDisplay(u))+' <span class="member-badge blocked-b">BLOCKED</span></div><div class="member-meta">'+esc(m[u]?m[u].userId||"":"")+'</div></div><button class="mact grn" onclick="unblockUser(\''+esc(u)+'\')"><i class="fas fa-unlock"></i> BUKA</button></div>';});
h+='</div>';
showModal("fa-ban","KONTAK DIBLOKIR",h,"TUTUP",null,"var(--r)");
};

window.unblockUser=function(u){showModal("fa-unlock","BUKA BLOKIR","Buka blokir <b>"+esc(getUserDisplay(u))+"</b>?","BUKA",function(){toggleBlock(u);toast("Blokir dibuka","ok");closeModal();if(typeof renderChatList==="function")renderChatList();showBlockedList();},"var(--n)");};

function countUnreadTotal(){
var total=0;
try{
var contacts=chatGetContacts();
contacts.forEach(function(c){
var rk=chatRoomKey(CURRENT_USER,c.u);
var cnt=parseInt(localStorage.getItem("damz_unread_"+rk)||"0");
total+=cnt;
});
var groups=groupGetList();
groups.forEach(function(g){
var cnt=parseInt(localStorage.getItem("damz_unread_grp_"+g.id)||"0");
total+=cnt;
});
}catch(e){}
return total;
}
window.countUnreadTotal=countUnreadTotal;

function attachLongPress(el,callback,duration){
duration=duration||2500;
var timer=null,startX=0,startY=0,moved=false,longPressFired=false;
function start(e){var t=e.touches?e.touches[0]:e;if(!t)return;startX=t.clientX;startY=t.clientY;moved=false;longPressFired=false;if(timer)clearTimeout(timer);timer=setTimeout(function(){if(!moved){longPressFired=true;try{if(navigator.vibrate)navigator.vibrate(80);}catch(x){}callback();}},duration);}
function move(e){var t=e.touches?e.touches[0]:e;if(!t)return;if(Math.abs(t.clientX-startX)>12||Math.abs(t.clientY-startY)>12){moved=true;if(timer)clearTimeout(timer);}}
function end(){if(timer)clearTimeout(timer);}
function cancel(){if(timer)clearTimeout(timer);moved=true;}
if(window.PointerEvent){el.addEventListener("pointerdown",start);el.addEventListener("pointermove",move);el.addEventListener("pointerup",end);el.addEventListener("pointercancel",cancel);el.addEventListener("pointerleave",cancel);}
else{el.addEventListener("touchstart",start,{passive:true});el.addEventListener("touchmove",move,{passive:true});el.addEventListener("touchend",end);el.addEventListener("touchcancel",cancel);el.addEventListener("mousedown",start);el.addEventListener("mousemove",move);el.addEventListener("mouseup",end);el.addEventListener("mouseleave",cancel);}
el.addEventListener("click",function(e){if(longPressFired){e.preventDefault();e.stopPropagation();longPressFired=false;setTimeout(function(){longPressFired=false;},150);}},true);
}
window.attachLongPress=attachLongPress;

function showChatPage(){
document.querySelectorAll(".pg").forEach(function(p){p.classList.remove("on");});
$("chatPage").classList.add("on");
document.querySelectorAll(".bni").forEach(function(b){b.classList.remove("on");});
var cb=document.querySelector(".bni[data-page='chatPage']");if(cb)cb.classList.add("on");
CHATv1.currentRoom=null;CHATv1.unread=0;
renderChatList();
}
window.showChatPage=showChatPage;

function renderChatList(){
var page=$("chatPage");if(!page)return;
page.innerHTML="";
var shell=document.createElement("div");shell.className="chat-shell";page.appendChild(shell);
var head=document.createElement("div");
head.style.cssText="display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px";
head.innerHTML='<div style="font-family:var(--fd);font-size:1.4rem;font-weight:900;color:#fff;letter-spacing:2px">CHAT</div><div style="display:flex;gap:8px"><button id="globalChatBtn" style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#38bdf8,#6366f1);color:#fff;border:none;cursor:pointer;font-size:18px;box-shadow:0 4px 14px rgba(56,189,248,.3)" title="Global Chat"><i class="fas fa-earth-asia"></i></button><button id="joinGroupBtn" style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--g2));color:#000;border:none;cursor:pointer;font-size:18px;box-shadow:0 4px 14px rgba(251,191,36,.4)" title="Gabung Grup"><i class="fas fa-right-to-bracket"></i></button><button id="createGrpBtn" style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--c),var(--c2));color:#000;border:none;cursor:pointer;font-size:18px;box-shadow:0 4px 14px rgba(34,211,238,.4)" title="Buat Grup"><i class="fas fa-users"></i></button><button id="addContactBtn" style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--n),var(--c));color:#000;border:none;cursor:pointer;font-size:18px;box-shadow:0 4px 14px rgba(0,255,136,.4)" title="Tambah Kontak"><i class="fas fa-user-plus"></i></button></div>';
shell.appendChild(head);
setTimeout(function(){
var ab=$("addContactBtn");if(ab)ab.onclick=openAddContactModal;var globalBtn=$("globalChatBtn");if(globalBtn)globalBtn.onclick=openGlobalChatRoom;
var gb=$("createGrpBtn");if(gb)gb.onclick=openCreateGroupModal;
var jb=$("joinGroupBtn");if(jb)jb.onclick=openJoinGroupModal;
},50);
var body=document.createElement("div");body.className="cv1-body";shell.appendChild(body);
body.innerHTML='<div class="skeleton skeleton-card"></div><div class="skeleton skeleton-card"></div>';

var groups=groupGetList();
var contacts=chatGetContacts();
contacts.sort(function(a,b){return b.t-a.t;});
var pinned=getPinnedChats();

setTimeout(function(){
if(!contacts.length&&!groups.length){
body.innerHTML='<div style="text-align:center;padding:80px 20px;color:var(--t3);font-size:.75rem;line-height:2"><div style="font-size:4rem;margin-bottom:22px;opacity:.25;color:var(--n)"><i class="fas fa-comments"></i></div><div style="font-family:var(--fd);font-size:1.1rem;color:var(--t2);margin-bottom:10px;letter-spacing:2px">BELUM ADA CHAT</div>Tap <b style="color:var(--n)">+</b> untuk tambah kontak<br>atau <b style="color:var(--c)">ikon grup</b> untuk buat grup<br>atau <b style="color:var(--g)">ikon join</b> untuk gabung grup</div>';
return;
}
body.innerHTML="";

var pinnedItems=[];
groups.forEach(function(g){if(isPinnedChat("g_"+g.id))pinnedItems.push({type:"group",data:g});});
contacts.forEach(function(c){if(isPinnedChat("u_"+c.u))pinnedItems.push({type:"user",data:c});});

if(pinnedItems.length){
var psec=document.createElement("div");psec.className="cv1-section pinned-sec";
psec.innerHTML='<span>DISEMATKAN <span class="cs-pin"><i class="fas fa-thumbtack"></i> '+pinnedItems.length+'</span></span>';
body.appendChild(psec);
pinnedItems.forEach(function(it){
if(it.type==="user"){renderUserChatItem(body,it.data,true);}
else{renderGroupChatItem(body,it.data,true);}
});
}

var normalGroups=groups.filter(function(g){return !isPinnedChat("g_"+g.id);});
var normalContacts=contacts.filter(function(c){return !isPinnedChat("u_"+c.u);});

if(normalGroups.length){
var gsec=document.createElement("div");gsec.className="cv1-section";
var reqTotal=0;
normalGroups.forEach(function(g){if(g.owner===CURRENT_USER||(g.admins||[]).indexOf(CURRENT_USER)>=0){reqTotal+=parseInt(localStorage.getItem("damz_grp_req_"+g.id)||"0");}});
gsec.innerHTML='<span>GRUP ('+normalGroups.length+')</span>'+(reqTotal>0?'<span class="cs-count"><i class="fas fa-user-clock"></i> '+reqTotal+' req</span>':'');
body.appendChild(gsec);
normalGroups.forEach(function(g){renderGroupChatItem(body,g,false);});
}
if(normalContacts.length){
var sec=document.createElement("div");sec.className="cv1-section";sec.textContent="KONTAK ("+normalContacts.length+")";body.appendChild(sec);
normalContacts.forEach(function(c){renderUserChatItem(body,c,false);});
}
},200);
}

function renderGroupChatItem(body,g,isPinned){
var el=document.createElement("div");el.className="cv1-item"+(isPinned?" pinned":"");
var gpp=g.pp?'background-image:url('+g.pp+');background-size:cover;background-position:center':'background:linear-gradient(135deg,var(--c),var(--c2))';
var gtxt=g.pp?'':esc(g.name.charAt(0).toUpperCase());
var isOwner=g.owner===CURRENT_USER;
var isAdmin=isOwner||(g.admins||[]).indexOf(CURRENT_USER)>=0;
var reqCount=parseInt(localStorage.getItem("damz_grp_req_"+g.id)||"0");
var modeTag=isOwner||isAdmin?(g.joinMode==="open"?'<span class="grp-tag open-tag">OPEN</span>':'<span class="grp-tag approval-tag">APPROVAL</span>'):'';
var unread=parseInt(localStorage.getItem("damz_unread_grp_"+g.id)||"0");
var pinIcon=isPinned?'<div class="cv1-pin"><i class="fas fa-thumbtack"></i></div>':'';
el.innerHTML=pinIcon+'<div style="width:50px;height:50px;border-radius:14px;'+gpp+';color:#000;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;flex-shrink:0;position:relative">'+gtxt+(reqCount>0&&isAdmin?'<span style="position:absolute;top:-4px;right:-4px;background:linear-gradient(135deg,var(--g),var(--g2));color:#000;font-family:var(--fm);font-size:.42rem;font-weight:900;min-width:16px;height:16px;border-radius:8px;display:flex;align-items:center;justify-content:center;border:2px solid var(--bg0);animation:pulse 1.5s infinite">'+reqCount+'</span>':'')+'</div><div class="cv1-item-info"><div class="cv1-item-name">'+esc(g.name)+' <span class="grp-tag">GRUP</span> '+modeTag+'</div><div class="cv1-item-msg" id="gprev_'+esc(g.id)+'">'+(unread>0?'<b style="color:var(--n)">'+unread+' pesan baru</b>':'Ketuk untuk buka')+'</div></div>'+(unread>0?'<span class="member-badge online-b">'+unread+'</span>':'');
var gidCopy=g.id,gnameCopy=g.name;
el.onclick=function(){
localStorage.setItem("damz_unread_grp_"+gidCopy,"0");
updateBadgesUI();
openGroupRoom(gidCopy,gnameCopy);
};
attachLongPress(el,function(){showGroupContextMenu(gidCopy,gnameCopy);},2500);
body.appendChild(el);
if(db)db.ref("groupChats/"+g.id).limitToLast(1).once("value").then(function(snap){var d=snap.val()||{},keys=Object.keys(d);if(!keys.length)return;var last=d[keys[0]],elP=$("gprev_"+g.id);if(!elP)return;if(unread>0)return;var prev=last.voice?"Voice":(last.mediaType==="photo"?"Foto":(last.mediaType==="video"?"Video":(last.text||"")));elP.textContent=(last.from===CURRENT_USER?"Kamu: ":getUserDisplay(last.from)+": ")+prev;});
}

function renderUserChatItem(body,c,isPinned){
var u=c.u;var m=getMembers();
if(!m[u])return;
var isOn=isOnline(m[u]);var blocked=isBlocked(u);
var el=document.createElement("div");el.className="cv1-item"+(isPinned?" pinned":"");
if(blocked)el.style.opacity="0.5";
var dispName=chatDisplayName(u);var uid=m[u].userId||"—";
var unread=parseInt(localStorage.getItem("damz_unread_"+chatRoomKey(CURRENT_USER,u))||"0");
var pinIcon=isPinned?'<div class="cv1-pin"><i class="fas fa-thumbtack"></i></div>':'';
el.innerHTML=pinIcon+avatarHTML(u,50)+'<div class="cv1-item-info"><div class="cv1-item-name">'+esc(dispName)+(blocked?' <span class="member-badge blocked-b">BLOCKED</span>':'')+'</div><div class="cv1-item-id">'+esc(uid)+'</div><div class="cv1-item-msg" id="prev_'+esc(u)+'">'+(blocked?'Chat diblokir':(unread>0?'<b style="color:var(--n)">'+unread+' pesan baru</b>':'Ketuk untuk buka'))+'</div></div>'+(isOn&&!blocked?'<span class="member-badge online-b">ON</span>':'')+(unread>0?'<span class="member-badge online-b" style="background:linear-gradient(135deg,var(--r),#b91c1c);color:#fff;border-color:var(--r)">'+unread+'</span>':'');
var userCopy=u;
el.onclick=function(){
if(blocked){toast("Kontak diblokir. Buka blokir dulu.","err");return;}
localStorage.setItem("damz_unread_"+chatRoomKey(CURRENT_USER,u),"0");
updateBadgesUI();
openChatRoom(userCopy);
};
attachLongPress(el,function(){showChatContextMenu(userCopy);},2500);
body.appendChild(el);
if(db&&!blocked&&unread===0){db.ref("chats/"+chatRoomKey(CURRENT_USER,u)).limitToLast(1).once("value").then(function(snap){var d=snap.val()||{},keys=Object.keys(d).filter(function(k){return k!=="pinnedMessage";});if(!keys.length)return;var last=d[keys[0]],elP=$("prev_"+u);if(!elP)return;var prev=last.voice?"Voice":(last.mediaType==="photo"?"Foto":(last.text||""));elP.textContent=(last.from===CURRENT_USER?"Kamu: ":"")+prev;});}
}
window.renderGroupChatItem=renderGroupChatItem;
window.renderUserChatItem=renderUserChatItem;

window.showChatContextMenu=function(u){
var c=chatGetContact(u);var alias=c&&c.alias?c.alias:"";
var blocked=isBlocked(u);
var pinned=isPinnedChat("u_"+u);
var h='<div style="text-align:left"><div style="display:flex;align-items:center;gap:12px;padding:12px;background:rgba(0,0,0,.3);border-radius:12px;margin-bottom:14px;border:1.5px solid var(--b)">'+avatarHTML(u,46)+'<div><div style="color:#fff;font-weight:700;font-size:.85rem">'+esc(chatDisplayName(u))+'</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--c);margin-top:2px">'+esc(getMembers()[u]?getMembers()[u].userId||"":"")+'</div></div></div>'+
'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){handlePinChat(\'u_'+esc(u)+'\')},100)"><i class="fas fa-thumbtack" style="color:var(--p2);width:22px"></i> '+(pinned?"Unpin Chat":"Pin Chat")+'</button>'+
(!blocked?'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){openChatRoom(\''+esc(u)+'\')},100)"><i class="fas fa-comments" style="color:var(--n);width:22px"></i> Buka Chat</button>':'')+
(!blocked?'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){startCall(\''+esc(u)+'\',false)},100)"><i class="fas fa-phone" style="color:var(--n);width:22px"></i> Voice Call</button>':'')+
(!blocked?'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){startCall(\''+esc(u)+'\',true)},100)"><i class="fas fa-video" style="color:var(--c);width:22px"></i> Video Call</button>':'')+
'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){renameContact(\''+esc(u)+'\')},100)"><i class="fas fa-signature" style="color:var(--c);width:22px"></i> '+(alias?"Ganti Alias":"Kasih Alias")+'</button>'+
'<button class="grp-act-btn '+(blocked?'':'danger')+'" onclick="closeModal();setTimeout(function(){toggleBlockUser(\''+esc(u)+'\')},100)"><i class="fas fa-ban" style="width:22px;color:'+(blocked?'var(--n)':'#fca5a5')+'"></i> '+(blocked?"Buka Blokir":"Blokir Kontak")+'</button>'+
'<button class="grp-act-btn danger" onclick="closeModal();setTimeout(function(){deleteChatConfirm(\''+esc(u)+'\',\'user\')},100)"><i class="fas fa-trash" style="width:22px"></i> Hapus Chat</button>'+
'<button class="grp-act-btn danger" onclick="closeModal();setTimeout(function(){removeContactConfirm(\''+esc(u)+'\')},100)"><i class="fas fa-user-minus" style="width:22px"></i> Hapus Kontak</button></div>';
showModal("fa-user-cog","PILIHAN KONTAK",h,"TUTUP",null,"var(--n)");
};

window.showGroupContextMenu=function(gid,gname){
var pinned=isPinnedChat("g_"+gid);
var h='<div style="text-align:left"><div style="display:flex;align-items:center;gap:12px;padding:12px;background:rgba(0,0,0,.3);border-radius:12px;margin-bottom:14px;border:1.5px solid var(--b)"><div style="width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,var(--c),var(--c2));color:#000;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:20px">'+gname.charAt(0).toUpperCase()+'</div><div><div style="color:#fff;font-weight:700;font-size:.85rem">'+esc(gname)+'</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--c);margin-top:2px">GRUP</div></div></div>'+
'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){handlePinChat(\'g_'+esc(gid)+'\')},100)"><i class="fas fa-thumbtack" style="color:var(--p2);width:22px"></i> '+(pinned?"Unpin Grup":"Pin Grup")+'</button>'+
'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){openGroupRoom(\''+esc(gid)+'\',\''+esc(gname)+'\')},100)"><i class="fas fa-comments" style="color:var(--n);width:22px"></i> Buka Grup</button>'+
'<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){showGroupInfo(\''+esc(gid)+'\')},100)"><i class="fas fa-info-circle" style="color:var(--c);width:22px"></i> Info Grup</button>'+
'<button class="grp-act-btn danger" onclick="closeModal();setTimeout(function(){leaveGroup(\''+esc(gid)+'\')},100)"><i class="fas fa-right-from-bracket" style="width:22px"></i> Keluar Grup</button>'+
'<button class="grp-act-btn danger" onclick="closeModal();setTimeout(function(){deleteChatConfirm(\''+esc(gid)+'\',\'group\')},100)"><i class="fas fa-trash" style="width:22px"></i> Hapus Chat</button></div>';
showModal("fa-users","PILIHAN GRUP",h,"TUTUP",null,"var(--c)");
};

window.handlePinChat=function(id){var nowPinned=togglePinChat(id);renderChatList();};

window.deleteChatConfirm=function(id,type){
var label=type==="user"?getUserDisplay(id):id;
showModal("fa-trash","HAPUS CHAT","Hapus chat <b>"+esc(label)+"</b>?<br><br><span style='color:#fca5a5;font-size:.65rem'>Semua pesan di chat ini akan dihapus permanen dari perangkat & server.</span>","HAPUS",function(){
if(!db){toast("DB not ready","err");closeModal();return;}
if(type==="user"){
var rk=chatRoomKey(CURRENT_USER,id);
db.ref("chats/"+rk).remove().then(function(){
chatRemoveContact(id);
localStorage.removeItem("damz_unread_"+rk);
var pinned=getPinnedChats().filter(function(x){return x!=="u_"+id;});
savePinnedChats(pinned);
toast("Chat dihapus","ok");
closeModal();
renderChatList();
}).catch(function(e){toast("Gagal: "+e.message,"err");closeModal();});
}else{
db.ref("groupChats/"+id).remove().then(function(){
var list=groupGetList().filter(function(g){return g.id!==id;});
groupSaveList(list);
delete GRP_CACHE[id];
localStorage.removeItem("damz_unread_grp_"+id);
var pinned=getPinnedChats().filter(function(x){return x!=="g_"+id;});
savePinnedChats(pinned);
toast("Chat grup dihapus","ok");
closeModal();
renderChatList();
}).catch(function(e){toast("Gagal: "+e.message,"err");closeModal();});
}
},"var(--r)");
};

window.toggleBlockUser=function(u){var blocked=isBlocked(u);if(blocked){showModal("fa-unlock","BUKA BLOKIR","Buka blokir <b>"+esc(getUserDisplay(u))+"</b>?","BUKA",function(){toggleBlock(u);toast("Blokir dibuka","ok");closeModal();renderChatList();},"var(--n)");}else{showModal("fa-ban","BLOKIR KONTAK","Blokir <b>"+esc(getUserDisplay(u))+"</b>?","BLOKIR",function(){toggleBlock(u);toast("Diblokir","ok");closeModal();renderChatList();},"var(--r)");}};

window.renameContact=function(u){
var c=chatGetContact(u);var cur=c&&c.alias?c.alias:"";var real=getUserDisplay(u);
showModal("fa-signature","KASIH ALIAS",'<label class="lbl">Nama Asli: '+esc(real)+'</label><input class="inp" id="aliasInput" placeholder="Nama panggilan" value="'+esc(cur)+'" maxlength="24">',"SIMPAN",function(){var v=$("aliasInput").value.trim();chatAddContact(u,v);toast(v?"Alias disimpan":"Alias dihapus","ok");closeModal();renderChatList();},"var(--c)");
};

window.removeContactConfirm=function(u){showModal("fa-user-minus","HAPUS KONTAK",'Hapus <b>'+esc(chatDisplayName(u))+'</b> dari kontak?<br><br><span style="color:#fca5a5;font-size:.65rem">Chat history tidak otomatis terhapus.</span>',"HAPUS",function(){chatRemoveContact(u);toast("Kontak dihapus","ok");closeModal();renderChatList();},"var(--r)");};

window.openAddContactModal=function(){
var h='<div style="text-align:left">'+
'<div class="info-box" style="margin-bottom:12px">Masukkan <b style="color:var(--c)">4 karakter terakhir</b> ID user.</div>'+
'<label class="lbl">ID User</label>'+
'<div style="display:flex;align-items:center;background:rgba(10,26,16,.7);border:1.5px solid var(--b);border-radius:var(--r-md);padding:0 14px;margin-bottom:10px;transition:border-color .2s;position:relative" id="searchIdWrap">'+
'<span style="font-family:var(--fm);font-size:1rem;font-weight:900;color:var(--c);pointer-events:none">DZ-</span>'+
'<input class="inp" id="searchIdInput" placeholder="XXXX" style="font-family:var(--fm);text-transform:uppercase;letter-spacing:3px;text-align:left;font-size:1rem;font-weight:900;border:none;background:transparent;padding:13px 0;margin:0;box-shadow:none" maxlength="4" autocomplete="off" autocapitalize="characters" inputmode="text">'+
'</div>'+
'<div id="searchResult" style="margin-top:12px"></div>'+
'<div id="searchHint" style="font-size:.55rem;color:var(--t3);text-align:center;margin-top:8px"></div>'+
'</div>';

showModal("fa-user-plus","TAMBAH KONTAK",h,"TUTUP",null,"var(--n)");

setTimeout(function(){
var inp=$("searchIdInput");
var wrap=$("searchIdWrap");
if(!inp)return;
inp.focus();
inp.onfocus=function(){if(wrap)wrap.style.borderColor="var(--n)";};
inp.onblur=function(){if(wrap)wrap.style.borderColor="var(--b)";};

var debounce=null;
inp.oninput=function(){
this.value=this.value.replace(/[^A-Z0-9]/ig,"").toUpperCase();
var v=this.value.trim().toUpperCase();
var box=$("searchResult");
var hint=$("searchHint");

if(debounce)clearTimeout(debounce);

if(!v||v.length<2){
box.innerHTML="";
if(hint)hint.textContent="Ketik min 2 karakter belakang";
return;
}

box.innerHTML='<div style="text-align:center;padding:14px"><i class="fas fa-spinner fa-spin" style="color:var(--n);font-size:20px"></i></div>';
if(hint)hint.textContent="";

debounce=setTimeout(function(){searchAndPreview("DZ-"+v);},300);
};

inp.onkeydown=function(e){
if(e.key==="Enter"){
e.preventDefault();
if(debounce)clearTimeout(debounce);
var v=this.value.trim().toUpperCase();
if(v.length>=2)searchAndPreview("DZ-"+v);
}
};
},120);
};

function searchAndPreview(uid){
var box=$("searchResult");if(!box)return;
var hint=$("searchHint");if(hint)hint.textContent="";
uid=String(uid||"").trim().toUpperCase();

if(uid&&uid.indexOf("DZ-")!==0&&uid.length<=6&&/^[A-Z0-9]+$/.test(uid)){uid="DZ-"+uid;}

var isSelf=(uid===String(CURRENT_ID||"").toUpperCase());
var uname=findUserByUserId(uid);

if(!uname){
var m0=getMembers();
for(var k in m0){
var uu=m0[k];
if(uu.userId&&String(uu.userId).toUpperCase()===uid){uname=k;break;}
if(String(uu.display||"").toUpperCase()===uid){uname=k;break;}
if(String(uu.username||"").toUpperCase()===uid){uname=k;break;}
}
}

if(isSelf){
var meDisp=getUserDisplay(CURRENT_USER);
var mePp=getUserPP(CURRENT_USER);
var meAv=mePp?'background-image:url('+mePp+');background-size:cover;background-position:center':'';
var meAvTxt=mePp?'':meDisp.charAt(0).toUpperCase();
box.innerHTML='<div style="padding:16px;background:linear-gradient(135deg,rgba(251,191,36,.12),rgba(245,158,11,.06));border:1.5px solid rgba(251,191,36,.45);border-radius:var(--r-lg);text-align:center"><div style="width:70px;height:70px;margin:0 auto 12px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--g2));display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:28px;font-weight:900;color:#000;'+meAv+'">'+meAvTxt+'</div><div style="font-family:var(--fd);font-size:1rem;font-weight:900;color:#fff;margin-bottom:6px">'+esc(meDisp)+' <span class="member-badge vip-b">KAMU</span></div><div style="font-family:var(--fm);font-size:.65rem;color:var(--c);letter-spacing:2px;font-weight:900;margin-bottom:8px">'+esc(uid)+'</div><div style="font-size:.62rem;color:var(--t2);line-height:1.6">Ini ID kamu sendiri.<br>Bagikan ID ini ke teman biar mereka bisa nambahin kamu.</div><button class="btn cyan" style="margin-top:12px" type="button" onclick="copyText(\''+esc(uid)+'\')"><i class="fas fa-copy"></i> SALIN ID</button></div>';
return;
}

if(!uname){
box.innerHTML='<div class="info-box red" style="text-align:center">ID <b style="font-family:var(--fm)">'+esc(uid)+'</b> tidak ditemukan<br><span style="font-size:.55rem;color:var(--t3)">Pastikan ID benar (DZ-XXXX)</span></div>';
return;
}

var m=getMembers(),u=m[uname]||{};
if(u.banned){box.innerHTML='<div class="info-box red" style="text-align:center">User diblokir</div>';return;}

var pp=getUserPP(uname);var disp=getUserDisplay(uname);var isAlready=chatGetContact(uname);
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
var avText=pp?'':disp.charAt(0).toUpperCase();
var btn=isAlready
?'<button class="btn green" type="button" onclick="confirmAddContact(\''+esc(uname)+'\')" style="background:rgba(34,197,94,.2);color:var(--n);border:1.5px solid var(--b2)"><i class="fas fa-check"></i> SUDAH DI KONTAK</button>'
:'<button class="btn" type="button" onclick="confirmAddContact(\''+esc(uname)+'\')"><i class="fas fa-user-plus"></i> TAMBAH</button>';
box.innerHTML='<div style="padding:16px;background:linear-gradient(135deg,rgba(15,36,22,.7),rgba(10,26,16,.6));border:1.5px solid var(--b2);border-radius:var(--r-lg);text-align:center"><div style="width:70px;height:70px;margin:0 auto 12px;border-radius:50%;background:linear-gradient(135deg,var(--n),var(--n2));display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:28px;font-weight:900;color:#000;'+avStyle+'">'+avText+'</div><div style="font-family:var(--fd);font-size:1rem;font-weight:900;color:#fff;margin-bottom:6px">'+esc(disp)+'</div><div style="font-family:var(--fm);font-size:.65rem;color:var(--c);letter-spacing:2px;font-weight:900;margin-bottom:8px">'+esc(uid)+'</div><div style="font-family:var(--fm);font-size:.55rem;color:var(--t3);margin-bottom:14px">'+(isOnline(u)?"🟢 Online":"⚪ Offline")+' • '+esc(u.userId||"")+'</div>'+btn+'</div>';

if(uname&&box._listenRef){try{box._listenRef.off();}catch(e){}}
if(uname){
box._listenRef=db.ref("contacts/"+uname+"/"+CURRENT_USER);
box._listenRef.on("value",function(snap){
if(snap.val()){
var isNowContact=chatGetContact(uname);
if(!isNowContact){
toast(disp+" menambahkan kamu!","ok");
var inp=$("searchIdInput");
if(inp&&inp.value===uid.replace("DZ-",""))searchAndPreview(uid);
if(typeof renderChatList==="function")renderChatList();
}
}
});
}
}
window.searchAndPreview=searchAndPreview;

window.confirmAddContact=function(uname){
var disp=getUserDisplay(uname);
showModal("fa-user-plus","TAMBAH KONTAK",'Tambahkan <b style="color:var(--n)">'+esc(disp)+'</b>?',"TAMBAH",function(){
chatAddContact(uname,"");
if(db){
db.ref("contacts/"+CURRENT_USER+"/"+uname).set({added:true,time:Date.now(),display:CURRENT_DISPLAY});
}
toast("Ditambahkan","ok");
closeModal();
renderChatList();
},"var(--n)");
};

function openChatRoom(otherUser){
CHATv1.currentRoom={type:"user",id:otherUser};CHATv1.unread=0;LAST_MSG_COUNT=0;CHATv1.pinnedMessage=null;
var page=$("chatPage");page.innerHTML="";
var shell=document.createElement("div");shell.className="chat-shell";page.appendChild(shell);
var m=getMembers(),isOn=m[otherUser]&&isOnline(m[otherUser]);
var disp=chatDisplayName(otherUser);
var uid=m[otherUser]?m[otherUser].userId||"":"";
var head=document.createElement("div");head.className="cv1-room-head";
head.innerHTML='<button class="cv1-back" id="backBtn"><i class="fas fa-arrow-left"></i></button>'+avatarHTML(otherUser,42)+'<div style="flex:1;cursor:pointer;min-width:0" id="userHeader"><div style="font-size:.85rem;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(disp)+'</div><div style="font-family:var(--fm);font-size:.5rem;color:'+(isOn?"var(--n)":"var(--t3)")+'">'+(isOn?"Online":"Offline")+' • '+esc(uid)+'</div></div><button class="cv1-back" id="callBtn" style="background:rgba(0,255,136,.15);color:var(--n)"><i class="fas fa-phone"></i></button><button class="cv1-back" id="videoCallBtn" style="background:rgba(34,211,238,.15);color:var(--c)"><i class="fas fa-video"></i></button>';
shell.appendChild(head);
setTimeout(function(){
var bb=$("backBtn");if(bb)bb.onclick=function(){stopChatListener();stopVoiceRecorder();try{if(db)db.ref("chats/"+chatRoomKey(CURRENT_USER,otherUser)+"/typing/"+CURRENT_USER).remove();}catch(e){}CHATv1.currentRoom=null;CHATv1.pinnedMessage=null;var sb=$("scrollBottomBtn");if(sb)sb.remove();renderChatList();};
var cb=$("callBtn");if(cb)cb.onclick=function(){startCall(otherUser,false);};
var vcb=$("videoCallBtn");if(vcb)vcb.onclick=function(){startCall(otherUser,true);};
var uh=$("userHeader");if(uh)uh.onclick=function(){showContactInfo(otherUser);};
},50);

var pinWrap=document.createElement("div");pinWrap.id="pinnedWrap";shell.appendChild(pinWrap);

var msgs=document.createElement("div");msgs.className="cv1-messages";msgs.id="chatMessages";
msgs.innerHTML='<div class="skeleton" style="height:50px;width:60%"></div><div class="skeleton" style="height:50px;width:70%;margin-left:auto"></div><div class="skeleton" style="height:50px;width:50%"></div>';
shell.appendChild(msgs);
var scrollBtn=document.createElement("button");scrollBtn.className="scroll-bottom-btn";scrollBtn.id="scrollBottomBtn";
scrollBtn.innerHTML='<i class="fas fa-arrow-down"></i><span class="badge" id="scrollBadge" style="display:none">0</span>';
document.body.appendChild(scrollBtn);
setTimeout(function(){
var sb=$("scrollBottomBtn");if(sb)sb.onclick=function(){scrollToBottom(true);};
var msgsEl=$("chatMessages");
if(msgsEl){msgsEl.addEventListener("scroll",function(){var isAtBottom=msgsEl.scrollHeight-msgsEl.scrollTop-msgsEl.clientHeight<80;if(isAtBottom){scrollBtn.classList.remove("on");CHATv1.unread=0;var b=$("scrollBadge");if(b)b.style.display="none";}});}
},150);
var bar=document.createElement("div");bar.className="cv1-input-bar";bar.id="chatInputBar";
bar.innerHTML=inputBarHTML();
shell.appendChild(bar);
setTimeout(bindChatInput,50);
startChatListener();
}
window.openChatRoom=openChatRoom;

function inputBarHTML(){
return '<div class="cv1-input-row">'+
'<button type="button" class="cv1-attach" id="chatAttachBtn"><i class="fas fa-plus"></i></button>'+
'<button type="button" class="cv1-attach cv1-mic" id="chatMicBtn"><i class="fas fa-microphone"></i></button>'+
'<div class="cv1-input-box"><textarea class="cv1-input" id="chatInput" placeholder="Ketik pesan..." rows="1"></textarea></div>'+
'<button class="cv1-send" id="chatSend" type="button"><i class="fas fa-paper-plane"></i></button>'+
'<div class="attach-menu" id="chatAttachMenu">'+
'<button type="button" class="attach-opt" data-opt="photo"><i class="fas fa-image" style="color:var(--n)"></i> Foto</button>'+
'<button type="button" class="attach-opt" data-opt="camera"><i class="fas fa-camera" style="color:var(--c)"></i> Kamera</button>'+
'<button type="button" class="attach-opt" data-opt="video"><i class="fas fa-video" style="color:var(--g)"></i> Video Note</button>'+
'<button type="button" class="attach-opt" data-opt="file"><i class="fas fa-file" style="color:var(--n2)"></i> File</button>'+
'<button type="button" class="attach-opt" data-opt="location"><i class="fas fa-map-marker-alt" style="color:var(--r2)"></i> Lokasi</button>'+
'<button type="button" class="attach-opt" data-opt="contact"><i class="fas fa-address-book" style="color:var(--p2)"></i> Kontak</button>'+
'<button type="button" class="attach-opt" data-opt="sticker"><i class="fas fa-face-smile" style="color:var(--g)"></i> Sticker</button>'+
'<button type="button" class="attach-opt" data-opt="voice"><i class="fas fa-wave-square" style="color:var(--p)"></i> Voice Changer</button>'+
'</div></div>';
}

function bindChatInput(){
var inp=$("chatInput"),btn=$("chatSend"),att=$("chatAttachBtn"),mic=$("chatMicBtn");
if(inp){
inp.oninput=function(){
this.style.height="auto";this.style.height=Math.min(this.scrollHeight,110)+"px";
if(CHATv1.currentRoom){var rk=getRoomKey();if(rk&&db){try{db.ref(rk+"/typing/"+CURRENT_USER).set(true);db.ref(rk+"/typing/"+CURRENT_USER).onDisconnect().remove();}catch(e){}if(TYPING_TIMEOUT)clearTimeout(TYPING_TIMEOUT);TYPING_TIMEOUT=setTimeout(function(){try{db.ref(rk+"/typing/"+CURRENT_USER).remove();}catch(e){}},2000);}}
};
inp.onkeydown=function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChatMessage();}};
}
if(btn)btn.onclick=sendChatMessage;
if(att)att.onclick=function(e){e.stopPropagation();$("chatAttachMenu").classList.toggle("on");};
if(mic)mic.onclick=startVoiceRecord;
document.querySelectorAll(".attach-opt").forEach(function(b){b.onclick=function(){var o=this.getAttribute("data-opt");$("chatAttachMenu").classList.remove("on");handleAttach(o);};});
document.addEventListener("click",function(e){var m=$("chatAttachMenu");if(m&&!e.target.closest("#chatAttachBtn")&&!e.target.closest("#chatAttachMenu"))m.classList.remove("on");});
}

function getRoomKey(){if(!CHATv1.currentRoom)return null;if(CHATv1.currentRoom.type==="group")return "groupChats/"+CHATv1.currentRoom.id;return "chats/"+chatRoomKey(CURRENT_USER,CHATv1.currentRoom.id);}
window.openGlobalChatRoom=function(){
if(!db){toast("Firebase belum tersambung","err");return;}
GRP_CACHE.global={name:"GLOBAL CHAT",owner:"system",members:[],admins:[],public:true,description:"Ruang obrolan bersama seluruh pengguna DAMZ NEXUS"};
openGroupRoom("global","GLOBAL CHAT");
};

function sendChatMessage(){
var inp=$("chatInput");if(!inp||!CHATv1.currentRoom||!db)return;
var txt=inp.value.trim();if(!txt)return;
var rk=getRoomKey();
inp.value="";inp.style.height="40px";
try{db.ref(rk+"/typing/"+CURRENT_USER).remove();}catch(e){}
db.ref(rk).push({from:CURRENT_USER,text:txt,time:new Date().toISOString(),timestamp:Date.now()});
setTimeout(function(){scrollToBottom(true);},200);
}

function handleAttach(opt){
if(!CHATv1.currentRoom||!db)return;
var rk=getRoomKey();
if(opt==="photo"){
var inp=document.createElement("input");
inp.type="file";inp.accept="image/*";
inp.onchange=function(e){
var f=e.target.files[0];if(!f)return;
if(f.size>8*1024*1024){toast("Max 8MB","err");return;}
toast("Mengompres foto...","ok");
compressImage(f,1280,1280,150,function(du,kb){
db.ref(rk).push({from:CURRENT_USER,text:"Foto",media:du,mediaType:"photo",time:new Date().toISOString(),timestamp:Date.now()});
toast("Terkirim ("+kb+"KB)","ok");
});
};
inp.click();return;
}
if(opt==="camera"){
var inp2=document.createElement("input");
inp2.type="file";inp2.accept="image/*";inp2.capture="environment";
inp2.onchange=function(e){
var f=e.target.files[0];if(!f)return;
toast("Mengompres foto...","ok");
compressImage(f,1280,1280,150,function(du,kb){
db.ref(rk).push({from:CURRENT_USER,text:"Kamera",media:du,mediaType:"photo",time:new Date().toISOString(),timestamp:Date.now()});
toast("Terkirim ("+kb+"KB)","ok");
});
};
inp2.click();return;
}
if(opt==="video"){startVideoRecord(rk);return;}
if(opt==="file"){var inp3=document.createElement("input");inp3.type="file";inp3.onchange=function(e){var f=e.target.files[0];if(!f)return;if(f.size>5*1024*1024){toast("Max 5MB","err");return;}var rd=new FileReader();rd.onload=function(ev){db.ref(rk).push({from:CURRENT_USER,text:f.name,media:ev.target.result,mediaType:"file",fileName:f.name,fileSize:f.size,time:new Date().toISOString(),timestamp:Date.now()});toast("Terkirim","ok");};rd.readAsDataURL(f);};inp3.click();return;}
if(opt==="location"){if(!navigator.geolocation){toast("GPS tidak support","err");return;}toast("Mengambil lokasi...","ok");navigator.geolocation.getCurrentPosition(function(pos){var lat=pos.coords.latitude,lon=pos.coords.longitude;db.ref(rk).push({from:CURRENT_USER,text:"Lokasi",mediaType:"location",lat:lat,lon:lon,time:new Date().toISOString(),timestamp:Date.now()});toast("Lokasi terkirim","ok");},function(err){toast("Gagal: "+err.message,"err");},{enableHighAccuracy:true,timeout:10000});return;}
if(opt==="contact"){showContactPickerForSend(rk);return;}
if(opt==="sticker"){showStickerPicker(rk);return;}
if(opt==="voice"){showVoiceChangerModal();return;}
}

function showVoiceChangerModal(){
var h='<div id="voiceChangerUI"></div>';
showModal("fa-wave-square","VOICE CHANGER",h,"TUTUP",null,"var(--p)");
setTimeout(function(){if(typeof vcRenderUI==="function")vcRenderUI();},100);
}

function showContactPickerForSend(rk){
var contacts=chatGetContacts();
if(!contacts.length){toast("Belum ada kontak","err");return;}
var h='<div style="text-align:left;max-height:400px;overflow-y:auto">';
contacts.forEach(function(c){var u=c.u;var m=getMembers();if(!m[u])return;h+='<div class="pick-contact" data-user="'+esc(u)+'" style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(0,0,0,.3);border:1.5px solid var(--b);border-radius:12px;margin-bottom:8px;cursor:pointer">'+avatarHTML(u,42)+'<div style="flex:1"><div style="color:#fff;font-weight:700;font-size:.78rem">'+esc(chatDisplayName(u))+'</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--c)">'+esc(m[u].userId||"—")+'</div></div></div>';});
h+='</div>';
showModal("fa-address-book","KIRIM KONTAK",h,"TUTUP",null,"var(--p2)");
setTimeout(function(){document.querySelectorAll(".pick-contact").forEach(function(el){el.onclick=function(){var u=this.getAttribute("data-user");var m=getMembers();var uid=m[u]?m[u].userId:"—";var disp=chatDisplayName(u);db.ref(rk).push({from:CURRENT_USER,text:disp+" ("+uid+")",mediaType:"contact",contactId:uid,contactName:disp,time:new Date().toISOString(),timestamp:Date.now()});toast("Terkirim","ok");closeModal();};});},80);
}

function showStickerPicker(rk){
var stickers=["😀","😂","🥰","😎","🤔","😴","🤩","😭","😡","🥳","👍","👎","🙏","👏","💪","✌️","🤝","❤️","💔","💯","🔥","⭐","✨","🌈","☀️","🌙","🍕","🍔","🍟","🍰","🎂","☕","🎉","🎁","🏆","⚽","🎮","📱","💻","🎵","🐱","🐶","🐼","🦁","🐸","🌸","🌹","🌻","🍀","🎈"];
var h='<div style="text-align:left"><div class="sticker-picker">';
stickers.forEach(function(s){h+='<div class="sticker-item" data-sticker="'+s+'">'+s+'</div>';});
h+='</div></div>';
showModal("fa-face-smile","STICKER",h,"TUTUP",null,"var(--g)");
setTimeout(function(){document.querySelectorAll(".sticker-item").forEach(function(el){el.onclick=function(){var s=this.getAttribute("data-sticker");db.ref(rk).push({from:CURRENT_USER,text:s,mediaType:"sticker",sticker:s,time:new Date().toISOString(),timestamp:Date.now()});toast("Terkirim","ok");closeModal();};});},80);
}

function startVoiceRecord(){
if(!CHATv1.currentRoom||!db||!navigator.mediaDevices){toast("Tidak support","err");return;}
var micBtn=$("chatMicBtn");
if(VOICE_REC.isRec){try{VOICE_REC.rec.stop();}catch(e){}return;}
navigator.mediaDevices.getUserMedia({audio:true}).then(function(stream){
VOICE_REC.stream=stream;VOICE_REC.chunks=[];VOICE_REC.rec=new MediaRecorder(stream);VOICE_REC.isRec=true;VOICE_REC.startTime=Date.now();
if(micBtn){micBtn.classList.add("recording");micBtn.innerHTML='<i class="fas fa-stop"></i>';}
$("recTimer").classList.add("on");
VOICE_REC.timer=setInterval(function(){var e=Date.now()-VOICE_REC.startTime;var s=Math.floor(e/1000);var m=Math.floor(s/60);s=s%60;$("recTimerText").textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");},250);
VOICE_REC.rec.ondataavailable=function(e){if(e.data.size>0)VOICE_REC.chunks.push(e.data);};
VOICE_REC.rec.onstop=function(){
var dur=Math.round((Date.now()-VOICE_REC.startTime)/1000);
try{VOICE_REC.stream.getTracks().forEach(function(t){t.stop();});}catch(e){}
VOICE_REC.isRec=false;clearInterval(VOICE_REC.timer);
if(micBtn){micBtn.classList.remove("recording");micBtn.innerHTML='<i class="fas fa-microphone"></i>';}
$("recTimer").classList.remove("on");
if(dur<1){toast("Terlalu singkat","err");return;}
var blob=new Blob(VOICE_REC.chunks,{type:"audio/webm"});
var rd=new FileReader();
rd.onloadend=function(){var rk=getRoomKey();if(!rk)return;db.ref(rk).push({from:CURRENT_USER,text:"Voice "+dur+"s",voice:rd.result,voiceDuration:dur,time:new Date().toISOString(),timestamp:Date.now()});toast("Terkirim","ok");};
rd.readAsDataURL(blob);
};
VOICE_REC.rec.start();
}).catch(function(err){toast("Mic ditolak","err");});
}
window.startVoiceRecord=startVoiceRecord;

function stopVoiceRecorder(){if(VOICE_REC.isRec){try{VOICE_REC.rec.stop();}catch(e){}}VOICE_REC.isRec=false;clearInterval(VOICE_REC.timer);}

function startVideoRecord(rk){
if(!navigator.mediaDevices){toast("Tidak support","err");return;}
showModal("fa-video","VIDEO NOTE","<div style='text-align:center'><div style='font-size:48px;margin-bottom:10px'>📹</div><div style='font-size:.72rem;color:var(--t2);line-height:1.7'>Rekam video max 30 detik.</div></div>","MULAI",function(){
navigator.mediaDevices.getUserMedia({video:{width:640,height:640,facingMode:"user"},audio:true}).then(function(stream){
var chunks=[];var rec=new MediaRecorder(stream);var startTime=Date.now();
var recTimer=$("recTimer");$("recTimerText").textContent="00:00";recTimer.classList.add("on");
var timer=setInterval(function(){var e=Date.now()-startTime;var s=Math.floor(e/1000);if(s>=30){try{rec.stop();}catch(x){}}var m=Math.floor(s/60);s=s%60;$("recTimerText").textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");},250);
rec.ondataavailable=function(e){if(e.data.size>0)chunks.push(e.data);};
rec.onstop=function(){
try{stream.getTracks().forEach(function(t){t.stop();});}catch(e){}
clearInterval(timer);recTimer.classList.remove("on");
var dur=Math.round((Date.now()-startTime)/1000);
if(dur<1){toast("Terlalu singkat","err");return;}
var blob=new Blob(chunks,{type:"video/webm"});
if(blob.size>2*1024*1024){toast("Terlalu besar","err");return;}
var rd=new FileReader();
rd.onloadend=function(){db.ref(rk).push({from:CURRENT_USER,text:"Video "+dur+"s",media:rd.result,mediaType:"video",videoDuration:dur,time:new Date().toISOString(),timestamp:Date.now()});toast("Terkirim","ok");};
rd.readAsDataURL(blob);
};
rec.start();
setTimeout(function(){if(rec.state==="recording")try{rec.stop();}catch(e){}},30000);
}).catch(function(err){toast("Kamera ditolak","err");});
},"var(--g)");
}
window.startVideoRecord=startVideoRecord;

function startChatListener(){
stopChatListener();
if(!CHATv1.currentRoom||!db)return;
var rk=getRoomKey();
var ref=db.ref(rk).limitToLast(150);
var h=ref.on("value",function(snap){
var d=snap.val()||{};
var arr=Object.keys(d).filter(function(k){return k!=="typing"&&k!=="reads"&&k!=="pinnedMessage";}).map(function(k){var m=d[k];m._key=k;return m;});
arr.sort(function(a,b){return (a.timestamp||0)-(b.timestamp||0);});
renderChatMessages(arr);
});
CHATv1.listeners[rk]={ref:ref,handler:h};

var pinRef=db.ref(rk+"/pinnedMessage");
var pinH=pinRef.on("value",function(s){
var v=s.val();
CHATv1.pinnedMessage=v;
renderPinnedBanner(v);
});
CHATv1.listeners[rk+"_pin"]={ref:pinRef,handler:pinH};

if(CHATv1.currentRoom.type==="user"){
var typRef=db.ref(rk+"/typing");
var typH=typRef.on("value",function(s){
var d=s.val()||{};
var others=Object.keys(d).filter(function(u){return u!==CURRENT_USER;});
updateTypingIndicator(others);
});
CHATv1.listeners[rk+"_typing"]={ref:typRef,handler:typH};
}
}
function stopChatListener(){
Object.keys(CHATv1.listeners).forEach(function(k){try{CHATv1.listeners[k].ref.off("value",CHATv1.listeners[k].handler);}catch(e){}});
CHATv1.listeners={};
}

function updateTypingIndicator(users){
var box=$("chatMessages");if(!box)return;
var existing=box.querySelector(".typing-indicator");
if(existing)existing.remove();
if(!users||!users.length)return;
var wrap=document.createElement("div");
wrap.className="typing-indicator";
wrap.innerHTML='<span></span><span></span><span></span>';
box.appendChild(wrap);
try{box.scrollTop=box.scrollHeight;}catch(e){}
}

function renderChatMessages(arr){
var box=$("chatMessages");if(!box)return;
var isGroup=CHATv1.currentRoom&&CHATv1.currentRoom.type==="group";
var typingEl=box.querySelector(".typing-indicator");
if(!arr.length){box.innerHTML="<div style='text-align:center;padding:50px;color:var(--t3)'>Belum ada pesan</div>";LAST_MSG_COUNT=0;return;}
var wasAtBottom=box.scrollHeight-box.scrollTop-box.clientHeight<80;
var isFirst=LAST_MSG_COUNT===0;
var hasNew=arr.length>LAST_MSG_COUNT;
LAST_MSG_COUNT=arr.length;
var h="";
arr.forEach(function(msg){
var isMe=msg.from===CURRENT_USER;
if(!isMe&&CHATv1.currentRoom&&CHATv1.currentRoom.type==="user"&&isBlocked(msg.from))return;
var isPinned=CHATv1.pinnedMessage&&CHATv1.pinnedMessage._key===msg._key;
h+="<div class='cv1-msg "+(isMe?"me":"them")+(isPinned?" pinned-msg":"")+"' data-msgkey='"+esc(msg._key)+"'>";
if(!isMe&&isGroup){
var ppm=getUserPP(msg.from);
h+='<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">'+(ppm?'<div style="width:20px;height:20px;border-radius:50%;background-image:url('+ppm+');background-size:cover"></div>':'')+'<div class="cv1-msg-author" style="margin:0">'+esc(chatDisplayName(msg.from))+'</div></div>';
}
if(msg.mediaType==="sticker"){h+='<div style="font-size:56px;line-height:1;text-align:center;padding:4px">'+esc(msg.sticker||msg.text)+'</div>';}
else if(msg.voice){
var vid="v_"+msg._key;
h+='<div style="display:flex;align-items:center;gap:10px;padding:4px"><button onclick="playVoice(\''+vid+'\',this)" style="width:34px;height:34px;border-radius:50%;background:'+(isMe?'rgba(0,0,0,.25)':'linear-gradient(135deg,var(--n),var(--c))')+';border:none;color:#000;cursor:pointer"><i class="fas fa-play"></i></button><div style="font-family:var(--fm);font-size:.6rem;font-weight:700">'+(msg.voiceDuration?msg.voiceDuration+"s":"")+'</div><audio id="audio_'+vid+'" src="'+msg.voice+'" preload="metadata"></audio></div>';
setTimeout(function(){var a=document.getElementById("audio_"+vid);if(a)a.onended=function(){var b=document.querySelector('button[onclick*="'+vid+'"] i');if(b)b.className="fas fa-play";};},100);
}
else if(msg.mediaType==="video"){h+='<video src="'+msg.media+'" controls style="max-width:220px;border-radius:10px;display:block;margin-bottom:4px"></video>';}
else if(msg.mediaType==="photo"){h+='<img src="'+msg.media+'" onclick="viewFullImage(\''+msg._key+'\')" style="cursor:pointer">';}
else if(msg.mediaType==="file"){h+='<div style="display:flex;align-items:center;gap:10px;padding:8px;background:rgba(0,0,0,.3);border-radius:10px"><i class="fas fa-file" style="font-size:24px;color:var(--n)"></i><div><div style="font-family:var(--fm);font-size:.62rem;font-weight:700">'+esc(msg.fileName||"File")+'</div><div style="font-family:var(--fm);font-size:.5rem;opacity:.7">'+Math.round((msg.fileSize||0)/1024)+' KB</div></div></div>';}
else if(msg.mediaType==="contact"){h+='<div style="display:flex;align-items:center;gap:10px;padding:8px;background:rgba(0,0,0,.3);border-radius:10px"><i class="fas fa-address-book" style="font-size:24px;color:var(--p2)"></i><div><div style="font-family:var(--fm);font-size:.62rem;font-weight:700">'+esc(msg.contactName||"Kontak")+'</div><div style="font-family:var(--fm);font-size:.5rem;opacity:.7">'+esc(msg.contactId||"")+'</div></div></div>';}
else if(msg.mediaType==="location"){h+='<div style="padding:8px;background:rgba(0,0,0,.3);border-radius:10px"><i class="fas fa-map-marker-alt" style="font-size:20px;color:var(--r2)"></i><div style="font-family:var(--fm);font-size:.55rem;margin-top:4px">'+Number(msg.lat).toFixed(4)+', '+Number(msg.lon).toFixed(4)+'</div></div>';}
else h+="<div style='word-wrap:break-word'>"+esc(msg.text)+"</div>";
var tick="";
if(isMe){tick='<span class="read-tick"><i class="fas fa-check"></i></span>';}
h+="<div class='cv1-msg-meta'>"+chatFmtTime(msg.time)+tick+"</div></div>";
});
box.innerHTML=h;
if(typingEl)box.appendChild(typingEl);
box.querySelectorAll(".cv1-msg").forEach(function(el){var mk=el.getAttribute("data-msgkey");if(!mk)return;attachLongPress(el,function(){showMessageContextMenu(mk);},2000);});
if(isFirst||wasAtBottom){
setTimeout(function(){scrollToBottom(false);},50);
setTimeout(function(){scrollToBottom(false);},300);
}else if(hasNew){
var scb=$("scrollBottomBtn");var bd=$("scrollBadge");
CHATv1.unread++;
if(scb)scb.classList.add("on");
if(bd){bd.style.display="inline-block";bd.textContent=CHATv1.unread;}
}
}

window.playVoice=function(vid,btn){
var a=document.getElementById("audio_"+vid);if(!a)return;
if(a.paused){a.play();btn.querySelector("i").className="fas fa-pause";}
else{a.pause();btn.querySelector("i").className="fas fa-play";}
};

window.viewFullImage=function(msgKey){
var box=$("chatMessages");if(!box)return;
var el=box.querySelector("[data-msgkey='"+msgKey+"']");if(!el)return;
var img=el.querySelector("img");if(!img)return;
$("viewer").classList.add("on");
$("viewerBody").innerHTML='<button class="btn sec" style="margin-bottom:12px" onclick="closeTool()"><i class="fas fa-arrow-left"></i> KEMBALI</button><div class="viewer-lbl">FOTO</div><div class="viewer-h">Preview</div><img src="'+img.src+'" style="width:100%;border-radius:14px">';
};

window.showMessageContextMenu=function(mk){
var rk=getRoomKey();if(!rk)return;
var box=$("chatMessages");
var el=box?box.querySelector("[data-msgkey='"+mk+"']"):null;
var txt="";
if(el){
var clone=el.cloneNode(true);
clone.querySelectorAll("button,audio,video,.cv1-msg-meta,.cv1-msg-author").forEach(function(x){x.remove();});
var img=el.querySelector("img");
txt=img?"[Foto]":(clone.textContent||"").trim();
}
var isPinned=CHATv1.pinnedMessage&&CHATv1.pinnedMessage._key===mk;
var h='<div style="text-align:left">'+
'<div style="padding:10px 12px;background:rgba(0,0,0,.45);border:1.5px solid var(--b);border-radius:12px;margin-bottom:14px;font-size:.72rem;color:var(--t2);max-height:100px;overflow-y:auto;word-wrap:break-word;line-height:1.5">'+esc(txt||"(kosong)")+'</div>'+
'<button class="grp-act-btn" onclick="'+(isPinned?'unpinMessage()':'pinMessage(\''+esc(mk)+'\')')+'"><i class="fas fa-thumbtack" style="color:var(--p2);width:22px"></i> '+(isPinned?"Unpin Pesan":"Pin Pesan")+'</button>'+
'<button class="grp-act-btn" onclick="copyChatMsg(\''+esc(mk)+'\')"><i class="fas fa-copy" style="color:var(--c);width:22px"></i> Salin Pesan</button>'+
'<button class="grp-act-btn danger" onclick="deleteChatMsg(\''+esc(mk)+'\')"><i class="fas fa-trash" style="width:22px"></i> Hapus Pesan</button>'+
'</div>';
showModal("fa-comment-dots","PESAN",h,"TUTUP",null,"var(--n)");
};

window.copyChatMsg=function(mk){
var el=document.querySelector("[data-msgkey='"+mk+"']");
if(!el){toast("Pesan hilang","err");return;}
var clone=el.cloneNode(true);
clone.querySelectorAll("button,audio,video,.cv1-msg-meta,.cv1-msg-author").forEach(function(x){x.remove();});
var img=el.querySelector("img");
var txt=img?img.src:(clone.textContent||"").trim();
if(!txt){toast("Pesan kosong","err");return;}
copyText(txt);
closeModal();
};

window.deleteChatMsg=function(mk){
showModal("fa-trash","HAPUS PESAN","Hapus pesan ini dari chat?","HAPUS",function(){
var rk=getRoomKey();
if(!rk){closeModal();return;}
db.ref(rk+"/"+mk).remove().then(function(){toast("Pesan dihapus","ok");closeModal();}).catch(function(){toast("Gagal hapus","err");closeModal();});
},"var(--r)");
};

window.showContactInfo=function(u){
var m=getMembers(),user=m[u]||{};
var pp=getUserPP(u);var disp=getUserDisplay(u);var blocked=isBlocked(u);
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
var avText=pp?'':disp.charAt(0).toUpperCase();
var h='<div style="text-align:left"><div class="grp-panel"><div class="gh-av" style="'+avStyle+'">'+avText+'</div><div class="gh-name">'+esc(disp)+'</div><div class="gh-meta" style="color:var(--c);letter-spacing:2px;font-family:var(--fm)">'+esc(user.userId||"—")+'</div><div class="gh-meta" style="margin-top:6px">'+(isOnline(user)?"Online":"Offline")+'</div>'+(blocked?'<div class="gh-meta" style="color:#fca5a5;margin-top:6px">Diblokir</div>':'')+'</div>';
h+='<div class="grp-sec">';
if(!blocked){
h+='<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){openChatRoom(\''+esc(u)+'\')},100)"><i class="fas fa-comments" style="color:var(--n);width:20px"></i> Buka Chat</button>';
h+='<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){startCall(\''+esc(u)+'\',false)},100)"><i class="fas fa-phone" style="color:var(--n);width:20px"></i> Voice Call</button>';
h+='<button class="grp-act-btn" onclick="closeModal();setTimeout(function(){startCall(\''+esc(u)+'\',true)},100)"><i class="fas fa-video" style="color:var(--c);width:20px"></i> Video Call</button>';
}
h+='<button class="grp-act-btn '+(blocked?'':'danger')+'" onclick="closeModal();setTimeout(function(){toggleBlockUser(\''+esc(u)+'\')},100)"><i class="fas fa-ban" style="width:20px"></i> '+(blocked?"Buka Blokir":"Blokir")+'</button></div></div>';
showModal("fa-user","INFO KONTAK",h,"TUTUP",null,"var(--n)");
};

function migrateLocalContacts(){
try{var old=localStorage.getItem("damz_contacts_"+CURRENT_USER);var v6=localStorage.getItem("damz_contacts_v6_"+CURRENT_USER);if(old&&!v6){localStorage.setItem("damz_contacts_v6_"+CURRENT_USER,old);}}catch(e){}
}
window.migrateLocalContacts=migrateLocalContacts;

function watchNewMessages(){
if(!db||!CURRENT_USER||watchNewMessages._done)return;
watchNewMessages._done=true;
var lastSeen=Date.now();
db.ref("chats").on("child_changed",function(snap){
var rk=snap.key;
if(rk.indexOf("dm_")!==0)return;
if(rk.indexOf(CURRENT_USER)<0)return;
var room=snap.val()||{};
var keys=Object.keys(room).filter(function(k){return k!=="typing"&&k!=="reads"&&k!=="pinnedMessage";});
if(!keys.length)return;
var lastKey=keys[keys.length-1];
var m=room[lastKey];
if(!m.from||m.from===CURRENT_USER)return;
if(!m.timestamp||m.timestamp<=lastSeen)return;
lastSeen=m.timestamp;
var partner=rk.replace("dm_","").split("__");
partner=partner[0]===CURRENT_USER?partner[1]:partner[0];
if(!chatGetContact(partner))return;
if(isBlocked(partner))return;
var isActive=(CHATv1.currentRoom&&CHATv1.currentRoom.type==="user"&&CHATv1.currentRoom.id===partner&&document.querySelector(".pg.on")&&document.querySelector(".pg.on").id==="chatPage");
var unreadKey="damz_unread_"+rk;
if(!isActive){
var curUnread=parseInt(localStorage.getItem(unreadKey)||"0")+1;
localStorage.setItem(unreadKey,String(curUnread));
updateBadgesUI();
var preview=m.voice?"Voice":(m.mediaType==="photo"?"Foto":(m.mediaType==="video"?"Video":(m.mediaType==="sticker"?"Sticker":(m.text||""))));
showAndroidNotif("chat",chatDisplayName(partner),preview,function(){showChatPage();setTimeout(function(){openChatRoom(partner);},120);});
}
});
}
window.watchNewMessages=watchNewMessages;

function scrollToBottom(smooth){
var box=$("chatMessages");if(!box)return;
requestAnimationFrame(function(){
var target=box.scrollHeight;
if(smooth){try{box.scrollTo({top:target,behavior:"smooth"});}catch(e){box.scrollTop=target;}}
else box.scrollTop=target;
setTimeout(function(){box.scrollTop=box.scrollHeight;},100);
setTimeout(function(){box.scrollTop=box.scrollHeight;},300);
});
}

function renderPinnedBanner(msg){
var wrap=$("pinnedWrap");if(!wrap)return;
if(!msg){wrap.innerHTML="";return;}
var preview=msg.text||(msg.voice?"Voice note":(msg.mediaType==="photo"?"Foto":"Pesan"));
wrap.innerHTML='<div class="cv1-pinned-banner" onclick="scrollToPinnedMsg(\''+esc(msg._key)+'\')"><div class="pb-icon"><i class="fas fa-thumbtack"></i></div><div class="pb-body"><div class="pb-lbl">DISEMATKAN</div><div class="pb-text">'+esc(preview)+'</div></div><button class="pb-close" onclick="event.stopPropagation();unpinMessage()"><i class="fas fa-times"></i></button></div>';
}
window.renderPinnedBanner=renderPinnedBanner;

function scrollToPinnedMsg(mk){
var box=$("chatMessages");if(!box||!mk)return;
var el=box.querySelector("[data-msgkey='"+mk+"']");
if(el){el.scrollIntoView({behavior:"smooth",block:"center"});el.style.transition="all .3s";el.style.boxShadow="0 0 30px rgba(168,85,247,.8)";setTimeout(function(){el.style.boxShadow="";},1500);}
}
window.scrollToPinnedMsg=scrollToPinnedMsg;

window.pinMessage=function(mk){
var rk=getRoomKey();if(!rk||!db)return;
var box=$("chatMessages");
var el=box?box.querySelector("[data-msgkey='"+mk+"']"):null;
var txt="";
if(el){
var clone=el.cloneNode(true);
clone.querySelectorAll("button,audio,video,.cv1-msg-meta,.cv1-msg-author").forEach(function(x){x.remove();});
txt=(clone.textContent||"").trim();
}
db.ref(rk+"/pinnedMessage").set({_key:mk,text:txt,from:CURRENT_USER,time:new Date().toISOString()}).then(function(){
toast("Pesan disematkan","pin");
closeModal();
}).catch(function(){toast("Gagal pin","err");});
};

window.unpinMessage=function(){
var rk=getRoomKey();if(!rk||!db)return;
showModal("fa-thumbtack","UNPIN PESAN","Lepas sematan pesan ini?","UNPIN",function(){
db.ref(rk+"/pinnedMessage").remove().then(function(){
toast("Unpin berhasil","ok");
CHATv1.pinnedMessage=null;
renderPinnedBanner(null);
closeModal();
}).catch(function(){closeModal();});
},"var(--r)");
};

document.addEventListener("visibilitychange",function(){
if(document.visibilityState==="visible"&&CURRENT_USER&&db){
try{db.ref("members/"+CURRENT_USER+"/lastPing").set(new Date().toISOString());}catch(e){}
}
});

function groupGetList(){try{return JSON.parse(localStorage.getItem("damz_groups_v7_"+CURRENT_USER)||"[]");}catch(e){return[];}}
function groupSaveList(l){try{localStorage.setItem("damz_groups_v7_"+CURRENT_USER,JSON.stringify(l));}catch(e){}}
function genGroupCode(){var c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";var s="";for(var i=0;i<8;i++)s+=c.charAt(Math.floor(Math.random()*c.length));return s;}
window.groupGetList=groupGetList;
window.groupSaveList=groupSaveList;
window.genGroupCode=genGroupCode;
