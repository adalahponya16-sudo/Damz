
var CALL_STATE={active:false,incoming:false,isGroup:false,groupId:null,groupName:null,members:[],peer:null,callId:null,ref:null,listeners:[],startTime:0,timer:null,isCaller:false,muted:false,speaker:false,videoMode:false,cameraOn:false,localStream:null,pcs:{},remoteAudios:{},remoteVideos:{},activeMembers:[],inviteData:null,facing:"user"};
window.CALL_STATE=CALL_STATE;
function genCallId(){return "call_"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function openCallScreen(){var cs=$("callScreen");if(!cs)return;cs.style.display="flex";cs.classList.add("on");document.body.style.overflow="hidden";try{requestWakeLock();}catch(e){}try{callNative("openCallActivity",[]);}catch(e){}if(IS_OWNER){var vfx=$("btnVoiceFx");if(vfx)vfx.style.display="flex";}}
function closeCallScreen(){var cs=$("callScreen");if(!cs)return;cs.classList.remove("on");cs.style.display="none";document.body.style.overflow="";try{releaseWakeLock();}catch(e){}try{closeWebCallNotif();}catch(e){}try{callNative("closeCallActivity",[]);}catch(e){}}

function preRequestMedia(videoMode){
return new Promise(function(resolve,reject){
if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){reject(new Error("Browser tidak support kamera/mic"));return;}
var constraints={audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:videoMode?{width:{ideal:1280},height:{ideal:720},facingMode:"user"}:false};
navigator.mediaDevices.getUserMedia(constraints).then(function(stream){
try{stream.getTracks().forEach(function(t){t.stop();});}catch(e){}
resolve(true);
}).catch(reject);
});
}

function getUserMediaStream(videoMode,facing){
return new Promise(function(resolve,reject){
if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){reject(new Error("Browser tidak support"));return;}
var videoConstraints=videoMode?{width:{ideal:1920,min:1280},height:{ideal:1080,min:720},frameRate:{ideal:30,max:30},facingMode:facing||CALL_STATE.facing||"user"}:false;
var constraints={audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,sampleRate:48000,channelCount:1},video:videoConstraints};
navigator.mediaDevices.getUserMedia(constraints).then(function(stream){
var vt=stream.getVideoTracks()[0];
if(vt&&vt.applyConstraints){
vt.applyConstraints({width:1920,height:1080,frameRate:30}).catch(function(){
vt.applyConstraints({width:1280,height:720,frameRate:30}).catch(function(){
vt.applyConstraints({width:640,height:480,frameRate:30}).catch(function(){});
});
});
}
resolve(stream);
}).catch(function(err){
if(videoMode){
navigator.mediaDevices.getUserMedia({audio:true,video:{width:{ideal:1280},height:{ideal:720},facingMode:facing||"user"}}).then(resolve).catch(function(){
navigator.mediaDevices.getUserMedia({audio:true,video:{facingMode:facing||"user"}}).then(resolve).catch(reject);
});
}else reject(err);
});
});
}

function updateQualityBars(state){var q=document.querySelector(".call-quality");if(!q)return;q.classList.remove("poor","medium");if(state==="poor")q.classList.add("poor");else if(state==="medium")q.classList.add("medium");}

function setupDraggablePreview(){
var prev=$("videoPreview");
if(!prev||prev._draggableBound)return;
prev._draggableBound=true;
var startX=0,startY=0,initRight=0,initTop=0,dragging=false,moved=false;
var winW=window.innerWidth,winH=window.innerHeight;
function pointerDown(e){
var t=e.touches?e.touches[0]:e;
if(!t)return;
dragging=true;moved=false;
startX=t.clientX;startY=t.clientY;
var rect=prev.getBoundingClientRect();
initRight=winW-rect.right;
initTop=rect.top;
prev.style.transition="none";
}
function pointerMove(e){
if(!dragging)return;
var t=e.touches?e.touches[0]:e;
if(!t)return;
var dx=t.clientX-startX;
var dy=t.clientY-startY;
if(Math.abs(dx)>5||Math.abs(dy)>5)moved=true;
if(!moved)return;
e.preventDefault();
var newRight=Math.max(8,Math.min(winW-prev.offsetWidth-8,initRight-dx));
var newTop=Math.max(80,Math.min(winH-prev.offsetHeight-100,initTop+dy));
prev.style.right=newRight+"px";
prev.style.top=newTop+"px";
}
function pointerUp(){
if(!dragging)return;
dragging=false;
prev.style.transition="transform .3s cubic-bezier(.34,1.4,.64,1)";
}
if(window.PointerEvent){
prev.addEventListener("pointerdown",pointerDown);
document.addEventListener("pointermove",pointerMove,{passive:false});
document.addEventListener("pointerup",pointerUp);
document.addEventListener("pointercancel",pointerUp);
}else{
prev.addEventListener("touchstart",pointerDown,{passive:true});
document.addEventListener("touchmove",pointerMove,{passive:false});
document.addEventListener("touchend",pointerUp);
prev.addEventListener("mousedown",pointerDown);
document.addEventListener("mousemove",pointerMove);
document.addEventListener("mouseup",pointerUp);
}
}
window.setupDraggablePreview=setupDraggablePreview;

function startCall(peerUser,videoMode){
if(!db||!CURRENT_USER){toast("DB not ready","err");return;}
if(!peerUser||peerUser===CURRENT_USER){toast("Tidak bisa call diri sendiri","err");return;}
if(CALL_STATE.active||CALL_STATE.incoming){toast("Masih ada panggilan aktif","err");return;}
if(!chatGetContact(peerUser)){toast("Tambahkan kontak dulu","err");return;}
if(isBlocked(peerUser)){toast("Kontak diblokir","err");return;}
toast(videoMode?"Minta izin kamera...":"Minta izin mic...","ok");
preRequestMedia(videoMode).then(function(){doStartCall(peerUser,videoMode);}).catch(function(err){
showModal("fa-exclamation-triangle","IZIN DITOLAK","<div style='text-align:left'><b style='color:var(--r)'>Izin "+(videoMode?"Kamera/Mic":"Mic")+" ditolak</b><br><br>Buka <b>Setting HP</b> → <b>Apps</b> → <b>DAMZ NEXUS</b> → <b>Izin</b> → aktifkan <b>"+(videoMode?"Kamera & Mikrofon":"Mikrofon")+"</b>.<br><br>Detail: "+esc(err.message||"")+"</div>","MENGERTI",null,"var(--r)");
});
}
window.startCall=startCall;

function doStartCall(peerUser,videoMode){
var callId=genCallId();
CALL_STATE.peer=peerUser;CALL_STATE.callId=callId;CALL_STATE.isCaller=true;CALL_STATE.active=true;CALL_STATE.isGroup=false;
CALL_STATE.muted=false;CALL_STATE.speaker=false;CALL_STATE.videoMode=!!videoMode;CALL_STATE.cameraOn=!!videoMode;
CALL_STATE.activeMembers=[CURRENT_USER,peerUser];CALL_STATE.pcs={};CALL_STATE.remoteAudios={};CALL_STATE.remoteVideos={};
CALL_STATE.facing="user";
var disp=chatDisplayName(peerUser);
var pp=getUserPP(peerUser);
$("callName").textContent=disp;
$("callStatus").textContent=videoMode?"Video Call...":"Memanggil...";
$("callTimer").textContent="00:00";
var av=$("callAvatar");
if(pp){av.style.backgroundImage="url("+pp+")";av.style.backgroundSize="cover";av.style.backgroundPosition="center";av.textContent="";}
else{av.style.backgroundImage="";av.textContent=disp.charAt(0).toUpperCase();}
var bg=$("callBgBlur");
if(bg&&pp){bg.style.backgroundImage="url("+pp+")";}
$("callActions").style.display="flex";
$("callIncomingActions").style.display="none";
$("callWaves").classList.remove("paused");
$("callScreen").classList.remove("group-mode");
if(videoMode)$("callScreen").classList.add("video-mode");else $("callScreen").classList.remove("video-mode");
updateQualityBars("good");
openCallScreen();
db.ref("calls/"+callId).set({from:CURRENT_USER,to:peerUser,videoMode:!!videoMode,isGroup:false,status:"ringing",createdAt:Date.now(),offer:null,answer:null}).then(function(){
initWebRTC(callId,true,videoMode,peerUser).then(function(){
watchCallRoom(callId,true);
setupDraggablePreview();
}).catch(function(e){toast("Gagal: "+e.message,"err");cleanupCall();});
}).catch(function(e){toast("Gagal call: "+e.message,"err");cleanupCall();});
}

function watchIncomingCall(){
if(!db||!CURRENT_USER)return;
if(watchIncomingCall._done)return;
watchIncomingCall._done=true;
var ref1=db.ref("calls").orderByChild("to").equalTo(CURRENT_USER);
var h1=ref1.on("child_added",function(snap){
var c=snap.val();if(!c)return;
if(c.status!=="ringing")return;
if(c.isGroup)return;
if(Date.now()-(c.createdAt||0)>60000)return;
if(CALL_STATE.active||CALL_STATE.incoming)return;
if(isBlocked(c.from))return;
showIncomingCall(snap.key,c);
});
var ref2=db.ref("callInvites/"+CURRENT_USER);
var h2=ref2.on("child_added",function(snap){
var inv=snap.val();if(!inv)return;
if(Date.now()-(inv.time||0)>60000){snap.ref.remove();return;}
if(CALL_STATE.active||CALL_STATE.incoming)return;
if(isBlocked(inv.from))return;
showGroupCallNotif(snap.key,inv);
});
window._incomingCallRefs={ref1:ref1,h1:h1,ref2:ref2,h2:h2};
}
window.watchIncomingCall=watchIncomingCall;

function showIncomingCall(callId,c){
CALL_STATE.incoming=true;CALL_STATE.callId=callId;CALL_STATE.peer=c.from;CALL_STATE.isCaller=false;CALL_STATE.isGroup=false;CALL_STATE.videoMode=!!c.videoMode;CALL_STATE.cameraOn=false;
var disp=chatDisplayName(c.from);
var callType=c.videoMode?"Video Call":"Voice Call";
showCallNotifBanner(c.from,callType,function(){acceptCall();},function(){rejectCall();});
try{playRingtone();}catch(e){}
try{triggerNativeRingSound();}catch(e){}
var sentNative=false;
try{sentNative=triggerNativeCallNotif(disp,callType,callId);}catch(e){}
if(!sentNative){try{webCallNotif(disp,callType,callId);}catch(e){}}
db.ref("calls/"+callId+"/status").on("value",function(s){
var st=s.val();
if(st==="cancelled"||st==="rejected"||st==="ended"){
if(CALL_STATE.incoming){
closeCallNotifBanner();stopNativeCallNotif();stopNativeRingSound();closeWebCallNotif();cleanupCall();
}
}
});
}

function showGroupCallNotif(inviteKey,inv){
CALL_STATE.inviteData={key:inviteKey,data:inv};
showGroupCallBanner(inv.fromDisplay||getUserDisplay(inv.from),inv.groupName,inv.videoMode,function(){
db.ref("callInvites/"+CURRENT_USER+"/"+inviteKey).remove();
joinGroupCall(inv.callId,inv);
},function(){
db.ref("callInvites/"+CURRENT_USER+"/"+inviteKey).remove();
CALL_STATE.inviteData=null;
});
try{playRingtone();}catch(e){}
try{triggerNativeRingSound();}catch(e){}
var sentNative=false;
try{sentNative=triggerNativeCallNotif(inv.groupName,inv.videoMode?"Video Call Grup":"Voice Call Grup",inv.callId);}catch(e){}
if(!sentNative){try{webCallNotif(inv.groupName,inv.videoMode?"Video Call Grup":"Voice Call Grup",inv.callId);}catch(e){}}
}

var RING_CTX=null,RING_INTERVAL=null;
function playRingtone(){
try{
if(RING_CTX)return;
RING_CTX=new (window.AudioContext||window.webkitAudioContext)();
var play=function(){
if(!RING_CTX)return;
try{
var o1=RING_CTX.createOscillator();var g1=RING_CTX.createGain();
o1.connect(g1);g1.connect(RING_CTX.destination);
o1.frequency.value=800;o1.type="sine";
g1.gain.setValueAtTime(0,RING_CTX.currentTime);
g1.gain.linearRampToValueAtTime(0.5,RING_CTX.currentTime+0.1);
g1.gain.linearRampToValueAtTime(0,RING_CTX.currentTime+0.5);
o1.start();o1.stop(RING_CTX.currentTime+0.6);
var o2=RING_CTX.createOscillator();var g2=RING_CTX.createGain();
o2.connect(g2);g2.connect(RING_CTX.destination);
o2.frequency.value=600;o2.type="sine";
g2.gain.setValueAtTime(0,RING_CTX.currentTime+0.4);
g2.gain.linearRampToValueAtTime(0.5,RING_CTX.currentTime+0.5);
g2.gain.linearRampToValueAtTime(0,RING_CTX.currentTime+0.9);
o2.start(RING_CTX.currentTime+0.4);o2.stop(RING_CTX.currentTime+1.0);
if(navigator.vibrate)navigator.vibrate([400,200,400]);
}catch(e){}
};
play();
RING_INTERVAL=setInterval(play,1500);
}catch(e){}
}
function stopRingtone(){
try{if(RING_INTERVAL)clearInterval(RING_INTERVAL);RING_INTERVAL=null;if(RING_CTX){RING_CTX.close();RING_CTX=null;}}catch(e){}
try{navigator.vibrate(0);}catch(e){}
}

function acceptCall(){
if(!CALL_STATE.incoming)return;
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
closeCallNotifBanner();
var callId=CALL_STATE.callId;
db.ref("calls/"+callId+"/status").set("accepted");
db.ref("calls/"+callId+"/acceptedAt").set(Date.now());
CALL_STATE.incoming=false;CALL_STATE.active=true;CALL_STATE.startTime=Date.now();
$("callStatus").textContent="Terhubung";
$("callActions").style.display="flex";
$("callIncomingActions").style.display="none";
openCallScreen();
startCallTimer();
initWebRTC(callId,false,CALL_STATE.videoMode,CALL_STATE.peer).then(function(){
watchCallRoom(callId,false);
$("callStatus").textContent="Terhubung";
setupDraggablePreview();
}).catch(function(e){toast("Gagal: "+e.message,"err");cleanupCall();});
}
window.acceptCall=acceptCall;

function startCallTimer(){
CALL_STATE.startTime=Date.now();
if(CALL_STATE.timer)clearInterval(CALL_STATE.timer);
CALL_STATE.timer=setInterval(function(){
var e=Date.now()-CALL_STATE.startTime;
var s=Math.floor(e/1000);var m=Math.floor(s/60);s=s%60;
var el=$("callTimer");
if(el)el.textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
},500);
}

function initWebRTC(callId,isCaller,videoMode,peerUser){
return new Promise(function(resolve,reject){
getUserMediaStream(videoMode).then(function(stream){
CALL_STATE.localStream=stream;
if(videoMode){
var lv=$("localVideo");
if(lv){lv.srcObject=stream;lv.play().catch(function(){});}
$("videoPreview").classList.add("on");
setupDraggablePreview();
}
var pc=new RTCPeerConnection(ICE_SERVERS);
CALL_STATE.pcs[peerUser||"peer"]=pc;
stream.getTracks().forEach(function(t){pc.addTrack(t,stream);});
pc.oniceconnectionstatechange=function(){
if(pc.iceConnectionState==="failed"||pc.iceConnectionState==="disconnected"){
var el=$("callStatus");if(el)el.textContent="Menyambung ulang...";
updateQualityBars("poor");
try{pc.restartIce();}catch(e){}
if(CALL_STATE.isCaller&&CALL_STATE.callId){
setTimeout(function(){
pc.createOffer({iceRestart:true}).then(function(o){return pc.setLocalDescription(o);}).then(function(){
return db.ref("calls/"+callId+"/offer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp,restart:Date.now()});
}).catch(function(){});
},800);
}
}
if(pc.iceConnectionState==="connected"){
var el2=$("callStatus");if(el2&&CALL_STATE.active)el2.textContent="Terhubung";
updateQualityBars("good");
}
};
pc.ontrack=function(ev){
if(videoMode){
var rv=$("remoteVideo");
if(rv){rv.srcObject=ev.streams[0];rv.play().catch(function(){});}
$("callScreen").classList.add("video-mode");
}
else{
if(!CALL_STATE.remoteAudios[peerUser]){
var audio=document.createElement("audio");
audio.autoplay=true;audio.id="remoteAudio";audio.style.display="none";
document.body.appendChild(audio);
CALL_STATE.remoteAudios[peerUser]=audio;
}
CALL_STATE.remoteAudios[peerUser].srcObject=ev.streams[0];
CALL_STATE.remoteAudios[peerUser].play().catch(function(){});
}
};
pc.onicecandidate=function(ev){
if(ev.candidate){
var ref=db.ref("calls/"+callId+(isCaller?"/callerCandidates":"/calleeCandidates"));
ref.push(ev.candidate.toJSON());
}
};
if(isCaller){
pc.createOffer().then(function(offer){return pc.setLocalDescription(offer);}).then(function(){return db.ref("calls/"+callId+"/offer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp});}).then(resolve).catch(reject);
}else{
var offerRef=db.ref("calls/"+callId+"/offer");
offerRef.once("value").then(function(snap){
var offer=snap.val();if(!offer){reject(new Error("No offer"));return;}
return pc.setRemoteDescription(new RTCSessionDescription(offer)).then(function(){return pc.createAnswer();}).then(function(answer){return pc.setLocalDescription(answer);}).then(function(){return db.ref("calls/"+callId+"/answer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp});}).then(resolve);
}).catch(reject);
}
}).catch(reject);
});
}

function watchCallRoom(callId,isCaller){
CALL_STATE.ref=db.ref("calls/"+callId);
CALL_STATE.listeners=[];
var isGroup=CALL_STATE.isGroup;
if(!isGroup){
var offerListener=CALL_STATE.ref.child("offer").on("value",function(snap){
var offer=snap.val();if(!offer)return;
if(isCaller)return;
var pc=CALL_STATE.pcs[CALL_STATE.peer];if(!pc)return;
if(pc.remoteDescription)return;
pc.setRemoteDescription(new RTCSessionDescription(offer)).then(function(){return pc.createAnswer();}).then(function(answer){return pc.setLocalDescription(answer);}).then(function(){return db.ref("calls/"+callId+"/answer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp});}).catch(function(){});
});
CALL_STATE.listeners.push({ref:CALL_STATE.ref.child("offer"),h:offerListener});
var answerListener=CALL_STATE.ref.child("answer").on("value",function(snap){
var answer=snap.val();if(!answer)return;
if(!isCaller)return;
var pc=CALL_STATE.pcs[CALL_STATE.peer];if(!pc)return;
if(pc.remoteDescription)return;
pc.setRemoteDescription(new RTCSessionDescription(answer)).then(function(){$("callStatus").textContent="Terhubung";startCallTimer();}).catch(function(){});
});
CALL_STATE.listeners.push({ref:CALL_STATE.ref.child("answer"),h:answerListener});
var peerCol=isCaller?"calleeCandidates":"callerCandidates";
var candRef=CALL_STATE.ref.child(peerCol);
var candListener=candRef.on("child_added",function(snap){
var c=snap.val();if(!c)return;
var pc=CALL_STATE.pcs[CALL_STATE.peer];if(!pc)return;
try{pc.addIceCandidate(new RTCIceCandidate(c));}catch(e){}
});
CALL_STATE.listeners.push({ref:candRef,h:candListener});
}
var statusListener=CALL_STATE.ref.child("status").on("value",function(snap){
var st=snap.val();
if(st==="ended"||st==="rejected"||st==="cancelled"){
if(CALL_STATE.active||CALL_STATE.incoming){
toast(st==="rejected"?"Ditolak":(st==="cancelled"?"Dibatalkan":"Diakhiri"),"err");
cleanupCall();
}
}else if(st==="accepted"&&isCaller&&!isGroup){
$("callStatus").textContent="Terhubung";
if(!CALL_STATE.timer)startCallTimer();
}
});
CALL_STATE.listeners.push({ref:CALL_STATE.ref.child("status"),h:statusListener});
}

function startGroupCall(gid,gname,videoMode){
if(!db||!CURRENT_USER){toast("DB not ready","err");return;}
if(CALL_STATE.active||CALL_STATE.incoming){toast("Masih ada panggilan aktif","err");return;}
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();if(!g){toast("Grup tidak ditemukan","err");return;}
var members=g.members||[];
if(members.indexOf(CURRENT_USER)<0){toast("Kamu bukan member","err");return;}
if(members.length>10){toast("Grup terlalu besar (max 10)","err");return;}
if(members.length>6){
showModal("fa-exclamation-triangle","PERINGATAN","Grup ini punya <b>"+members.length+" orang</b>.<br><br>Group call lebih dari 6 orang bisa <b style='color:var(--r)'>LAG PARAH</b>.<br><br>Lanjut?","LANJUT",function(){closeModal();preRequestMedia(videoMode).then(function(){doStartGroupCall(gid,gname,members,videoMode);}).catch(function(err){toast("Izin ditolak: "+err.message,"err");});},"var(--g)");
}else{
preRequestMedia(videoMode).then(function(){doStartGroupCall(gid,gname,members,videoMode);}).catch(function(err){toast("Izin ditolak: "+err.message,"err");});
}
});
}
window.startGroupCall=startGroupCall;

function doStartGroupCall(gid,gname,members,videoMode){
var callId=genCallId();
CALL_STATE.callId=callId;CALL_STATE.isCaller=true;CALL_STATE.active=true;CALL_STATE.isGroup=true;
CALL_STATE.groupId=gid;CALL_STATE.groupName=gname;CALL_STATE.members=members;
CALL_STATE.muted=false;CALL_STATE.speaker=false;CALL_STATE.videoMode=!!videoMode;CALL_STATE.cameraOn=!!videoMode;
CALL_STATE.activeMembers=[CURRENT_USER];CALL_STATE.pcs={};CALL_STATE.remoteAudios={};CALL_STATE.remoteVideos={};
CALL_STATE.facing="user";
$("callName").textContent=gname;
$("callStatus").textContent=(videoMode?"Video Call":"Voice Call")+" • 1/"+members.length;
$("callTimer").textContent="00:00";
var av=$("callAvatar");av.style.backgroundImage="";av.textContent=gname.charAt(0).toUpperCase();
$("callActions").style.display="flex";
$("callIncomingActions").style.display="none";
$("callWaves").classList.remove("paused");
$("callScreen").classList.add("group-mode");
if(videoMode)$("callScreen").classList.add("video-mode");else $("callScreen").classList.remove("video-mode");
openCallScreen();
renderGroupCallGrid();
getUserMediaStream(videoMode).then(function(stream){
CALL_STATE.localStream=stream;
if(videoMode){
var lv=$("localVideo");
if(lv){lv.srcObject=stream;lv.play().catch(function(){});}
$("videoPreview").classList.add("on");
setupDraggablePreview();
}
db.ref("calls/"+callId).set({from:CURRENT_USER,groupId:gid,groupName:gname,videoMode:!!videoMode,isGroup:true,members:members,status:"ringing",createdAt:Date.now(),host:CURRENT_USER}).then(function(){
db.ref("calls/"+callId+"/activeMembers/"+CURRENT_USER).set(true);
watchCallRoom(callId,true);
members.forEach(function(m){
if(m===CURRENT_USER)return;
db.ref("callInvites/"+m).push({callId:callId,from:CURRENT_USER,fromDisplay:CURRENT_DISPLAY,fromId:CURRENT_ID,groupName:gname,groupId:gid,videoMode:!!videoMode,members:members,time:Date.now()});
});
});
}).catch(function(e){toast("Gagal mic/kamera: "+e.message,"err");cleanupCall();});
}

function joinGroupCall(callId,inv){
if(!db)return;
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
closeCallNotifBanner();
CALL_STATE.active=true;CALL_STATE.isGroup=true;
CALL_STATE.groupId=inv.groupId;CALL_STATE.groupName=inv.groupName;
CALL_STATE.members=inv.members||[];
CALL_STATE.videoMode=!!inv.videoMode;CALL_STATE.cameraOn=!!inv.videoMode;
CALL_STATE.callId=callId;CALL_STATE.isCaller=false;
CALL_STATE.pcs={};CALL_STATE.remoteAudios={};CALL_STATE.remoteVideos={};
CALL_STATE.facing="user";
$("callName").textContent=inv.groupName;
$("callStatus").textContent=(inv.videoMode?"Video Call":"Voice Call")+" • Menghubungkan...";
$("callTimer").textContent="00:00";
var av=$("callAvatar");av.style.backgroundImage="";av.textContent=inv.groupName.charAt(0).toUpperCase();
$("callActions").style.display="flex";
$("callIncomingActions").style.display="none";
$("callWaves").classList.remove("paused");
$("callScreen").classList.add("group-mode");
if(inv.videoMode)$("callScreen").classList.add("video-mode");else $("callScreen").classList.remove("video-mode");
openCallScreen();
renderGroupCallGrid();
getUserMediaStream(inv.videoMode).then(function(stream){
CALL_STATE.localStream=stream;
if(inv.videoMode){
var lv=$("localVideo");
if(lv){lv.srcObject=stream;lv.play().catch(function(){});}
$("videoPreview").classList.add("on");
setupDraggablePreview();
}
db.ref("calls/"+callId+"/activeMembers/"+CURRENT_USER).set(true);
connectToGroupPeers(callId);
watchCallRoom(callId,false);
startCallTimer();
$("callStatus").textContent="Terhubung";
}).catch(function(e){toast("Gagal mic/kamera: "+e.message,"err");cleanupCall();});
}

function connectToGroupPeers(callId){
db.ref("calls/"+callId+"/activeMembers").on("value",function(snap){
var active=snap.val()||{};
var activeList=Object.keys(active);
CALL_STATE.activeMembers=activeList;
updateGroupCallStatus();
activeList.forEach(function(m){
if(m===CURRENT_USER)return;
if(CALL_STATE.pcs[m])return;
var isInitiator=CURRENT_USER<m;
createPeerConnection(callId,m,isInitiator);
});
renderGroupCallGrid();
});
}

function createPeerConnection(callId,peerUser,isInitiator){
if(CALL_STATE.pcs[peerUser])return CALL_STATE.pcs[peerUser];
var pc=new RTCPeerConnection(ICE_SERVERS);
CALL_STATE.pcs[peerUser]=pc;
if(CALL_STATE.localStream){
CALL_STATE.localStream.getTracks().forEach(function(t){pc.addTrack(t,CALL_STATE.localStream);});
}
pc.oniceconnectionstatechange=function(){
if(pc.iceConnectionState==="failed"||pc.iceConnectionState==="disconnected"){
var el=$("callStatus");if(el)el.textContent="Menyambung ulang...";
updateQualityBars("poor");
try{pc.restartIce();}catch(e){}
if(CALL_STATE.isCaller&&CALL_STATE.callId){
var roomKey=CURRENT_USER<peerUser?CURRENT_USER+"_"+peerUser:peerUser+"_"+CURRENT_USER;
var roomRef=db.ref("calls/"+CALL_STATE.callId+"/mesh/"+roomKey);
setTimeout(function(){
pc.createOffer({iceRestart:true}).then(function(o){return pc.setLocalDescription(o);}).then(function(){
return roomRef.child("offer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp,from:CURRENT_USER,restart:Date.now()});
}).catch(function(){});
},800);
}
}
if(pc.iceConnectionState==="connected"){
var el2=$("callStatus");if(el2&&CALL_STATE.active)el2.textContent="Terhubung";
updateQualityBars("good");
}
};
pc.onicecandidate=function(ev){
if(ev.candidate){
var ref=db.ref("calls/"+callId+"/mesh/"+CURRENT_USER+"_"+peerUser+"/"+CURRENT_USER+"Candidates");
ref.push(ev.candidate.toJSON());
}
};
pc.ontrack=function(ev){
if(CALL_STATE.videoMode){
CALL_STATE.remoteVideos[peerUser]=ev.streams[0];
renderGroupCallGrid();
}else{
if(!CALL_STATE.remoteAudios[peerUser]){
var audio=document.createElement("audio");
audio.autoplay=true;audio.id="grpaudio_"+peerUser;audio.style.display="none";
document.body.appendChild(audio);
CALL_STATE.remoteAudios[peerUser]=audio;
}
CALL_STATE.remoteAudios[peerUser].srcObject=ev.streams[0];
CALL_STATE.remoteAudios[peerUser].play().catch(function(){});
}
};
var roomKey=CURRENT_USER<peerUser?CURRENT_USER+"_"+peerUser:peerUser+"_"+CURRENT_USER;
var roomRef=db.ref("calls/"+callId+"/mesh/"+roomKey);
if(isInitiator&&CURRENT_USER<peerUser){
pc.createOffer().then(function(offer){return pc.setLocalDescription(offer);}).then(function(){return roomRef.child("offer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp,from:CURRENT_USER});}).catch(function(){});
}
roomRef.child("offer").on("value",function(snap){
var offer=snap.val();if(!offer)return;
if(offer.from===CURRENT_USER)return;
if(pc.remoteDescription)return;
pc.setRemoteDescription(new RTCSessionDescription(offer)).then(function(){return pc.createAnswer();}).then(function(answer){return pc.setLocalDescription(answer);}).then(function(){return roomRef.child("answer").set({type:pc.localDescription.type,sdp:pc.localDescription.sdp,from:CURRENT_USER});}).catch(function(){});
});
roomRef.child("answer").on("value",function(snap){
var answer=snap.val();if(!answer)return;
if(answer.from===CURRENT_USER)return;
if(pc.remoteDescription)return;
pc.setRemoteDescription(new RTCSessionDescription(answer)).catch(function(){});
});
roomRef.child(peerUser+"Candidates").on("child_added",function(snap){
var c=snap.val();if(!c)return;
try{pc.addIceCandidate(new RTCIceCandidate(c));}catch(e){}
});
return pc;
}

function renderGroupCallGrid(){
var wrap=$("groupCallGrid");if(!wrap)return;
var members=CALL_STATE.members||[];
var html="";
members.forEach(function(m){
var isActive=CALL_STATE.activeMembers.indexOf(m)>=0;
var pp=getUserPP(m);var disp=getUserDisplay(m);
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
var avText=pp?'':disp.charAt(0).toUpperCase();
var isMe=m===CURRENT_USER;
html+='<div class="grp-member-card'+(isActive?' active':'')+'">';
if(isActive&&CALL_STATE.videoMode){html+='<video id="grpvid_'+esc(m)+'" autoplay playsinline'+(isMe?' muted':'')+'></video>';}
else{html+='<div class="grp-member-av" style="'+avStyle+'">'+avText+'</div>';}
html+='<div class="grp-member-name">'+esc(disp)+(isMe?' (Kamu)':'')+'</div>';
if(!isActive){html+='<div class="grp-member-mute" style="background:rgba(107,114,128,.9)"><i class="fas fa-hourglass-half"></i></div>';}
else if(!isMe&&CALL_STATE.videoMode){html+='<div class="grp-member-mute" style="background:rgba(16,185,129,.9)"><i class="fas fa-video"></i></div>';}
else if(isMe&&CALL_STATE.muted){html+='<div class="grp-member-mute"><i class="fas fa-microphone-slash"></i></div>';}
html+='</div>';
});
wrap.innerHTML=html;
setTimeout(function(){
members.forEach(function(m){
if(m===CURRENT_USER){if(CALL_STATE.localStream){var lv=$("grpvid_"+m);if(lv)lv.srcObject=CALL_STATE.localStream;}}
else{if(CALL_STATE.remoteVideos[m]){var rv=$("grpvid_"+m);if(rv)rv.srcObject=CALL_STATE.remoteVideos[m];}}
});
},100);
}

function updateGroupCallStatus(){
var total=(CALL_STATE.members||[]).length;
var active=CALL_STATE.activeMembers.length;
var el=$("callStatus");
if(el)el.textContent=(CALL_STATE.videoMode?"Video Call":"Voice Call")+" • "+active+"/"+total;
}

function toggleMute(){
CALL_STATE.muted=!CALL_STATE.muted;
var btn=$("btnMute");
if(btn){
if(CALL_STATE.muted){btn.classList.add("active");btn.innerHTML='<i class="fas fa-microphone-slash"></i>';toast("Mic OFF","ok");}
else{btn.classList.remove("active");btn.innerHTML='<i class="fas fa-microphone"></i>';toast("Mic ON","ok");}
}
if(CALL_STATE.localStream){CALL_STATE.localStream.getAudioTracks().forEach(function(t){t.enabled=!CALL_STATE.muted;});}
if(CALL_STATE.isGroup)renderGroupCallGrid();
}
window.toggleMute=toggleMute;

function toggleSpeaker(){
CALL_STATE.speaker=!CALL_STATE.speaker;
var btn=$("btnSpeaker");
if(btn){
if(CALL_STATE.speaker){btn.classList.add("active");btn.innerHTML='<i class="fas fa-volume-up"></i>';toast("Speaker ON","ok");}
else{btn.classList.remove("active");btn.innerHTML='<i class="fas fa-volume-down"></i>';toast("Speaker OFF","ok");}
}
Object.keys(CALL_STATE.remoteAudios).forEach(function(k){var a=CALL_STATE.remoteAudios[k];if(a)a.volume=CALL_STATE.speaker?1.0:0.5;});
try{callNative("setSpeaker",[CALL_STATE.speaker?"on":"off"]);}catch(e){}
}
window.toggleSpeaker=toggleSpeaker;

function toggleCamera(){
if(!CALL_STATE.videoMode){toast("Voice call","err");return;}
CALL_STATE.cameraOn=!CALL_STATE.cameraOn;
var btn=$("btnCamera");
if(btn){
if(CALL_STATE.cameraOn){btn.classList.add("active");btn.innerHTML='<i class="fas fa-video"></i>';toast("Kamera ON","ok");}
else{btn.classList.remove("active");btn.innerHTML='<i class="fas fa-video-slash"></i>';toast("Kamera OFF","ok");}
}
if(CALL_STATE.localStream){CALL_STATE.localStream.getVideoTracks().forEach(function(t){t.enabled=CALL_STATE.cameraOn;});}
if(CALL_STATE.isGroup)renderGroupCallGrid();
}
window.toggleCamera=toggleCamera;

function flipCamera(){
if(!CALL_STATE.videoMode){toast("Voice call","err");return;}
CALL_STATE.facing=CALL_STATE.facing==="user"?"environment":"user";
if(CALL_STATE.localStream){CALL_STATE.localStream.getVideoTracks().forEach(function(t){t.stop();});}
getUserMediaStream(true,CALL_STATE.facing).then(function(newStream){
var oldVideo=CALL_STATE.localStream.getVideoTracks()[0];
CALL_STATE.localStream.removeTrack(oldVideo);
newStream.getVideoTracks().forEach(function(t){CALL_STATE.localStream.addTrack(t);});
var lv=$("localVideo");if(lv)lv.srcObject=CALL_STATE.localStream;
Object.keys(CALL_STATE.pcs).forEach(function(k){
var pc=CALL_STATE.pcs[k];if(!pc)return;
var sender=pc.getSenders().filter(function(s){return s.track&&s.track.kind==="video";})[0];
if(sender&&newStream.getVideoTracks()[0])sender.replaceTrack(newStream.getVideoTracks()[0]);
});
if(CALL_STATE.isGroup)renderGroupCallGrid();
toast("Kamera dibalik","ok");
}).catch(function(e){toast("Gagal flip: "+e.message,"err");});
}
window.flipCamera=flipCamera;

function rejectCall(){
if(!CALL_STATE.callId)return;
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
closeCallNotifBanner();
db.ref("calls/"+CALL_STATE.callId+"/status").set("rejected");
toast("Ditolak","err");
cleanupCall();
}
window.rejectCall=rejectCall;

function endCall(){
if(!CALL_STATE.callId)return;
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
closeCallNotifBanner();
var st=CALL_STATE.active?"ended":"cancelled";
db.ref("calls/"+CALL_STATE.callId+"/status").set(st);
if(CALL_STATE.isGroup){db.ref("calls/"+CALL_STATE.callId+"/activeMembers/"+CURRENT_USER).remove();}
toast("Panggilan diakhiri","ok");
cleanupCall();
}
window.endCall=endCall;

function cleanupCall(){
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
closeCallNotifBanner();
if(CALL_STATE.timer){clearInterval(CALL_STATE.timer);CALL_STATE.timer=null;}
if(CALL_STATE.listeners){
CALL_STATE.listeners.forEach(function(l){try{l.ref.off("value",l.h);}catch(e){}});
CALL_STATE.listeners=[];
}
Object.keys(CALL_STATE.pcs).forEach(function(k){try{CALL_STATE.pcs[k].close();}catch(e){}});
CALL_STATE.pcs={};
if(CALL_STATE.localStream){try{CALL_STATE.localStream.getTracks().forEach(function(t){t.stop();});}catch(e){}CALL_STATE.localStream=null;}
Object.keys(CALL_STATE.remoteAudios).forEach(function(k){try{CALL_STATE.remoteAudios[k].pause();CALL_STATE.remoteAudios[k].srcObject=null;}catch(e){}});
CALL_STATE.remoteAudios={};
CALL_STATE.remoteVideos={};
var rv=$("remoteVideo");if(rv){try{rv.srcObject=null;}catch(e){}}
var lv=$("localVideo");if(lv){try{lv.srcObject=null;}catch(e){}}
$("videoPreview").classList.remove("on");
if(CALL_STATE.ref){try{CALL_STATE.ref.off();}catch(e){}CALL_STATE.ref=null;}
closeCallScreen();
var gcg=$("groupCallGrid");if(gcg)gcg.innerHTML="";
document.querySelectorAll("audio[id^='grpaudio_']").forEach(function(a){try{a.pause();a.srcObject=null;a.remove();}catch(e){}});
CALL_STATE.active=false;CALL_STATE.incoming=false;CALL_STATE.callId=null;CALL_STATE.peer=null;CALL_STATE.groupId=null;CALL_STATE.groupName=null;CALL_STATE.startTime=0;CALL_STATE.isCaller=false;CALL_STATE.isGroup=false;CALL_STATE.videoMode=false;CALL_STATE.cameraOn=false;CALL_STATE.muted=false;CALL_STATE.speaker=false;CALL_STATE.activeMembers=[];CALL_STATE.inviteData=null;CALL_STATE.facing="user";
$("callActions").style.display="flex";
$("callIncomingActions").style.display="none";
$("callWaves").classList.add("paused");
$("callScreen").classList.remove("group-mode","video-mode");
var mb=$("btnMute");if(mb){mb.classList.remove("active");mb.innerHTML='<i class="fas fa-microphone"></i>';}
var sb=$("btnSpeaker");if(sb){sb.classList.remove("active");sb.innerHTML='<i class="fas fa-volume-up"></i>';}
var cb=$("btnCamera");if(cb){cb.classList.remove("active");cb.innerHTML='<i class="fas fa-video"></i>';}
}
window.cleanupCall=cleanupCall;

function showCallNotifBanner(fromUser,callType,onAccept,onReject){
var pp=getUserPP(fromUser);var disp=chatDisplayName(fromUser);
var av=$("cnAvatar");
if(pp){av.style.backgroundImage="url("+pp+")";av.style.backgroundSize="cover";av.style.backgroundPosition="center";av.textContent="";}
else{av.style.backgroundImage="";av.textContent=disp.charAt(0).toUpperCase();}
$("cnName").textContent=disp;
$("cnType").textContent=callType.toUpperCase();
var d=new Date();
$("cnTime").textContent=String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
$("callNotif").classList.add("on");
var accBtn=document.querySelector(".call-notif .cn-btn.accept");
var rejBtn=document.querySelector(".call-notif .cn-btn.reject");
accBtn.onclick=function(){closeCallNotifBanner();if(onAccept)onAccept();};
rejBtn.onclick=function(){closeCallNotifBanner();if(onReject)onReject();};
}
window.showCallNotifBanner=showCallNotifBanner;

function showGroupCallBanner(fromDisplay,groupName,videoMode,onJoin,onReject){
var av=$("cnAvatar");
av.style.backgroundImage="";
av.textContent=groupName.charAt(0).toUpperCase();
$("cnName").textContent=groupName;
$("cnType").textContent=(videoMode?"VIDEO":"VOICE")+" • "+fromDisplay;
var d=new Date();
$("cnTime").textContent=String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
$("callNotif").classList.add("on");
var accBtn=document.querySelector(".call-notif .cn-btn.accept");
var rejBtn=document.querySelector(".call-notif .cn-btn.reject");
accBtn.onclick=function(){closeCallNotifBanner();if(onJoin)onJoin();};
rejBtn.onclick=function(){closeCallNotifBanner();if(onReject)onReject();};
}

function closeCallNotifBanner(){var el=$("callNotif");if(el)el.classList.remove("on");}
window.closeCallNotifBanner=closeCallNotifBanner;

function acceptIncomingCallNotif(){
var el=$("callNotif");
if(!el)return;
if(CALL_STATE.incoming)acceptCall();
else if(CALL_STATE.inviteData){
var inv=CALL_STATE.inviteData.data;
try{db.ref("callInvites/"+CURRENT_USER+"/"+CALL_STATE.inviteData.key).remove();}catch(e){}
joinGroupCall(inv.callId,inv);
}
}
window.acceptIncomingCallNotif=acceptIncomingCallNotif;

function rejectIncomingCallNotif(){
closeCallNotifBanner();
stopRingtone();
try{stopNativeRingSound();}catch(e){}
try{stopNativeCallNotif();}catch(e){}
closeWebCallNotif();
if(CALL_STATE.incoming)rejectCall();
else if(CALL_STATE.inviteData){
try{db.ref("callInvites/"+CURRENT_USER+"/"+CALL_STATE.inviteData.key).remove();}catch(e){}
CALL_STATE.inviteData=null;
}
}
window.rejectIncomingCallNotif=rejectIncomingCallNotif;

window.addEventListener("beforeunload",function(){
if(CALL_STATE.callId&&db){
try{db.ref("calls/"+CALL_STATE.callId+"/status").set("ended");}catch(e){}
if(CALL_STATE.isGroup){try{db.ref("calls/"+CALL_STATE.callId+"/activeMembers/"+CURRENT_USER).remove();}catch(e){}}
}
});

window.addEventListener("orientationchange",function(){
setTimeout(function(){
var prev=$("videoPreview");
if(prev&&CALL_STATE.active){
prev.style.right="14px";
prev.style.top="calc(80px + env(safe-area-inset-top,0))";
}
},300);
});

window.openCallVoiceFx=function(){
if(!IS_OWNER){toast("Fitur khusus Owner","err");return;}
var h='<div id="voiceChangerUI"></div>';
showModal("fa-wave-square","VOICE CHANGER (OWNER)",h,"TUTUP",null,"var(--p)");
setTimeout(function(){if(typeof vcRenderUI==="function")vcRenderUI();},100);
};
