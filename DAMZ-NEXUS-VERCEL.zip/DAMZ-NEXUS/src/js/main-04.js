
window.openCreateGroupModal=function(){
var h='<div style="text-align:left">'+
'<div class="info-box" style="font-size:.62rem;line-height:1.6">Buat grup dulu, nanti tambah anggota atau bagikan link. Simple.</div>'+
'<label class="lbl">Nama Grup</label><input class="inp" id="grpNameInput" placeholder="Nama grup" maxlength="40">'+
'<label class="lbl">Deskripsi (opsional)</label><input class="inp" id="grpDescInput" placeholder="Deskripsi" maxlength="80">'+
'<label class="lbl">Mode Gabung</label>'+
'<div class="mode-pick">'+
'<div class="mode-card on" id="modeOpen" onclick="pickJoinMode(\'open\')"><i class="fas fa-door-open"></i><div class="mc-title">OPEN</div><div class="mc-desc">Siapa pun bisa langsung join via link</div></div>'+
'<div class="mode-card" id="modeApproval" onclick="pickJoinMode(\'approval\')"><i class="fas fa-user-shield"></i><div class="mc-title">APPROVAL</div><div class="mc-desc">Owner harus approve dulu</div></div>'+
'</div>'+
'<div id="grpCreateErr" style="color:#fca5a5;font-size:.62rem;text-align:center;min-height:16px;margin-bottom:6px"></div>'+
'</div>';
window._grpJoinMode="open";
showModal("fa-users","BUAT GRUP BARU",h,"BUAT",function(){createNewGroup();},"var(--c)");
};

window.pickJoinMode=function(mode){
window._grpJoinMode=mode;
var open=$("modeOpen"),approval=$("modeApproval");
if(!open||!approval)return;
if(mode==="open"){open.classList.add("on");open.classList.remove("approval-mode");approval.classList.remove("on");approval.classList.remove("approval-mode");}
else{approval.classList.add("on","approval-mode");open.classList.remove("on");}
};

window.createNewGroup=function(){
var name=$("grpNameInput")?$("grpNameInput").value.trim():"";
var desc=$("grpDescInput")?$("grpDescInput").value.trim():"";
var err=$("grpCreateErr");
if(!name||name.length<2){if(err)err.textContent="Nama min 2 karakter";return;}
var gid="grp_"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
var code=genGroupCode();
var group={id:gid,name:name,desc:desc||"",owner:CURRENT_USER,members:[CURRENT_USER],admins:[],banned:[],pending:[],pp:"",created:Date.now(),joinMode:window._grpJoinMode||"open",inviteCode:code};
db.ref("groups/"+gid).set(group).then(function(){
db.ref("groupInviteCodes/"+code).set({gid:gid});
var list=groupGetList();
list.unshift({id:gid,name:name,t:Date.now(),pp:"",owner:CURRENT_USER,admins:[],joinMode:group.joinMode,inviteCode:code});
groupSaveList(list);
GRP_CACHE[gid]=group;
closeModal();
showConfetti();
toast("Grup dibuat!","gold");
logAction("create_group",gid+" "+name);
renderChatList();
setTimeout(function(){openGroupRoom(gid,name);},400);
}).catch(function(e){
if(err)err.textContent="Gagal: "+e.message;
});
};

window.openJoinGroupModal=function(){
var h='<div style="text-align:left">'+
'<div class="info-box" style="font-size:.62rem;line-height:1.6">Masukkan <b style="color:var(--c)">kode undangan</b> atau <b style="color:var(--n)">link join</b> grup.</div>'+
'<label class="lbl">Kode / Link</label>'+
'<input class="inp" id="joinCodeInput" placeholder="Contoh: ABCD1234" style="font-family:var(--fm);text-transform:uppercase;text-align:center;letter-spacing:3px;font-weight:900" autocomplete="off">'+
'<div id="joinErr" style="color:#fca5a5;font-size:.62rem;text-align:center;min-height:16px;margin-bottom:6px"></div>'+
'</div>';
showModal("fa-right-to-bracket","GABUNG GRUP",h,"LIHAT GRUP",function(){
var v=$("joinCodeInput")?$("joinCodeInput").value.trim():"";
if(!v){var e=$("joinErr");if(e)e.textContent="Isi kode dulu";return;}
var code=v.toUpperCase();
try{var m=v.match(/join\/([A-Z0-9]+)/i);if(m)code=m[1].toUpperCase();}catch(e){}
try{var m2=v.match(/[?&]join=([A-Z0-9]+)/i);if(m2)code=m2[1].toUpperCase();}catch(e){}
previewJoinGroup(code);
},"var(--g)");
};

window.previewJoinGroup=function(code){
var err=$("joinErr");
db.ref("groupInviteCodes/"+code).once("value").then(function(s){
var inv=s.val();
if(!inv||!inv.gid){if(err)err.textContent="Kode tidak valid";return;}
db.ref("groups/"+inv.gid).once("value").then(function(s2){
var g=s2.val();
if(!g){if(err)err.textContent="Grup tidak ditemukan";return;}
if((g.members||[]).indexOf(CURRENT_USER)>=0){
closeModal();
toast("Kamu sudah member grup ini","ok");
openGroupRoom(g.id,g.name);
return;
}
if((g.banned||[]).indexOf(CURRENT_USER)>=0){if(err)err.textContent="Kamu diblokir dari grup ini";return;}
closeModal();
showJoinGroupPreview(g);
});
}).catch(function(){if(err)err.textContent="Gagal cek kode";});
};

window.showJoinGroupPreview=function(g){
var ownerDisp=getUserDisplay(g.owner);
var modeText=g.joinMode==="open"?"Terbuka - langsung masuk":"Approval - owner harus approve";
var modeIcon=g.joinMode==="open"?"fa-door-open":"fa-user-shield";
var modeColor=g.joinMode==="open"?"var(--n)":"var(--g)";
var h='<div style="text-align:left">'+
'<div class="join-modal-preview">'+
'<div class="jmp-av" '+(g.pp?'style="background-image:url('+g.pp+');background-size:cover;background-position:center"':'')+'>'+(g.pp?"":esc(g.name.charAt(0).toUpperCase()))+'</div>'+
'<div class="jmp-name">'+esc(g.name)+'</div>'+
(g.desc?'<div class="jmp-desc">'+esc(g.desc)+'</div>':'')+
'<div class="jmp-stats">'+
'<span><i class="fas fa-user"></i> '+(g.members||[]).length+' anggota</span>'+
'<span><i class="fas fa-crown"></i> '+esc(ownerDisp)+'</span>'+
'<span style="color:'+modeColor+'"><i class="fas '+modeIcon+'"></i> '+modeText+'</span>'+
'</div></div>'+
'<div class="info-box '+(g.joinMode==="open"?"":"orange")+'" style="font-size:.6rem">'+
(g.joinMode==="open"?"Kamu akan <b>langsung masuk</b> setelah klik Gabung.":"Permintaanmu akan <b>dikirim ke owner</b>. Tunggu approval.")+
'</div>'+
'</div>';
showModal("fa-users","PREVIEW GRUP",h,"GABUNG",function(){requestJoinGroup(g);},g.joinMode==="open"?"var(--n)":"var(--g)");
};

window.requestJoinGroup=function(g){
db.ref("groups/"+g.id).once("value").then(function(s){
var cur=s.val();
if(!cur){toast("Grup hilang","err");return;}
if((cur.members||[]).indexOf(CURRENT_USER)>=0){toast("Kamu sudah member","ok");openGroupRoom(g.id,g.name);return;}
if(cur.joinMode==="open"){
var nm=(cur.members||[]).concat([CURRENT_USER]);
db.ref("groups/"+g.id+"/members").set(nm).then(function(){
var list=groupGetList();
list.unshift({id:g.id,name:g.name,t:Date.now(),pp:cur.pp||"",owner:cur.owner,admins:cur.admins||[],joinMode:cur.joinMode,inviteCode:cur.inviteCode});
groupSaveList(list);
db.ref("groupNotifs/"+cur.owner).push({type:"member_join",gid:g.id,gname:g.name,from:CURRENT_USER,fromDisplay:CURRENT_DISPLAY,time:Date.now()});
toast("Berhasil gabung!","ok");
showConfetti();
renderChatList();
setTimeout(function(){openGroupRoom(g.id,g.name);},400);
});
}else{
var pending=cur.pending||[];
if(pending.indexOf(CURRENT_USER)>=0){toast("Sudah request, tunggu approval","gold");return;}
pending.push(CURRENT_USER);
db.ref("groups/"+g.id+"/pending").set(pending).then(function(){
var req={from:CURRENT_USER,fromDisplay:CURRENT_DISPLAY,fromId:CURRENT_ID,time:Date.now(),gid:g.id,gname:g.name};
db.ref("joinRequests/"+g.id+"/"+CURRENT_USER).set(req).then(function(){
db.ref("groupNotifs/"+cur.owner).push({type:"join_request",gid:g.id,gname:g.name,from:CURRENT_USER,fromDisplay:CURRENT_DISPLAY,time:Date.now()});
toast("Request terkirim!","ok");
});
});
}
});
};

window.showMyGroupsList=function(){
var groups=groupGetList();
var h='<div style="text-align:left;max-height:70vh;overflow-y:auto">';
if(!groups.length){
h+='<div class="empty-box"><i class="fas fa-users"></i>Belum ada grup<br>Buat grup baru atau gabung via kode</div>';
}else{
groups.forEach(function(g){
var isOwner=g.owner===CURRENT_USER;
var isAdmin=isOwner||(g.admins||[]).indexOf(CURRENT_USER)>=0;
var reqCount=parseInt(localStorage.getItem("damz_grp_req_"+g.id)||"0");
var pinned=isPinnedChat("g_"+g.id);
h+='<div class="member-item"><div class="member-av" style="'+(g.pp?'background-image:url('+g.pp+');background-size:cover;background-position:center':'background:linear-gradient(135deg,var(--c),var(--c2))')+'">'+(g.pp?'':esc(g.name.charAt(0).toUpperCase()))+'</div><div class="member-info"><div class="member-name">'+esc(g.name)+(pinned?' <i class="fas fa-thumbtack" style="color:var(--p2);font-size:.55rem"></i>':'')+' '+(isOwner?'<span class="member-badge owner-b">OWNER</span>':(isAdmin?'<span class="member-badge admin-b">ADMIN</span>':''))+(g.joinMode==="open"?' <span class="member-badge online-b">OPEN</span>':' <span class="member-badge vip-b">APPROVAL</span>')+'</div><div class="member-meta">'+(g.inviteCode?"Kode: "+esc(g.inviteCode):"")+'</div></div>'+
(isAdmin&&reqCount>0?'<button class="mact gld" onclick="closeModal();setTimeout(function(){showGroupInfo(\''+esc(g.id)+'\')},100)">REQ ('+reqCount+')</button>':'')+
'<button class="mact cyn" onclick="closeModal();setTimeout(function(){openGroupRoom(\''+esc(g.id)+'\',\''+esc(g.name)+'\')},100)">BUKA</button></div>';
});
}
h+='</div>';
showModal("fa-users","GRUP SAYA",h,"TUTUP",null,"var(--c)");
};

function openGroupRoom(gid,gname){
CHATv1.currentRoom={type:"group",id:gid};CHATv1.unread=0;LAST_MSG_COUNT=0;CHATv1.pinnedMessage=null;
localStorage.setItem("damz_unread_grp_"+gid,"0");
updateBadgesUI();
var page=$("chatPage");page.innerHTML="";
var shell=document.createElement("div");shell.className="chat-shell";page.appendChild(shell);
var group=GRP_CACHE[gid];
if(!group){db.ref("groups/"+gid).once("value").then(function(s){if(s.val()){GRP_CACHE[gid]=s.val();group=s.val();}});}
var pp=group&&group.pp?group.pp:"";
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'background:linear-gradient(135deg,var(--c),var(--c2))';
var avText=pp?'':gname.charAt(0).toUpperCase();
var memberCount=group&&group.members?group.members.length:0;
var isOwner=group&&group.owner===CURRENT_USER;
var isAdmin=isOwner||(group&&(group.admins||[]).indexOf(CURRENT_USER)>=0);
var reqCount=isAdmin?parseInt(localStorage.getItem("damz_grp_req_"+gid)||"0"):0;
var head=document.createElement("div");head.className="cv1-room-head";
head.innerHTML='<button class="cv1-back" id="grpBackBtn"><i class="fas fa-arrow-left"></i></button><div style="width:42px;height:42px;border-radius:12px;'+avStyle+';color:#000;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:900;flex-shrink:0">'+avText+'</div><div style="flex:1;cursor:pointer;min-width:0" id="grpHeader"><div style="font-size:.85rem;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(gname)+'</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--c)">'+memberCount+' anggota'+(reqCount>0?' • <span style="color:var(--g);font-weight:900">'+reqCount+' request</span>':'')+'</div></div>'+(isAdmin&&reqCount>0?'<button class="cv1-back" id="grpReqBtn" style="background:rgba(251,191,36,.15);color:var(--g);position:relative"><i class="fas fa-user-clock"></i><span style="position:absolute;top:-4px;right:-4px;background:var(--g);color:#000;font-family:var(--fm);font-size:.4rem;font-weight:900;min-width:14px;height:14px;padding:0 3px;border-radius:7px;display:flex;align-items:center;justify-content:center">'+reqCount+'</span></button>':'')+'<button class="cv1-back" id="grpCallBtn" style="background:rgba(0,255,136,.15);color:var(--n)"><i class="fas fa-phone"></i></button><button class="cv1-back" id="grpVideoBtn" style="background:rgba(34,211,238,.15);color:var(--c)"><i class="fas fa-video"></i></button>';
shell.appendChild(head);
setTimeout(function(){
var bb=$("grpBackBtn");if(bb)bb.onclick=function(){stopChatListener();stopVoiceRecorder();try{if(db)db.ref("groupChats/"+gid+"/typing/"+CURRENT_USER).remove();}catch(e){}CHATv1.currentRoom=null;CHATv1.pinnedMessage=null;var sb=$("scrollBottomBtn");if(sb)sb.remove();renderChatList();};
var gb=$("grpCallBtn");if(gb)gb.onclick=function(){startGroupCall(gid,gname,false);};
var gvb=$("grpVideoBtn");if(gvb)gvb.onclick=function(){startGroupCall(gid,gname,true);};
var gh=$("grpHeader");if(gh&&gid!=="global")gh.onclick=function(){showGroupInfo(gid);};
var rq=$("grpReqBtn");if(rq)rq.onclick=function(){showJoinRequests(gid);};
},50);

var pinWrap=document.createElement("div");pinWrap.id="pinnedWrap";shell.appendChild(pinWrap);

var msgs=document.createElement("div");msgs.className="cv1-messages";msgs.id="chatMessages";
msgs.innerHTML='<div class="skeleton" style="height:50px;width:60%"></div>';
shell.appendChild(msgs);
var scrollBtn=document.createElement("button");scrollBtn.className="scroll-bottom-btn";scrollBtn.id="scrollBottomBtn";
scrollBtn.innerHTML='<i class="fas fa-arrow-down"></i><span class="badge" id="scrollBadge" style="display:none">0</span>';
document.body.appendChild(scrollBtn);
setTimeout(function(){
var sb=$("scrollBottomBtn");if(sb)sb.onclick=function(){scrollToBottom(true);};
var msgsEl=$("chatMessages");
if(msgsEl){msgsEl.addEventListener("scroll",function(){var isAtBottom=msgsEl.scrollHeight-msgsEl.scrollTop-msgsEl.clientHeight<80;if(isAtBottom){scrollBtn.classList.remove("on");CHATv1.unread=0;var b=$("scrollBadge");if(b)b.style.display="none";}});}
},150);
var bar=document.createElement("div");bar.className="cv1-input-bar";bar.id="chatInputBar";
bar.innerHTML=inputBarHTML();
shell.appendChild(bar);
setTimeout(bindChatInput,50);
startChatListener();
}
window.openGroupRoom=openGroupRoom;

window.showGroupInfo=function(gid){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();if(!g){toast("Grup tidak ditemukan","err");return;}
GRP_CACHE[gid]=g;
var isOwner=g.owner===CURRENT_USER;
var isAdmin=isOwner||(g.admins&&g.admins.indexOf(CURRENT_USER)>=0);
var members=g.members||[];
var banned=g.banned||[];
var pending=g.pending||[];
var pp=g.pp||"";
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
var avText=pp?'':g.name.charAt(0).toUpperCase();
var joinMode=g.joinMode||"open";
var inviteCode=g.inviteCode||"";
var h='<div style="text-align:left;max-height:75vh;overflow-y:auto">';
h+='<div class="grp-panel"><div class="gh-av" id="grpPPBox" onclick="'+(isAdmin?'pickGroupPP(\''+gid+'\')':'')+'" style="'+avStyle+'">'+avText+(isAdmin?'<div class="edit-pp"><i class="fas fa-camera"></i></div>':'')+'</div>';
h+='<div class="gh-name">'+esc(g.name)+'</div>';
if(g.desc)h+='<div class="gh-desc">'+esc(g.desc)+'</div>';
h+='<div class="gh-meta">'+members.length+' anggota • Owner: '+esc(getUserDisplay(g.owner))+'</div>';
h+='<div class="gh-meta" style="margin-top:6px">'+(joinMode==="open"?'<span style="color:var(--n)"><i class="fas fa-door-open"></i> OPEN — siapa pun bisa join</span>':'<span style="color:var(--g)"><i class="fas fa-user-shield"></i> APPROVAL — owner approve</span>')+'</div>';
if(inviteCode){
h+='<div class="gh-code" onclick="copyGroupInvite(\''+esc(inviteCode)+'\')"><i class="fas fa-link"></i> '+esc(inviteCode)+' <i class="fas fa-copy" style="font-size:10px;opacity:.7"></i></div>';
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button class="btn cyan" style="margin:0;padding:11px;font-size:.62rem" onclick="shareGroupLink(\''+esc(inviteCode)+'\',\''+esc(g.name)+'\')"><i class="fas fa-share-nodes"></i> SHARE LINK</button><button class="btn sec" style="margin:0;padding:11px;font-size:.62rem" onclick="copyGroupInvite(\''+esc(inviteCode)+'\')"><i class="fas fa-copy"></i> SALIN</button></div>';
}
h+='<input type="file" id="grpPPInput" accept="image/*" style="display:none"></div>';
if(isAdmin){
h+='<div class="grp-sec"><div class="grp-sec-title">PENGATURAN</div>';
h+='<button class="grp-act-btn" onclick="editGroupName(\''+gid+'\')"><i class="fas fa-edit" style="color:var(--n);width:20px"></i> Ganti Nama</button>';
h+='<button class="grp-act-btn" onclick="editGroupDesc(\''+gid+'\')"><i class="fas fa-align-left" style="color:var(--n);width:20px"></i> Ganti Deskripsi</button>';
h+='<button class="grp-act-btn" onclick="toggleGroupJoinMode(\''+gid+'\')"><i class="fas '+(joinMode==="open"?"fa-user-shield":"fa-door-open")+'" style="color:var(--g);width:20px"></i> Ubah ke '+(joinMode==="open"?"APPROVAL":"OPEN")+'</button>';
h+='<button class="grp-act-btn" onclick="addGroupMember(\''+gid+'\')"><i class="fas fa-user-plus" style="color:var(--n);width:20px"></i> Tambah Anggota (dari kontak)</button>';
if(pending.length>0)h+='<button class="grp-act-btn" onclick="showJoinRequests(\''+gid+'\')" style="background:linear-gradient(135deg,rgba(251,191,36,.15),rgba(245,158,11,.08));border-color:rgba(251,191,36,.4)"><i class="fas fa-user-clock" style="color:var(--g);width:20px"></i> Permintaan Bergabung ('+pending.length+')</button>';
if(banned.length>0)h+='<button class="grp-act-btn" onclick="showBannedMembers(\''+gid+'\')"><i class="fas fa-ban" style="color:var(--g);width:20px"></i> Anggota Diblokir ('+banned.length+')</button>';
h+='</div>';
}
h+='<div class="grp-sec"><div class="grp-sec-title">ANGGOTA ('+members.length+')</div>';
members.forEach(function(u){
var isM=g.owner===u;
var isA=(g.admins||[]).indexOf(u)>=0;
var uPP=getUserPP(u);
var badges="";
if(isM)badges+='<span class="gm-badges owner">OWNER</span>';
else if(isA)badges+='<span class="gm-badges admin">ADMIN</span>';
var actions="";
if(isAdmin&&u!==CURRENT_USER&&!isM){
if(!isA)actions+='<button class="grp-act-mini star" onclick="grpMakeAdmin(\''+gid+'\',\''+u+'\')" title="Jadikan Admin"><i class="fas fa-star"></i></button>';
else actions+='<button class="grp-act-mini star" onclick="grpRemoveAdmin(\''+gid+'\',\''+u+'\')" title="Cabut Admin"><i class="fas fa-star-half-alt"></i></button>';
actions+='<button class="grp-act-mini kick" onclick="grpKickMember(\''+gid+'\',\''+u+'\')" title="Kick"><i class="fas fa-user-minus"></i></button>';
actions+='<button class="grp-act-mini ban" onclick="grpBanMember(\''+gid+'\',\''+u+'\')" title="Blokir"><i class="fas fa-ban"></i></button>';
}
var avStyle=uPP?'background-image:url('+uPP+');background-size:cover;background-position:center':'';
var avText=uPP?'':getUserDisplay(u).charAt(0).toUpperCase();
h+='<div class="grp-member-row"><div class="gm-av" style="'+avStyle+'">'+avText+'</div><div class="gm-info"><div class="gm-name">'+esc(getUserDisplay(u))+' '+badges+'</div></div><div class="grp-member-actions">'+actions+'</div></div>';
});
h+='</div>';
h+='<div class="grp-sec"><div class="grp-sec-title">AKSI</div>';
h+='<button class="grp-act-btn danger" onclick="leaveGroup(\''+gid+'\')"><i class="fas fa-right-from-bracket" style="width:20px"></i> Keluar Grup</button>';
if(isOwner)h+='<button class="grp-act-btn danger" onclick="deleteGroupTotal(\''+gid+'\')"><i class="fas fa-trash-alt" style="width:20px"></i> Hapus Grup Total</button>';
h+='</div></div>';
showModal("fa-users","INFO GRUP",h,"TUTUP",null,"var(--c)");
});
};

window.copyGroupInvite=function(code){
var link=APP_BASE_URL+"?join="+code;
copyText(link);
};
window.shareGroupLink=function(code,gname){
var link=APP_BASE_URL+"?join="+code;
var txt="Yuk gabung grup \""+gname+"\" di DAMZ NEXUS!\n\nKlik link: "+link+"\nAtau masukkan kode: "+code;
if(navigator.share){navigator.share({title:"Gabung Grup "+gname,text:txt,url:link}).catch(function(){copyText(txt);});}
else copyText(txt);
};

window.toggleGroupJoinMode=function(gid){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();if(!g)return;
var cur=g.joinMode||"open";
var nw=cur==="open"?"approval":"open";
showModal("fa-shuffle","UBAH MODE GABUNG","Ubah ke <b>"+nw.toUpperCase()+"</b>?","UBAH",function(){
db.ref("groups/"+gid+"/joinMode").set(nw).then(function(){
toast("Mode diubah ke "+nw.toUpperCase(),"ok");
closeModal();
setTimeout(function(){showGroupInfo(gid);},200);
});
},"var(--g)");
});
};

window.showJoinRequests=function(gid){
db.ref("joinRequests/"+gid).once("value").then(function(s){
var reqs=s.val()||{};
var keys=Object.keys(reqs);
localStorage.setItem("damz_grp_req_"+gid,"0");
var h='<div style="text-align:left;max-height:70vh;overflow-y:auto">';
if(!keys.length)h+='<div class="empty-box"><i class="fas fa-user-check"></i>Tidak ada permintaan bergabung</div>';
else{
keys.forEach(function(uid){
var r=reqs[uid];
var pp=getUserPP(uid);
var avStyle=pp?'background-image:url('+pp+');background-size:cover;background-position:center':'';
h+='<div class="request-row"><div class="rq-av" style="'+avStyle+'">'+(pp?"":esc((r.fromDisplay||uid).charAt(0).toUpperCase()))+'</div><div class="rq-info"><div class="rq-name">'+esc(r.fromDisplay||uid)+'</div><div class="rq-meta">'+esc(r.fromId||"")+' • '+chatFmtTime(new Date(r.time).toISOString())+'</div></div><div class="rq-actions"><button class="rq-btn accept" onclick="approveJoinRequest(\''+esc(gid)+'\',\''+esc(uid)+'\')"><i class="fas fa-check"></i> TERIMA</button><button class="rq-btn reject" onclick="rejectJoinRequest(\''+esc(gid)+'\',\''+esc(uid)+'\')"><i class="fas fa-times"></i> TOLAK</button></div></div>';
});
}
h+='</div>';
showModal("fa-user-clock","PERMINTAAN BERGABUNG",h,"TUTUP",null,"var(--g)");
});
};

window.approveJoinRequest=function(gid,uid){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();if(!g)return;
var members=g.members||[];
var pending=g.pending||[];
if(members.indexOf(uid)<0)members.push(uid);
pending=pending.filter(function(x){return x!==uid;});
db.ref("groups/"+gid+"/members").set(members);
db.ref("groups/"+gid+"/pending").set(pending);
db.ref("joinRequests/"+gid+"/"+uid).remove();
db.ref("groupNotifs/"+uid).push({type:"approved",gid:gid,gname:g.name,by:CURRENT_USER,time:Date.now()});
localStorage.setItem("damz_grp_req_"+gid,String(Math.max(0,parseInt(localStorage.getItem("damz_grp_req_"+gid)||"0")-1)));
toast("Diterima","ok");
closeModal();
setTimeout(function(){showJoinRequests(gid);},300);
});
};

window.rejectJoinRequest=function(gid,uid){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();if(!g)return;
var pending=(g.pending||[]).filter(function(x){return x!==uid;});
db.ref("groups/"+gid+"/pending").set(pending);
db.ref("joinRequests/"+gid+"/"+uid).remove();
db.ref("groupNotifs/"+uid).push({type:"rejected",gid:gid,gname:g.name,by:CURRENT_USER,time:Date.now()});
localStorage.setItem("damz_grp_req_"+gid,String(Math.max(0,parseInt(localStorage.getItem("damz_grp_req_"+gid)||"0")-1)));
toast("Ditolak","err");
closeModal();
setTimeout(function(){showJoinRequests(gid);},300);
});
};

function watchJoinRequests(){
if(!db||!CURRENT_USER||watchJoinRequests._done)return;
watchJoinRequests._done=true;
db.ref("groups").on("value",function(snap){
var all=snap.val()||{};
Object.keys(all).forEach(function(gid){
var g=all[gid];if(!g)return;
if((g.members||[]).indexOf(CURRENT_USER)<0)return;
GRP_CACHE[gid]=g;
var list=groupGetList();
var exists=list.filter(function(x){return x.id===gid;})[0];
if(!exists){list.unshift({id:gid,name:g.name,t:g.created||Date.now(),pp:g.pp||"",owner:g.owner,admins:g.admins||[],joinMode:g.joinMode||"open",inviteCode:g.inviteCode||""});groupSaveList(list);}
else{exists.name=g.name;if(g.pp)exists.pp=g.pp;exists.owner=g.owner;exists.admins=g.admins||[];exists.joinMode=g.joinMode||"open";exists.inviteCode=g.inviteCode||"";groupSaveList(list);}
var isOwner=g.owner===CURRENT_USER;
var isAdmin=isOwner||(g.admins||[]).indexOf(CURRENT_USER)>=0;
if(isAdmin){
var pending=g.pending||[];
var count=pending.length;
var old=parseInt(localStorage.getItem("damz_grp_req_"+gid)||"0");
localStorage.setItem("damz_grp_req_"+gid,String(count));
if(count>old){
var newest=pending[pending.length-1];
var newDisp=getUserDisplay(newest);
var isActiveGrp=(CHATv1.currentRoom&&CHATv1.currentRoom.type==="group"&&CHATv1.currentRoom.id===gid&&document.querySelector(".pg.on")&&document.querySelector(".pg.on").id==="chatPage");
if(!isActiveGrp){
showAndroidNotif("group",g.name,"Permintaan join dari "+newDisp+" — tap untuk lihat",function(){showChatPage();setTimeout(function(){showJoinRequests(gid);},200);});
}
}
}
});
});
}
window.watchJoinRequests=watchJoinRequests;

function watchGroupNotifs(){
if(!db||!CURRENT_USER||watchGroupNotifs._done)return;
watchGroupNotifs._done=true;
db.ref("groupNotifs/"+CURRENT_USER).on("child_added",function(snap){
var n=snap.val();if(!n)return;
if(Date.now()-(n.time||0)>300000){snap.ref.remove();return;}
if(n.type==="approved"){
showAndroidNotif("group","Grup "+n.gname,"Kamu diterima di grup! Tap untuk buka",function(){
showChatPage();
setTimeout(function(){
db.ref("groups/"+n.gid).once("value").then(function(s){
var g=s.val();if(!g)return;
var list=groupGetList();
list.unshift({id:n.gid,name:g.name,t:Date.now(),pp:g.pp||"",owner:g.owner,admins:g.admins||[],joinMode:g.joinMode||"open",inviteCode:g.inviteCode||""});
groupSaveList(list);
openGroupRoom(n.gid,g.name);
});
},200);
});
snap.ref.remove();
}else if(n.type==="rejected"){
showAndroidNotif("group","Grup "+n.gname,"Permintaan join ditolak",function(){showChatPage();});
snap.ref.remove();
}else if(n.type==="join_request"){
showAndroidNotif("group","Grup "+n.gname,n.fromDisplay+" ingin gabung",function(){
showChatPage();
setTimeout(function(){showJoinRequests(n.gid);},200);
});
snap.ref.remove();
}else if(n.type==="member_join"){
showAndroidNotif("group","Grup "+n.gname,n.fromDisplay+" bergabung",function(){showChatPage();});
snap.ref.remove();
}else snap.ref.remove();
});
}
window.watchGroupNotifs=watchGroupNotifs;

window.pickGroupPP=function(gid){
var inp=$("grpPPInput");if(!inp)return;
inp.onchange=function(e){
var f=e.target.files[0];if(!f)return;
if(f.size>2*1024*1024){toast("Max 2MB","err");return;}
compressImage(f,300,300,200,function(du,kb){
db.ref("groups/"+gid+"/pp").set(du).then(function(){
toast("PP grup tersimpan","ok");
closeModal();
var list=groupGetList();
list.forEach(function(g){if(g.id===gid)g.pp=du;});
groupSaveList(list);
if(GRP_CACHE[gid])GRP_CACHE[gid].pp=du;
setTimeout(function(){showGroupInfo(gid);},300);
});
});
};
inp.click();
};

window.editGroupName=function(gid){
db.ref("groups/"+gid+"/name").once("value").then(function(s){
showModal("fa-edit","GANTI NAMA",'<label class="lbl">Nama Baru</label><input class="inp" id="editGrpName" value="'+esc(s.val()||"")+'" maxlength="40">',"SIMPAN",function(){
var n=$("editGrpName").value.trim();
if(!n||n.length<2){toast("Min 2","err");return;}
db.ref("groups/"+gid+"/name").set(n).then(function(){
toast("Nama diganti","ok");closeModal();
var list=groupGetList();list.forEach(function(g){if(g.id===gid)g.name=n;});groupSaveList(list);
if(GRP_CACHE[gid])GRP_CACHE[gid].name=n;
setTimeout(function(){showGroupInfo(gid);},200);
});
},"var(--n)");
});
};

window.editGroupDesc=function(gid){
db.ref("groups/"+gid+"/desc").once("value").then(function(s){
showModal("fa-align-left","GANTI DESKRIPSI",'<label class="lbl">Deskripsi Baru</label><input class="inp" id="editGrpDesc" value="'+esc(s.val()||"")+'" maxlength="80">',"SIMPAN",function(){
var d=$("editGrpDesc").value.trim();
db.ref("groups/"+gid+"/desc").set(d).then(function(){toast("Deskripsi diganti","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});
},"var(--n)");
});
};

window.addGroupMember=function(gid){
var contacts=chatGetContacts();
db.ref("groups/"+gid+"/members").once("value").then(function(s){
var cur=s.val()||[];
var available=contacts.filter(function(c){return cur.indexOf(c.u)<0;});
if(!available.length){toast("Semua kontak sudah di grup","err");return;}
var h='<div style="text-align:left;max-height:400px;overflow-y:auto">';
available.forEach(function(c){h+='<div class="pick-add" data-user="'+esc(c.u)+'" style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(0,0,0,.3);border:1.5px solid var(--b);border-radius:12px;margin-bottom:8px;cursor:pointer">'+avatarHTML(c.u,42)+'<div style="flex:1"><div style="color:#fff;font-weight:700;font-size:.78rem">'+esc(chatDisplayName(c.u))+'</div></div><i class="fas fa-plus" style="color:var(--n)"></i></div>';});
h+='</div>';
showModal("fa-user-plus","TAMBAH ANGGOTA",h,"TUTUP",null,"var(--c)");
setTimeout(function(){
document.querySelectorAll(".pick-add").forEach(function(el){
el.onclick=function(){
var u=this.getAttribute("data-user");
db.ref("groups/"+gid+"/members").once("value").then(function(s2){
var arr=s2.val()||[];
if(arr.indexOf(u)<0)arr.push(u);
db.ref("groups/"+gid+"/banned").once("value").then(function(s3){
var banned=s3.val()||[];
banned=banned.filter(function(x){return x!==u;});
db.ref("groups/"+gid+"/banned").set(banned);
db.ref("groups/"+gid+"/members").set(arr).then(function(){toast("Ditambahkan","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});
});
});
};
});
},80);
});
};

window.grpKickMember=function(gid,u){
showModal("fa-user-minus","KICK ANGGOTA","Keluarkan <b>"+esc(getUserDisplay(u))+"</b> dari grup?","KICK",function(){
db.ref("groups/"+gid+"/members").once("value").then(function(s){
var arr=s.val()||[];
arr=arr.filter(function(x){return x!==u;});
db.ref("groups/"+gid+"/members").set(arr).then(function(){toast("Dikeluarkan","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});
});
},"var(--g)");
};

window.grpBanMember=function(gid,u){
showModal("fa-ban","BLOKIR DARI GRUP","Blokir <b>"+esc(getUserDisplay(u))+"</b> dari grup ini?","BLOKIR",function(){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val()||{};
var members=g.members||[],banned=g.banned||[];
members=members.filter(function(x){return x!==u;});
if(banned.indexOf(u)<0)banned.push(u);
db.ref("groups/"+gid+"/members").set(members);
db.ref("groups/"+gid+"/banned").set(banned).then(function(){toast("Diblokir dari grup","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});
});
},"var(--r)");
};

window.showBannedMembers=function(gid){
db.ref("groups/"+gid+"/banned").once("value").then(function(s){
var banned=s.val()||[];
var h='<div style="text-align:left">';
if(!banned.length)h+='<div class="empty-box"><i class="fas fa-user-check"></i>Tidak ada anggota diblokir</div>';
else banned.forEach(function(u){h+='<div class="grp-member-row"><div class="gm-av">'+getUserDisplay(u).charAt(0).toUpperCase()+'</div><div class="gm-info"><div class="gm-name">'+esc(getUserDisplay(u))+' <span class="gm-badges banned">BANNED</span></div></div><div class="grp-member-actions"><button class="grp-act-mini star" onclick="unbanFromGroup(\''+gid+'\',\''+u+'\')" title="Unban"><i class="fas fa-undo"></i></button></div></div>';});
h+='</div>';
showModal("fa-ban","ANGGOTA DIBLOKIR",h,"TUTUP",null,"var(--g)");
});
};

window.unbanFromGroup=function(gid,u){
db.ref("groups/"+gid+"/banned").once("value").then(function(s){var arr=s.val()||[];arr=arr.filter(function(x){return x!==u;});db.ref("groups/"+gid+"/banned").set(arr).then(function(){toast("Unban berhasil","ok");closeModal();setTimeout(function(){showBannedMembers(gid);},200);});});
};

window.grpMakeAdmin=function(gid,u){
db.ref("groups/"+gid+"/admins").once("value").then(function(s){var arr=s.val()||[];if(arr.indexOf(u)<0)arr.push(u);db.ref("groups/"+gid+"/admins").set(arr).then(function(){toast("Jadi admin","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});});
};

window.grpRemoveAdmin=function(gid,u){
db.ref("groups/"+gid+"/admins").once("value").then(function(s){var arr=s.val()||[];arr=arr.filter(function(x){return x!==u;});db.ref("groups/"+gid+"/admins").set(arr).then(function(){toast("Admin dicabut","ok");closeModal();setTimeout(function(){showGroupInfo(gid);},200);});});
};

window.leaveGroup=function(gid){
showModal("fa-right-from-bracket","KELUAR GRUP","Yakin keluar dari grup ini?","KELUAR",function(){
db.ref("groups/"+gid+"/members").once("value").then(function(s){
var arr=s.val()||[];
arr=arr.filter(function(x){return x!==CURRENT_USER;});
db.ref("groups/"+gid+"/members").set(arr);
var list=groupGetList().filter(function(g){return g.id!==gid;});
groupSaveList(list);
toast("Keluar dari grup","ok");closeModal();
stopChatListener();stopVoiceRecorder();
CHATv1.currentRoom=null;
var sb=$("scrollBottomBtn");if(sb)sb.remove();
renderChatList();
});
},"var(--r)");
};

window.deleteGroupTotal=function(gid){
showModal("fa-trash-alt","HAPUS GRUP TOTAL","Yakin hapus grup ini <b>untuk semua orang</b>?","HAPUS",function(){
db.ref("groups/"+gid).once("value").then(function(s){
var g=s.val();
if(g&&g.inviteCode)db.ref("groupInviteCodes/"+g.inviteCode).remove();
db.ref("groups/"+gid).remove();
db.ref("groupChats/"+gid).remove();
db.ref("joinRequests/"+gid).remove();
});
var list=groupGetList().filter(function(g){return g.id!==gid;});
groupSaveList(list);
delete GRP_CACHE[gid];
toast("Grup dihapus total","ok");closeModal();
stopChatListener();stopVoiceRecorder();
CHATv1.currentRoom=null;
var sb=$("scrollBottomBtn");if(sb)sb.remove();
renderChatList();
},"var(--r)");
};

function watchGroupMessagesNotif(){
if(!db||!CURRENT_USER||watchGroupMessagesNotif._done)return;
watchGroupMessagesNotif._done=true;
var lastSeen={};
db.ref("groups").once("value").then(function(s){
var all=s.val()||{};
Object.keys(all).forEach(function(gid){
var g=all[gid];if(!g)return;
if((g.members||[]).indexOf(CURRENT_USER)<0)return;
db.ref("groupChats/"+gid).limitToLast(1).on("child_added",function(snap){
var m=snap.val();
if(!m||!m.from||m.from===CURRENT_USER)return;
var lm=lastSeen[gid]||0;
if(!m.timestamp||m.timestamp<=lm)return;
lastSeen[gid]=m.timestamp;
var isActive=(CHATv1.currentRoom&&CHATv1.currentRoom.type==="group"&&CHATv1.currentRoom.id===gid&&document.querySelector(".pg.on")&&document.querySelector(".pg.on").id==="chatPage");
if(!isActive){
var uk="damz_unread_grp_"+gid;
var cu=parseInt(localStorage.getItem(uk)||"0")+1;
localStorage.setItem(uk,String(cu));
updateBadgesUI();
var preview=m.voice?"Voice":(m.mediaType==="photo"?"Foto":(m.mediaType==="video"?"Video":(m.text||"")));
showAndroidNotif("group",g.name+" • "+getUserDisplay(m.from),preview,function(){showChatPage();setTimeout(function(){openGroupRoom(gid,g.name);},120);});
}
});
});
});
}
window.watchGroupMessagesNotif=watchGroupMessagesNotif;

window.handleJoinLinkOnBoot=function(){
try{
var params=new URLSearchParams(location.search);
var jc=params.get("join");
if(jc){
setTimeout(function(){
toast("Memproses kode grup...","ok");
previewJoinGroup(jc.toUpperCase());
},500);
try{history.replaceState({},"",location.pathname);}catch(e){}
}
}catch(e){}
};
