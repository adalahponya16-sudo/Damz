
function runB64(e){var i=$("inp1").value;if(!i){toast("Isi","err");return;}var o;try{o=e?btoa(unescape(encodeURIComponent(i))):decodeURIComponent(escape(atob(i)));}catch(x){toast("Invalid","err");return;}showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);word-break:break-all;font-family:var(--fm)'>"+esc(o)+"</div>");}window.runB64=runB64;
function runUrlEnc(e){var i=$("inp1").value;var o=e?encodeURIComponent(i):decodeURIComponent(i);showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(o)+"</div>");}window.runUrlEnc=runUrlEnc;
function runHtmlEnt(e){var i=$("inp1").value;var o;if(e)o=i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");else o=i.replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"');showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(o)+"</div>");}window.runHtmlEnt=runHtmlEnt;
var MORSE={A:".-",B:"-...",C:"-.-.",D:"-..",E:".",F:"..-.",G:"--.",H:"....",I:"..",J:".---",K:"-.-",L:".-..",M:"--",N:"-.",O:"---",P:".--.",Q:"--.-",R:".-.",S:"...",T:"-",U:"..-",V:"...-",W:".--",X:"-..-",Y:"-.--",Z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----."};
function runMorse(e){var i=$("inp1").value.toUpperCase();if(!i){toast("Isi","err");return;}var o;if(e)o=i.split("").map(function(c){return MORSE[c]||c;}).join(" ");else o=i.split(" ").map(function(c){for(var k in MORSE)if(MORSE[k]===c)return k;return c;}).join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(o)+"</div>");}window.runMorse=runMorse;
function runReverse(){var i=$("inp1").value;showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(i.split("").reverse().join(""))+"</div>");}window.runReverse=runReverse;
function runCase(m){var i=$("inp1").value;var o=m===1?i.toUpperCase():i.toLowerCase();showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(o)+"</div>");}window.runCase=runCase;
function runLeet(){var i=$("inp1").value;var map={a:"4",e:"3",i:"1",o:"0",s:"5",t:"7",g:"9",b:"8"};var o=i.toLowerCase().split("").map(function(c){return map[c]||c;}).join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n)'>"+esc(o)+"</div>");}window.runLeet=runLeet;
function runRot13(){var i=$("inp1").value;var o=i.replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26);});showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n)'>"+esc(o)+"</div>");}window.runRot13=runRot13;
function runCaesar(){var i=$("inp1").value,s=parseInt($("inp2").value)||3;var o=i.replace(/[a-zA-Z]/g,function(c){var b=c<="Z"?65:97;return String.fromCharCode((c.charCodeAt(0)-b+s)%26+b);});showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n)'>"+esc(o)+"</div>");}window.runCaesar=runCaesar;
function runBinary(e){var i=$("inp1").value;var o;if(e)o=i.split("").map(function(c){return c.charCodeAt(0).toString(2).padStart(8,"0");}).join(" ");else o=i.split(" ").map(function(b){return String.fromCharCode(parseInt(b,2));}).join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all;font-size:.7rem'>"+esc(o)+"</div>");}window.runBinary=runBinary;
function runHex(e){var i=$("inp1").value;var o;if(e)o=i.split("").map(function(c){return c.charCodeAt(0).toString(16).padStart(2,"0");}).join(" ");else o=i.split(" ").map(function(h){return String.fromCharCode(parseInt(h,16));}).join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all'>"+esc(o)+"</div>");}window.runHex=runHex;
function runUpsideDown(){var i=$("inp1").value;var o=i.toLowerCase().split("").reverse().join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-size:1.4rem;text-align:center'>"+esc(o)+"</div>");}window.runUpsideDown=runUpsideDown;
function runBubble(){var i=$("inp1").value;showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-size:1.2rem;text-align:center'>"+esc(i)+"</div>");}window.runBubble=runBubble;
function runStrike(){var i=$("inp1").value;var o=i.split("").map(function(c){return c+"\u0336";}).join("");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-size:1.2rem;text-align:center'>"+esc(o)+"</div>");}window.runStrike=runStrike;
function runPig(){var i=$("inp1").value;var o=i.split(/\s+/).map(function(w){return w.match(/^[aeiou]/i)?w+"way":w.slice(1)+w[0]+"ay";}).join(" ");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n)'>"+esc(o)+"</div>");}window.runPig=runPig;
function runJson(){try{var o=JSON.parse($("inp1").value);showResult("<pre style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);white-space:pre-wrap;font-size:.65rem;font-family:var(--fm)'>"+esc(JSON.stringify(o,null,2))+"</pre>");}catch(e){showResult("<div class='info-box red'>Invalid JSON: "+esc(e.message)+"</div>");}}window.runJson=runJson;
function runJsonVal(){try{JSON.parse($("inp1").value);showResult("<div class='info-box'><b>VALID JSON</b></div>");}catch(e){showResult("<div class='info-box red'><b>INVALID</b><br>"+esc(e.message)+"</div>");}}window.runJsonVal=runJsonVal;
function runHtmlFmt(){var c=$("inp1").value;if(!c){toast("Isi","err");return;}c=c.replace(/></g,">\n<");showResult("<pre style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);white-space:pre-wrap;font-size:.6rem;font-family:var(--fm)'>"+esc(c)+"</pre>");}window.runHtmlFmt=runHtmlFmt;
function runCssFmt(){var c=$("inp1").value;if(!c){toast("Isi","err");return;}var o=c.replace(/\s*{\s*/g," {\n  ").replace(/;\s*/g,";\n  ").replace(/\s*}\s*/g,"\n}\n").trim();showResult("<pre style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);white-space:pre-wrap;font-size:.6rem;font-family:var(--fm)'>"+esc(o)+"</pre>");}window.runCssFmt=runCssFmt;
function runJsFmt(){var c=$("inp1").value;if(!c){toast("Isi","err");return;}var o=c.replace(/;\s*/g,";\n").replace(/{\s*/g,"{\n  ").replace(/\s*}/g,"\n}").trim();showResult("<pre style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);white-space:pre-wrap;font-size:.6rem;font-family:var(--fm)'>"+esc(o)+"</pre>");}window.runJsFmt=runJsFmt;
function runCssMin(){var c=$("inp1").value;var o=c.replace(/\/\*[\s\S]*?\*\//g,"").replace(/\s+/g," ").replace(/\s*([{}:;,>])\s*/g,"$1").trim();showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all;font-size:.65rem;font-family:var(--fm)'>"+esc(o)+"</div>");}window.runCssMin=runCssMin;
function runJsMin(){var c=$("inp1").value;var o=c.replace(/\/\*[\s\S]*?\*\//g,"").replace(/\/\/.*/g,"").replace(/\s+/g," ").replace(/\s*([{};:,+\-*=<>()\[\]])\s*/g,"$1").trim();showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);word-break:break-all;font-size:.65rem;font-family:var(--fm)'>"+esc(o)+"</div>");}window.runJsMin=runJsMin;
function runRegex(){var pat=$("inp1").value,txt=$("inp2").value;try{var re=new RegExp(pat,"g");var m=txt.match(re)||[];showResult("<div class='info-box'>Match: <b>"+m.length+"</b><br>"+m.map(function(x){return "• "+esc(x);}).join("<br>")+"</div>");}catch(e){showResult("<div class='info-box red'>Invalid regex</div>");}}window.runRegex=runRegex;
function runUuid(){var o="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(c){var r=Math.random()*16|0,v=c==="x"?r:(r&0x3|0x8);return v.toString(16);});showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-family:var(--fm);word-break:break-all'>"+o+"</div>");}window.runUuid=runUuid;
function runHash(){var t=$("inp1").value;var h=0;for(var i=0;i<t.length;i++){h=((h<<5)-h)+t.charCodeAt(i);h|=0;}var h2=0;for(var j=t.length-1;j>=0;j--){h2=((h2<<5)-h2)+t.charCodeAt(j);h2|=0;}showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-family:var(--fm);word-break:break-all'>h_"+Math.abs(h).toString(36)+"_"+Math.abs(h2).toString(36)+"</div>");}window.runHash=runHash;
function runTimestamp(){var v=$("inp1").value;var d;if(/^\d+$/.test(v))d=new Date(parseInt(v));else d=new Date(v);if(isNaN(d)){toast("Invalid","err");return;}showResult("<div class='info-box'>ISO: <b>"+d.toISOString()+"</b><br>Unix: <b>"+d.getTime()+"</b><br>Readable: <b>"+d.toLocaleString("id-ID")+"</b></div>");}window.runTimestamp=runTimestamp;
function runCharCount(){var i=$("inp1").value;showResult("<div class='info-box'>Total: <b>"+i.length+"</b><br>Tanpa spasi: <b>"+i.replace(/\s/g,"").length+"</b></div>");}window.runCharCount=runCharCount;
function runWordCount(){var i=$("inp1").value.trim();var w=i?i.split(/\s+/).length:0;showResult("<div class='info-box'>Kata: <b>"+w+"</b></div>");}window.runWordCount=runWordCount;
function runLineCount(){var i=$("inp1").value;var l=i?i.split("\n").length:0;showResult("<div class='info-box'>Baris: <b>"+l+"</b></div>");}window.runLineCount=runLineCount;
function runDupLine(){var i=$("inp1").value;var arr=i.split("\n");var uniq=arr.filter(function(v,idx){return arr.indexOf(v)===idx;});showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);white-space:pre-wrap'>"+esc(uniq.join("\n"))+"</div>");}window.runDupLine=runDupLine;
function runSortText(){var i=$("inp1").value;var arr=i.split("\n").sort();showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);white-space:pre-wrap'>"+esc(arr.join("\n"))+"</div>");}window.runSortText=runSortText;
function runDiff(){var a=$("inp1").value.split("\n"),b=$("inp2").value.split("\n");var max=Math.max(a.length,b.length);var h="";for(var i=0;i<max;i++){if(a[i]!==b[i])h+="<div style='color:#fca5a5'>- "+esc(a[i]||"")+"<br>+ "+esc(b[i]||"")+"</div>";else h+="<div>"+esc(a[i]||"")+"</div>";}showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px'>"+h+"</div>");}window.runDiff=runDiff;
function runMdPrev(){var t=$("inp1").value;var o=t.replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>").replace(/\*\*(.+?)\*\*/g,"<b>$1</b>").replace(/\*(.+?)\*/g,"<i>$1</i>").replace(/`(.+?)`/g,"<code style='background:rgba(0,255,136,.15);padding:2px 6px;border-radius:4px'>$1</code>").replace(/\n/g,"<br>");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;line-height:1.7'>"+o+"</div>");}window.runMdPrev=runMdPrev;
function runCsvJson(){var t=$("inp1").value.trim();var lines=t.split("\n");if(!lines.length){toast("Kosong","err");return;}var head=lines[0].split(",");var arr=[];for(var i=1;i<lines.length;i++){var vals=lines[i].split(",");var obj={};head.forEach(function(h,j){obj[h.trim()]=vals[j]||"";});arr.push(obj);}showResult("<pre style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-size:.65rem;white-space:pre-wrap'>"+esc(JSON.stringify(arr,null,2))+"</pre>");}window.runCsvJson=runCsvJson;
function runJsonCsv(){try{var a=JSON.parse($("inp1").value);if(!Array.isArray(a))throw new Error("Harus array");var keys=Object.keys(a[0]||{});var csv=keys.join(",")+"\n";a.forEach(function(o){csv+=keys.map(function(k){return o[k];}).join(",")+"\n";});showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);white-space:pre-wrap;font-size:.65rem'>"+esc(csv)+"</div>");}catch(e){showResult("<div class='info-box red'>Invalid: "+esc(e.message)+"</div>");}}window.runJsonCsv=runJsonCsv;
function runUrlParse(){try{var u=new URL($("inp1").value);showResult("<div class='info-box'>Protocol: <b>"+esc(u.protocol)+"</b><br>Host: <b>"+esc(u.host)+"</b><br>Path: <b>"+esc(u.pathname)+"</b><br>Query: <b>"+esc(u.search)+"</b><br>Hash: <b>"+esc(u.hash)+"</b></div>");}catch(e){showResult("<div class='info-box red'>Invalid URL</div>");}}window.runUrlParse=runUrlParse;
function runHttpStat(){var c=parseInt($("inp1").value);var m={200:"OK",201:"Created",204:"No Content",301:"Moved",302:"Found",304:"Not Modified",400:"Bad Request",401:"Unauthorized",403:"Forbidden",404:"Not Found",405:"Method Not Allowed",429:"Too Many Requests",500:"Internal Server Error",502:"Bad Gateway",503:"Service Unavailable",504:"Gateway Timeout"};showResult("<div class='info-box'><b>"+c+"</b> "+esc(m[c]||"Unknown")+"</div>");}window.runHttpStat=runHttpStat;
function runUaView(){showResult("<div class='info-box' style='word-break:break-all'>"+esc(navigator.userAgent)+"</div>");}window.runUaView=runUaView;
function runIpInfo(){showResult(loading());fetch("https://api.ipify.org?format=json").then(function(r){return r.json();}).then(function(d){showResult("<div class='info-box'>IP: <b>"+esc(d.ip)+"</b></div>");}).catch(function(){showResult("<div class='info-box red'>Gagal ambil IP</div>");});}window.runIpInfo=runIpInfo;
function runQr(){var t=$("inp1").value.trim();if(!t){toast("Isi","err");return;}var u="https://api.qrserver.com/v1/create-qr-code/?size=400x400&data="+encodeURIComponent(t);showResult("<img src='"+u+"' style='width:100%;border-radius:14px'>");}window.runQr=runQr;
function runBarcode(){var t=$("inp1").value.trim();if(!t){toast("Isi","err");return;}var u="https://barcode.tec-it.com/barcode.ashx?data="+encodeURIComponent(t)+"&code=Code128&dpi=96";showResult("<img src='"+u+"' style='width:100%;border-radius:14px;background:#fff;padding:10px'>");}window.runBarcode=runBarcode;
function runColorPicker(){var c=$("inp1").value,r=parseInt(c.substr(1,2),16),g=parseInt(c.substr(3,2),16),b=parseInt(c.substr(5,2),16);showResult("<div style='padding:20px;background:"+c+";border-radius:14px;height:90px'></div><div class='info-box'>HEX: <b>"+c.toUpperCase()+"</b><br>RGB: <b>rgb("+r+","+g+","+b+")</b></div>");}window.runColorPicker=runColorPicker;
function runColorConv(){var c=$("inp1").value;var r=parseInt(c.substr(1,2),16),g=parseInt(c.substr(3,2),16),b=parseInt(c.substr(5,2),16);var max=Math.max(r,g,b)/255,min=Math.min(r,g,b)/255;var l=(max+min)/2;var s=0,h=0;if(max!==min){var d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);switch(max){case r/255:h=(g/255-b/255)/d+(g<b?6:0);break;case g/255:h=(b/255-r/255)/d+2;break;case b/255:h=(r/255-g/255)/d+4;break;}h*=60;}showResult("<div class='info-box'>HEX: <b>"+c.toUpperCase()+"</b><br>RGB: <b>rgb("+r+","+g+","+b+")</b><br>HSL: <b>hsl("+Math.round(h)+","+Math.round(s*100)+"%,"+Math.round(l*100)+"%)</b></div>");}window.runColorConv=runColorConv;
function runGradient(){var c1=$("inp1").value,c2=$("inp2").value;var css="linear-gradient(135deg,"+c1+","+c2+")";showResult("<div style='padding:36px;background:"+css+";border-radius:14px;margin-bottom:10px'></div><div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;font-family:var(--fm);color:var(--n);font-size:.58rem;word-break:break-all'>"+css+";</div>");}window.runGradient=runGradient;
function runPwGen(){var l=parseInt($("inp1").value)||16,p="";if($("pwU").checked)p+="ABCDEFGHIJKLMNOPQRSTUVWXYZ";if($("pwL").checked)p+="abcdefghijklmnopqrstuvwxyz";if($("pwN").checked)p+="0123456789";if($("pwS").checked)p+="!@#$%^&*";if(!p){toast("Pilih min 1","err");return;}var o="";for(var i=0;i<l;i++)o+=p.charAt(Math.floor(Math.random()*p.length));showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border:1.5px solid var(--n);border-radius:12px;color:var(--n);word-break:break-all;font-family:var(--fm)'>"+esc(o)+"</div>");}window.runPwGen=runPwGen;
function runPwCheck(){var p=$("inp1").value;var s=0;if(p.length>=8)s++;if(p.length>=12)s++;if(/[a-z]/.test(p))s++;if(/[A-Z]/.test(p))s++;if(/\d/.test(p))s++;if(/[^a-zA-Z0-9]/.test(p))s++;var lvl=s<3?"LEMAH":s<5?"SEDANG":"KUAT";var col=s<3?"#ef4444":s<5?"#fbbf24":"#00ff88";showResult("<div class='info-box'>Strength: <b style='color:"+col+"'>"+lvl+"</b> ("+s+"/6)</div>");}window.runPwCheck=runPwCheck;
function runRandom(){var mn=parseInt($("inp1").value)||0,mx=parseInt($("inp2").value)||100;var r=Math.floor(Math.random()*(mx-mn+1))+mn;showResult("<div style='text-align:center;padding:30px'><div style='font-family:var(--fd);font-size:3.5rem;font-weight:900;color:var(--n)'>"+r+"</div></div>");}window.runRandom=runRandom;
function runRandStr(){var l=parseInt($("inp1").value)||16;var c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",o="";for(var i=0;i<l;i++)o+=c.charAt(Math.floor(Math.random()*c.length));showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-family:var(--fm);word-break:break-all'>"+o+"</div>");}window.runRandStr=runRandStr;
var _swInt=null,_swStart=0;
function swStart(){if(_swInt)return;_swStart=Date.now();_swInt=setInterval(function(){var e=Date.now()-_swStart,m=Math.floor(e/60000),s=Math.floor((e%60000)/1000),d=Math.floor((e%1000)/100);var el=$("inp1");if(el)el.textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0")+"."+d;},50);}window.swStart=swStart;
function swReset(){clearInterval(_swInt);_swInt=null;var el=$("inp1");if(el)el.textContent="00:00.0";}window.swReset=swReset;
var _cdInt=null;
function runCountdown(){var s=parseInt($("inp1").value)||60;var d=$("cdDisplay");if(_cdInt)clearInterval(_cdInt);_cdInt=setInterval(function(){if(s<=0){clearInterval(_cdInt);d.textContent="SELESAI!";return;}var m=Math.floor(s/60),ss=s%60;d.textContent=String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");s--;},1000);}window.runCountdown=runCountdown;
function runPomodoro(){var el=$("pomoDisplay");var s=25*60;if(window._pomoInt)clearInterval(window._pomoInt);window._pomoInt=setInterval(function(){if(s<=0){clearInterval(window._pomoInt);el.textContent="SELESAI!";return;}var m=Math.floor(s/60),ss=s%60;el.textContent=String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");s--;},1000);}window.runPomodoro=runPomodoro;
function runCalc(){try{var r=Function("return ("+$("inp1").value+")")();showResult("<div style='padding:20px;text-align:center'><div style='font-family:var(--fd);font-size:1.8rem;font-weight:900;color:var(--n)'>"+r+"</div></div>");}catch(e){toast("Invalid","err");}}window.runCalc=runCalc;
function runLength(){var v=parseFloat($("inp1").value)||0;showResult("<div class='info-box'>Meter: <b>"+v+"</b><br>KM: <b>"+(v/1000)+"</b><br>CM: <b>"+(v*100)+"</b><br>MM: <b>"+(v*1000)+"</b></div>");}window.runLength=runLength;
function runWeight(){var v=parseFloat($("inp1").value)||0;showResult("<div class='info-box'>KG: <b>"+v+"</b><br>Gram: <b>"+(v*1000)+"</b><br>Pound: <b>"+(v*2.20462).toFixed(2)+"</b><br>Ounce: <b>"+(v*35.274).toFixed(2)+"</b></div>");}window.runWeight=runWeight;
function runTemp(){var v=parseFloat($("inp1").value)||0,f=$("inp2").value,c;if(f==="C")c=v;else if(f==="F")c=(v-32)*5/9;else c=v-273.15;showResult("<div class='info-box'>C: <b>"+c.toFixed(2)+"</b><br>F: <b>"+(c*9/5+32).toFixed(2)+"</b><br>K: <b>"+(c+273.15).toFixed(2)+"</b></div>");}window.runTemp=runTemp;
function runPercent(){var a=parseFloat($("inp1").value)||0,p=parseFloat($("inp2").value)||0;showResult("<div class='info-box'>"+p+"% dari "+a+" = <b>"+((a*p)/100)+"</b></div>");}window.runPercent=runPercent;
function runTip(){var b=parseFloat($("inp1").value)||0,p=parseFloat($("inp2").value)||0,t=b*p/100;showResult("<div class='info-box'>Tip: <b>"+t.toFixed(0)+"</b><br>Total: <b>"+(b+t).toFixed(0)+"</b></div>");}window.runTip=runTip;
function runDiscount(){var b=parseFloat($("inp1").value)||0,p=parseFloat($("inp2").value)||0,d=b*p/100;showResult("<div class='info-box'>Diskon: <b>"+d.toFixed(0)+"</b><br>Akhir: <b>"+(b-d).toFixed(0)+"</b></div>");}window.runDiscount=runDiscount;
function runBmi(){var w=parseFloat($("inp1").value),h=parseFloat($("inp2").value)/100;var b=(w/(h*h)).toFixed(1);var c=b<18.5?"UNDER":b<25?"NORMAL":b<30?"OVER":"OBESE";var col=b<18.5?"#fbbf24":b<25?"#00ff88":"#ef4444";showResult("<div style='text-align:center;padding:20px'><div style='font-family:var(--fd);font-size:56px;font-weight:900;color:"+col+"'>"+b+"</div><div style='color:"+col+";font-weight:800'>"+c+"</div></div>");}window.runBmi=runBmi;
function runAge(){var b=new Date($("inp1").value);var now=new Date(),y=now.getFullYear()-b.getFullYear();var m=now.getMonth()-b.getMonth();if(m<0||(m===0&&now.getDate()<b.getDate()))y--;showResult("<div class='info-box'>Umur: <b>"+y+" tahun</b></div>");}window.runAge=runAge;
function runLottery(){var n=parseInt($("inp1").value)||6,r=[];while(r.length<n){var x=Math.floor(Math.random()*49)+1;if(r.indexOf(x)<0)r.push(x);}r.sort(function(a,b){return a-b;});showResult("<div style='text-align:center;padding:20px'>"+r.map(function(x){return "<span style='display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--n),var(--c));color:#000;width:44px;height:44px;border-radius:50%;margin:4px;font-weight:900'>"+x+"</span>";}).join("")+"</div>");}window.runLottery=runLottery;
function runCoin(){showResult("<div style='text-align:center;padding:30px'><div style='font-family:var(--fd);font-size:1.8rem;font-weight:900;color:var(--g)'>"+(Math.random()<0.5?"HEADS":"TAILS")+"</div></div>");}window.runCoin=runCoin;
function runDice(){var n=parseInt($("inp1").value)||1,r=[];for(var i=0;i<n;i++)r.push(Math.floor(Math.random()*6)+1);var emoji={1:"⚀",2:"⚁",3:"⚂",4:"⚃",5:"⚄",6:"⚅"};showResult("<div style='text-align:center;padding:20px;font-size:3rem'>"+r.map(function(x){return emoji[x];}).join(" ")+"<div style='font-family:var(--fm);font-size:.8rem;color:var(--n);margin-top:10px'>"+r.join(" + ")+" = "+r.reduce(function(a,b){return a+b;},0)+"</div></div>");}window.runDice=runDice;
function runJoke(){var j=["Kenapa programmer suka dark mode? Karena light menarik bug!","Berapa programmer untuk ganti lampu? Nol, itu masalah hardware.","Kenapa developer bangkrut? Karena kehabisan cache.","Ada 10 tipe orang: yang ngerti binary dan yang nggak.","Programming itu 10% nulis kode, 90% nyari kenapa kodenya error."];showResult("<div style='padding:20px;text-align:center;font-size:.88rem;line-height:1.8'>"+esc(j[Math.floor(Math.random()*j.length)])+"</div>");}window.runJoke=runJoke;
function runLove(){var a=$("inp1").value.trim(),b=$("inp2").value.trim();if(!a||!b){toast("Isi 2 nama","err");return;}var h=0,s=(a+b).toLowerCase();for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%101;showResult("<div style='text-align:center;padding:24px'><div style='font-family:var(--fd);font-size:64px;font-weight:900;color:var(--n)'>"+h+"%</div></div>");}window.runLove=runLove;
function runTruth(m){var t=["Siapa yang paling kamu sayang?","Apa rahasia terbesarmu?","Pernah suka teman sendiri?","Apa hal paling memalukan?","Siapa orang yang paling kamu benci?"];var d=["Kirim pesan ke 5 orang: Aku sayang kamu","Nyanyi 30 detik","Tirukan artis favorit","Telepon teman, bilang aku kangen","Kirim selfie jelek ke grup"];var arr=m==="truth"?t:d;showResult("<div style='padding:20px;text-align:center;background:rgba(0,255,136,.15);border-radius:14px;border:1.5px solid var(--n)'><div style='font-size:.55rem;color:var(--n);font-weight:900;margin-bottom:12px'>"+(m==="truth"?"TRUTH":"DARE")+"</div><div style='font-size:.88rem;line-height:1.7'>"+esc(arr[Math.floor(Math.random()*arr.length)])+"</div></div>");}window.runTruth=runTruth;
function runSpin(){var o=($("inp1").value||"A,B,C").split(",").map(function(s){return s.trim();}).filter(Boolean);var r=o[Math.floor(Math.random()*o.length)];showResult("<div style='text-align:center;padding:30px'><div style='font-size:56px'>🎡</div><div style='font-family:var(--fd);font-size:1.5rem;font-weight:900;color:var(--n);margin-top:14px'>"+esc(r)+"</div></div>");}window.runSpin=runSpin;
function runMagic8(){var a=["Ya, pasti!","Tidak.","Mungkin.","Coba lagi nanti.","Tentu saja!","Jangan harap.","Tanya besok.","Tidak mungkin.","100% iya.","Sangat tidak mungkin."];showResult("<div style='text-align:center;padding:30px'><div style='font-size:4.5rem'>🎱</div><div style='color:var(--n);font-weight:900;margin-top:14px'>"+esc(a[Math.floor(Math.random()*a.length)])+"</div></div>");}window.runMagic8=runMagic8;
function runFortune(){var a=["Rezeki mendekat","Hati-hati keputusan","Kejutan baik","Istirahat cukup","Kesempatan baru","Jangan menyerah","Ada kabar baik"];showResult("<div style='text-align:center;padding:30px'><div style='font-size:4.5rem'>🍪</div><div style='margin-top:14px;line-height:1.7'>"+esc(a[Math.floor(Math.random()*a.length)])+"</div></div>");}window.runFortune=runFortune;
function runHoroscope(){var f=["Hari baik memulai","Waspadai keputusan","Rezeki menghampiri","Jaga kesehatan","Kabar baik datang","Hati-hati ucapan"];showResult("<div style='padding:20px;text-align:center'><div style='font-family:var(--fd);color:var(--n);font-weight:900;font-size:1.1rem'>"+$("inp1").value+"</div><div style='margin-top:12px'>"+f[Math.floor(Math.random()*f.length)]+"</div></div>");}window.runHoroscope=runHoroscope;
function runNickname(){var i=$("inp1").value.trim();var p=["xX_","Pro_","Mr_","The_","King_","Dark_","Lord_"],s=["_Xx","_Pro","_YT","_GG","_ID","_Official"];var o=p[Math.floor(Math.random()*p.length)]+i.replace(/\s/g,"")+s[Math.floor(Math.random()*s.length)];showResult("<div style='text-align:center;padding:30px;color:var(--n);font-family:var(--fd);font-weight:900;font-size:1.1rem'>"+esc(o)+"</div>");}window.runNickname=runNickname;
function runSlug(){var i=$("inp1").value;var o=i.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9\s-]/g,"").trim().replace(/\s+/g,"-");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-family:var(--fm)'>"+esc(o)+"</div>");}window.runSlug=runSlug;
function runPalindrome(){var i=$("inp1").value.toLowerCase().replace(/\s/g,"");var rev=i.split("").reverse().join("");showResult("<div class='info-box "+(i===rev?"":"red")+"'>"+(i===rev?"PALINDROME!":"BUKAN palindrome")+"</div>");}window.runPalindrome=runPalindrome;
function runVowel(){var i=$("inp1").value.toLowerCase();var v=(i.match(/[aeiou]/g)||[]).length;var k=(i.match(/[^aeiou\s]/g)||[]).length;showResult("<div class='info-box'>Vokal: <b>"+v+"</b><br>Konsonan: <b>"+k+"</b></div>");}window.runVowel=runVowel;
function runIqc(){var t=$("inp1").value.trim()||"Stay hungry.",a=$("inp2").value.trim()||"Anon";showResult("<div style='background:linear-gradient(135deg,#0a1a10,#000);padding:28px;border-radius:16px;border:1.5px solid var(--n)'><div style='color:#fff;text-align:center;font-size:1.05rem;font-style:italic'>\""+esc(t)+"\"</div><div style='text-align:center;color:var(--n);margin-top:14px;font-family:var(--fm);font-weight:900'>- "+esc(a)+"</div></div>");}window.runIqc=runIqc;
function runBrat(){showResult("<div style='background:#8ace00;padding:28px;border-radius:14px;text-align:center;font-weight:900;font-size:1.4rem;color:#000'>"+esc($("inp1").value||"brat")+"</div>");}window.runBrat=runBrat;
function runMeme(){showResult("<div style='background:#000;padding:18px;border-radius:14px;text-align:center;color:#fff;min-height:260px;display:flex;flex-direction:column;justify-content:space-between'><div style='font-weight:900;font-size:1.2rem'>"+esc($("inp1").value.toUpperCase())+"</div><div style='font-size:3.5rem'>🐱</div><div style='font-weight:900;font-size:1.2rem'>"+esc($("inp2").value.toUpperCase())+"</div></div>");}window.runMeme=runMeme;
function runQuote(){showResult("<div style='background:linear-gradient(135deg,#22d3ee,#00ff88);padding:36px;border-radius:16px;text-align:center;color:#000'><div style='font-size:2.6rem'>❝</div><div style='font-weight:600;font-style:italic'>"+esc($("inp1").value||"Quote")+"</div></div>");}window.runQuote=runQuote;
function runHashtag(){var t=$("inp1").value.replace(/\s/g,"");showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);line-height:2'>#"+esc(t)+" #"+esc(t)+"Viral #"+esc(t)+"Keren #"+esc(t)+"Trending #"+esc(t)+"FYP</div>");}window.runHashtag=runHashtag;
function runVcard(){var n=$("inp1").value,t=$("inp2").value,e=$("inp3").value;var v="BEGIN:VCARD\nVERSION:3.0\nFN:"+n+"\nTEL:"+t+"\nEMAIL:"+e+"\nEND:VCARD";showResult("<div style='padding:12px;background:rgba(0,0,0,.5);border-radius:12px;color:var(--n);font-family:var(--fm);font-size:.62rem;white-space:pre-wrap'>"+esc(v)+"</div>");}window.runVcard=runVcard;
function runEmojiArt(){showResult("<div style='text-align:center;padding:20px;font-size:2.2rem;line-height:1.4'>"+($("inp1").value||"⭐").repeat(15)+"</div>");}window.runEmojiArt=runEmojiArt;
function runFakeWa(){var u=$("inp1").value,m=$("inp2").value;showResult("<div style='background:#0b141a;padding:20px;border-radius:14px'><div style='display:flex;justify-content:flex-end'><div style='background:#005c4b;color:#fff;padding:10px 14px;border-radius:14px 14px 4px 14px;max-width:80%'><div style='color:#7de9a0;font-size:.62rem;margin-bottom:4px'>"+esc(u)+"</div>"+esc(m)+"</div></div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO - SIMULASI</div></div>");}window.runFakeWa=runFakeWa;
function runFakeWaProf(){showResult("<div style='background:#0b141a;padding:24px;border-radius:14px;text-align:center'><div style='width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#25d366,#128c7e);margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:900;color:#fff'>"+esc($("inp1").value.charAt(0).toUpperCase())+"</div><div style='color:#fff;font-weight:700;font-size:1rem'>"+esc($("inp1").value)+"</div><div style='color:#8696a0;font-size:.7rem;margin-top:4px'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeWaProf=runFakeWaProf;
function runFakeWaGroup(){showResult("<div style='background:#0b141a;padding:20px;border-radius:14px'><div style='color:#8696a0;font-size:.7rem;margin-bottom:8px'>Grup: "+esc($("inp1").value)+"</div><div style='background:#005c4b;color:#fff;padding:10px 14px;border-radius:14px;max-width:80%;font-size:.78rem'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeWaGroup=runFakeWaGroup;
function runFakeWaStatus(){showResult("<div style='background:linear-gradient(135deg,#0b141a,#001a0e);padding:30px;border-radius:14px;text-align:center;min-height:300px;display:flex;align-items:center;justify-content:center'><div style='color:#fff;font-size:1.2rem;font-weight:700'>"+esc($("inp1").value)+"</div></div>");}window.runFakeWaStatus=runFakeWaStatus;
function runFakeWaCall(){showResult("<div style='background:#0b141a;padding:40px 20px;border-radius:14px;text-align:center;min-height:300px'><div style='font-size:80px'>📞</div><div style='color:#fff;font-size:1.3rem;font-weight:700;margin-top:16px'>"+esc($("inp1").value)+"</div><div style='color:#8696a0;font-size:.7rem;margin-top:8px'>Memanggil...</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:16px'>DEMO</div></div>");}window.runFakeWaCall=runFakeWaCall;
function runFakeMsgr(){showResult("<div style='background:#0a0a0a;padding:20px;border-radius:14px'><div style='background:#0084ff;color:#fff;padding:10px 14px;border-radius:14px;max-width:80%;font-size:.78rem'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeMsgr=runFakeMsgr;
function runFakeTg(){showResult("<div style='background:#17212b;padding:20px;border-radius:14px'><div style='background:#2b5278;color:#fff;padding:10px 14px;border-radius:14px;max-width:80%;font-size:.78rem'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeTg=runFakeTg;
function runFakeIg(){showResult("<div style='background:#000;padding:20px;border-radius:14px'><div style='background:linear-gradient(135deg,#f09433,#dc2743,#bc1888);color:#fff;padding:10px 14px;border-radius:22px;max-width:80%;font-size:.78rem'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeIg=runFakeIg;
function runFakeSms(){showResult("<div style='background:#1c1c1e;padding:20px;border-radius:14px'><div style='color:#8e8e93;font-size:.65rem;margin-bottom:8px'>"+esc($("inp1").value)+"</div><div style='background:#34c759;color:#fff;padding:10px 14px;border-radius:18px;max-width:80%;font-size:.78rem'>"+esc($("inp2").value)+"</div><div style='text-align:center;font-size:.55rem;color:#8696a0;margin-top:10px'>DEMO</div></div>");}window.runFakeSms=runFakeSms;
function runFakeEmail(){showResult("<div style='background:#fff;color:#000;padding:20px;border-radius:14px'><div style='border-bottom:1px solid #ddd;padding-bottom:10px;margin-bottom:10px'><div style='font-weight:700'>"+esc($("inp2").value)+"</div><div style='font-size:.7rem;color:#666'>From: "+esc($("inp1").value)+"</div></div><div style='font-size:.82rem;line-height:1.6'>"+esc($("inp3").value)+"</div></div>");}window.runFakeEmail=runFakeEmail;
function imgToCanvas(file,cb){var r=new FileReader();r.onload=function(e){var img=new Image();img.onload=function(){cb(img);};img.src=e.target.result;};r.readAsDataURL(file);}
window.runImgResize=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var w=parseInt($("inp2").value)||800;imgToCanvas(f,function(img){var c=document.createElement("canvas");var s=w/img.width;c.width=w;c.height=img.height*s;c.getContext("2d").drawImage(img,0,0,c.width,c.height);var du=c.toDataURL("image/jpeg",0.9);showResult("<img src='"+du+"' style='width:100%;border-radius:14px'><div class='info-box'>Size: "+c.width+"x"+c.height+"</div>");});};
window.runImgCompress=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var q=(parseInt($("inp2").value)||60)/100;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;c.getContext("2d").drawImage(img,0,0);var du=c.toDataURL("image/jpeg",q);var kb=Math.round(du.length/1024);showResult("<img src='"+du+"' style='width:100%;border-radius:14px'><div class='info-box'>Size: "+kb+" KB</div>");});};
window.runImgCrop=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var x=parseInt($("inp2").value)||0,y=parseInt($("inp3").value)||0,w=parseInt($("inp4").value)||300,h=parseInt($("inp5").value)||300;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=w;c.height=h;c.getContext("2d").drawImage(img,x,y,w,h,0,0,w,h);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
window.runImgFormat=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var fmt=$("inp2").value;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;c.getContext("2d").drawImage(img,0,0);showResult("<img src='"+c.toDataURL(fmt,0.9)+"' style='width:100%;border-radius:14px'>");});};
window.runImgRotate=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var deg=parseInt($("inp2").value)||90;imgToCanvas(f,function(img){var rad=deg*Math.PI/180;var c=document.createElement("canvas");if(deg%180===0){c.width=img.width;c.height=img.height;}else{c.width=img.height;c.height=img.width;}var ctx=c.getContext("2d");ctx.translate(c.width/2,c.height/2);ctx.rotate(rad);ctx.drawImage(img,-img.width/2,-img.height/2);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
window.runImgGrayscale=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;var ctx=c.getContext("2d");ctx.drawImage(img,0,0);var d=ctx.getImageData(0,0,c.width,c.height);for(var i=0;i<d.data.length;i+=4){var g=0.299*d.data[i]+0.587*d.data[i+1]+0.114*d.data[i+2];d.data[i]=d.data[i+1]=d.data[i+2]=g;}ctx.putImageData(d,0,0);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
window.runImgBlur=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var b=parseInt($("inp2").value)||5;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;var ctx=c.getContext("2d");ctx.filter="blur("+b+"px)";ctx.drawImage(img,0,0);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
window.runImgBrightness=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var b=parseInt($("inp2").value)||120;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;var ctx=c.getContext("2d");ctx.filter="brightness("+b+"%)";ctx.drawImage(img,0,0);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
window.runImgContrast=function(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var b=parseInt($("inp2").value)||120;imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width;c.height=img.height;var ctx=c.getContext("2d");ctx.filter="contrast("+b+"%)";ctx.drawImage(img,0,0);showResult("<img src='"+c.toDataURL("image/png")+"' style='width:100%;border-radius:14px'>");});};
function aiHistGet(){try{return JSON.parse(localStorage.getItem("damz_ai_hist_v6_"+CURRENT_USER)||"[]");}catch(e){return[];}}
function aiHistSave(l){try{localStorage.setItem("damz_ai_hist_v6_"+CURRENT_USER,JSON.stringify(l));}catch(e){}}
function renderAiHist(){var el=$("aiHist");if(!el)return;var hist=aiHistGet();if(!hist.length){el.innerHTML="";return;}var h="<div style='font-size:.5rem;color:var(--c);letter-spacing:2px;font-weight:900;margin:10px 0 6px'>HISTORY ("+hist.length+")</div>";hist.slice(0,5).forEach(function(it){h+="<div style='padding:8px;background:rgba(0,0,0,.3);border-radius:10px;margin-bottom:6px;border-left:3px solid var(--n)'><div style='font-size:.65rem;color:#fff;font-weight:700'>Q: "+esc(it.q.slice(0,50))+"...</div><div style='font-size:.6rem;color:#7bffb9;margin-top:4px'>A: "+esc(it.a.slice(0,80))+"...</div></div>";});el.innerHTML=h;}
function runAiChat(){var q=$("inp1").value.trim();if(!q){toast("Isi pertanyaan","err");return;}showResult(loading());var endpoint="https://text.pollinations.ai/"+encodeURIComponent(q)+"?model=openai";var ctrl=new AbortController();var to=setTimeout(function(){ctrl.abort();},30000);fetch(endpoint,{signal:ctrl.signal}).then(function(r){return r.text();}).then(function(txt){clearTimeout(to);if(!txt||txt.length<2)throw new Error("empty");var hist=aiHistGet();hist.unshift({q:q,a:txt.trim().slice(0,200),t:Date.now()});hist=hist.slice(0,20);aiHistSave(hist);renderAiHist();var r2=$("toolResult");if(r2){r2.style.display="block";r2.innerHTML='<div style="padding:14px;background:linear-gradient(135deg,rgba(0,255,136,.1),rgba(34,211,238,.05));border-radius:14px;border:1.5px solid var(--n);line-height:1.7;font-size:.82rem;color:#fff;white-space:pre-wrap;word-wrap:break-word;max-height:400px;overflow-y:auto">'+esc(txt.trim())+'</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button class="btn sec" onclick="copyResultText()" type="button">SALIN</button><button class="btn cyan" onclick="downloadResultText()" type="button">DOWNLOAD</button></div>';}}).catch(function(){clearTimeout(to);showResult("<div class='info-box red'>AI tidak merespon</div>");});}
window.runAiChat=runAiChat;
window.clearAiHist=function(){showModal("fa-trash","HAPUS HISTORY","Hapus semua history AI Chat?","HAPUS",function(){localStorage.removeItem("damz_ai_hist_v6_"+CURRENT_USER);renderAiHist();toast("History AI dihapus","ok");closeModal();},"var(--r)");};
function runAiImage(){var p=$("inp1").value.trim();if(!p){toast("Isi prompt","err");return;}showResult(loading());var u="https://image.pollinations.ai/prompt/"+encodeURIComponent(p)+"?width=1024&height=1024&nologo=true&seed="+Date.now();var img=new Image();img.onload=function(){var r=$("toolResult");if(!r)return;r.style.display="block";r.innerHTML='<div class="info-box">Berhasil!</div><img id="aiImgResult" src="'+u+'" style="width:100%;border-radius:14px;margin-bottom:10px"><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button class="btn green" onclick="downloadAiImage()" type="button">DOWNLOAD</button><button class="btn sec" onclick="runAiImage()" type="button">REGEN</button></div>';};img.onerror=function(){showResult("<div class='info-box red'>Gagal</div>");};img.src=u;}
window.runAiImage=runAiImage;
window.downloadAiImage=function(){var img=$("aiImgResult");if(!img)return;fetch(img.src).then(function(r){return r.blob();}).then(function(b){var u=URL.createObjectURL(b);var a=document.createElement("a");a.href=u;a.download="ai_"+Date.now()+".png";a.click();toast("Downloaded","ok");}).catch(function(){window.open(img.src,"_blank");});};
function runAiTranslate(){var t=$("inp1").value.trim(),to=$("inp2").value;if(!t){toast("Isi text","err");return;}showResult(loading());fetch("https://api.mymemory.translated.net/get?q="+encodeURIComponent(t)+"&langpair=id|"+to).then(function(r){return r.json();}).then(function(d){var o=(d.responseData&&d.responseData.translatedText)?d.responseData.translatedText:"(kosong)";showResult("<div style='padding:14px;background:rgba(0,0,0,.4);border-radius:12px;border:1.5px solid var(--n);line-height:1.7'>"+esc(o)+"</div>");}).catch(function(){showResult("<div class='info-box red'>Gagal</div>");});}
window.runAiTranslate=runAiTranslate;
function runHdImage(){var f=$("inp1").files[0];if(!f){toast("Pilih gambar","err");return;}var level=parseInt($("inp2")?$("inp2").value:2)||2;showResult(loading());imgToCanvas(f,function(img){var c=document.createElement("canvas");c.width=img.width*level;c.height=img.height*level;var x=c.getContext("2d");x.imageSmoothingEnabled=true;x.imageSmoothingQuality="high";x.drawImage(img,0,0,c.width,c.height);var du=c.toDataURL("image/jpeg",0.95);var r2=$("toolResult");if(r2){r2.style.display="block";r2.innerHTML='<div class="info-box">HD: '+c.width+'x'+c.height+'</div><img id="hdResultImg" src="'+du+'" style="width:100%;border-radius:14px;margin-bottom:10px"><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button class="btn green" onclick="downloadHdImage()" type="button">DOWNLOAD</button><button class="btn sec" onclick="copyHdBase64()" type="button">SALIN</button></div>';}});}
window.runHdImage=runHdImage;
window.downloadHdImage=function(){var img=$("hdResultImg");if(!img)return;var a=document.createElement("a");a.href=img.src;a.download="hd_"+Date.now()+".jpg";a.click();toast("Downloaded","ok");};
window.copyHdBase64=function(){var img=$("hdResultImg");if(!img)return;copyText(img.src);};
function runTts(){var t=$("inp1").value.trim();var lang=$("inp2")?$("inp2").value:"id";if(!t){toast("Isi text","err");return;}if(t.length>200){toast("Max 200","err");return;}var r=$("toolResult");if(r){r.style.display="block";r.innerHTML='<div style="text-align:center;padding:24px"><div style="font-size:64px;margin-bottom:14px">🔊</div><div style="font-family:var(--fd);color:var(--n);font-weight:900;letter-spacing:2px">MEMUAT AUDIO...</div></div>';}if("speechSynthesis" in window){try{speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(t);var lc={id:"id-ID",en:"en-US",ja:"ja-JP"}[lang]||"id-ID";u.lang=lc;u.rate=0.95;u.onend=function(){var r2=$("toolResult");if(r2){r2.style.display="block";r2.innerHTML='<div style="text-align:center;padding:24px"><div style="font-size:64px;margin-bottom:14px">🔊</div><div style="font-family:var(--fd);color:var(--n);font-weight:900;letter-spacing:2px">SELESAI</div><button class="btn red" style="margin-top:16px" onclick="stopTts()">ULANGI</button></div>';}};speechSynthesis.speak(u);toast("Memutar...","ok");}catch(e){showResult("<div class='info-box red'>TTS gagal</div>");}}else showResult("<div class='info-box red'>TTS tidak support</div>");}
window.runTts=runTts;
window.stopTts=function(){try{if(window.speechSynthesis)speechSynthesis.cancel();}catch(e){}toast("Stop","ok");};
if(typeof speechSynthesis!=="undefined"){speechSynthesis.onvoiceschanged=function(){speechSynthesis.getVoices();};speechSynthesis.getVoices();}

window.VC={ctx:null,source:null,stream:null,processors:null,gain:null,analyser:null,recorder:null,chunks:[],recording:false,active:false,preset:"none",visualizerRAF:null,callDest:null};
window.VC_PRESETS={
none:{pitch:1.0,tremolo:0,robot:false,echo:0,lp:20000,hp:20,label:"Normal",icon:"fa-microphone",color:"#00ff88"},
chipmunk:{pitch:1.65,tremolo:0,robot:false,echo:0,lp:12000,hp:400,label:"Chipmunk",icon:"fa-mask",color:"#fbbf24"},
deep:{pitch:0.6,tremolo:0,robot:false,echo:0,lp:6000,hp:20,label:"Deep",icon:"fa-user-ninja",color:"#c084fc"},
robot:{pitch:1.0,tremolo:0,robot:true,echo:0,lp:8000,hp:200,label:"Robot",icon:"fa-robot",color:"#22d3ee"},
alien:{pitch:1.4,tremolo:0.8,robot:false,echo:0.2,lp:10000,hp:600,label:"Alien",icon:"fa-user-astronaut",color:"#22c55e"},
echo:{pitch:1.0,tremolo:0,robot:false,echo:0.5,lp:15000,hp:20,label:"Echo",icon:"fa-wave-square",color:"#f43f5e"},
vibrato:{pitch:1.0,tremolo:1.0,robot:false,echo:0,lp:16000,hp:20,label:"Vibrato",icon:"fa-water",color:"#06b6d4"},
telephone:{pitch:1.0,tremolo:0,robot:false,echo:0,lp:3400,hp:300,label:"Telepon",icon:"fa-phone",color:"#f59e0b"},
whisper:{pitch:1.0,tremolo:0,robot:false,echo:0.1,lp:5000,hp:2000,label:"Bisik",icon:"fa-comment-slash",color:"#86efac"}
};
function createPitchShifter(ctx,pitchFactor){
var bufSize=4096;
var node=ctx.createScriptProcessor(bufSize,1,1);
var buffer=new Float32Array(bufSize);
var writePtr=0,readPtr=0,fade=48;
node.onaudioprocess=function(e){
var input=e.inputBuffer.getChannelData(0);
var output=e.outputBuffer.getChannelData(0);
for(var i=0;i<input.length;i++){buffer[writePtr]=input[i];writePtr=(writePtr+1)%bufSize;}
for(var j=0;j<output.length;j++){
readPtr+=pitchFactor;
if(readPtr>=bufSize)readPtr-=bufSize;
if(readPtr<0)readPtr+=bufSize;
var idx=Math.floor(readPtr);
var frac=readPtr-idx;
var s0=buffer[idx],s1=buffer[(idx+1)%bufSize];
var sample=s0+(s1-s0)*frac;
var w=1;
var dist=Math.min(readPtr,bufSize-readPtr);
if(dist<fade)w=dist/fade;
output[j]=sample*w;
}
var diff=(writePtr-readPtr+bufSize)%bufSize;
if(diff<512)readPtr=(readPtr+512)%bufSize;
};
return node;
}
function createRobot(ctx){
var node=ctx.createScriptProcessor(1024,1,1);
var phase=0;
var freq=42;
node.onaudioprocess=function(e){
var input=e.inputBuffer.getChannelData(0);
var output=e.outputBuffer.getChannelData(0);
for(var i=0;i<output.length;i++){
phase+=2*Math.PI*freq/ctx.sampleRate;
if(phase>2*Math.PI)phase-=2*Math.PI;
var mod=Math.sin(phase)>0?1:-1;
output[i]=input[i]*mod*0.75;
}
};
return node;
}
function createTremolo(ctx,depth){
var node=ctx.createScriptProcessor(1024,1,1);
var phase=0;
var freq=6.5;
node.onaudioprocess=function(e){
var input=e.inputBuffer.getChannelData(0);
var output=e.outputBuffer.getChannelData(0);
for(var i=0;i<output.length;i++){
phase+=2*Math.PI*freq/ctx.sampleRate;
if(phase>2*Math.PI)phase-=2*Math.PI;
var g=1-depth*0.5*(1-Math.cos(phase));
output[i]=input[i]*g;
}
};
return node;
}
function buildVoiceChain(presetKey,micStream){
stopVoiceChain(true);
var p=VC_PRESETS[presetKey]||VC_PRESETS.none;
VC.ctx=new (window.AudioContext||window.webkitAudioContext)();
VC.stream=micStream;
VC.source=VC.ctx.createMediaStreamSource(micStream);
VC.processors={};
var hp=VC.ctx.createBiquadFilter();
hp.type="highpass";
hp.frequency.value=p.hp;
var lp=VC.ctx.createBiquadFilter();
lp.type="lowpass";
lp.frequency.value=p.lp;
var node=hp;
VC.source.connect(hp);
if(p.pitch!==1.0){
var pitchNode=createPitchShifter(VC.ctx,p.pitch);
VC.processors.pitch=pitchNode;
node.connect(pitchNode);
node=pitchNode;
}
if(p.robot){
var robotNode=createRobot(VC.ctx);
VC.processors.robot=robotNode;
node.connect(robotNode);
node=robotNode;
}
if(p.tremolo>0){
var tremNode=createTremolo(VC.ctx,p.tremolo);
VC.processors.trem=tremNode;
node.connect(tremNode);
node=tremNode;
}
node.connect(lp);
node=lp;
if(p.echo>0){
var delay=VC.ctx.createDelay(1);
delay.delayTime.value=0.28;
var feedback=VC.ctx.createGain();
feedback.gain.value=p.echo;
var wet=VC.ctx.createGain();
wet.gain.value=0.55;
delay.connect(feedback);
feedback.connect(delay);
var dry=VC.ctx.createGain();
dry.gain.value=0.75;
node.connect(dry);
node.connect(delay);
delay.connect(wet);
var mix=VC.ctx.createGain();
mix.gain.value=1;
dry.connect(mix);
wet.connect(mix);
node=mix;
VC.processors.delay=delay;
}
VC.analyser=VC.ctx.createAnalyser();
VC.analyser.fftSize=512;
VC.gain=VC.ctx.createGain();
VC.gain.gain.value=1;
node.connect(VC.analyser);
VC.analyser.connect(VC.gain);
VC.gain.connect(VC.ctx.destination);
VC.active=true;
VC.preset=presetKey;
startVisualizer();
vcRenderStatus();
if(typeof CALL_STATE!=="undefined"&&CALL_STATE.active)vcAttachToCall();
return VC.ctx;
}
window.vcAttachToCall=function(){
if(!VC.ctx||!VC.gain)return;
if(!CALL_STATE||!CALL_STATE.active)return;
try{VC.gain.disconnect(VC.ctx.destination);}catch(e){}
if(!VC.callDest){
VC.callDest=VC.ctx.createMediaStreamDestination();
VC.gain.connect(VC.callDest);
}
var newTrack=VC.callDest.stream.getAudioTracks()[0];
if(!newTrack)return;
Object.keys(CALL_STATE.pcs||{}).forEach(function(key){
var pc=CALL_STATE.pcs[key];
if(!pc)return;
pc.getSenders().forEach(function(sender){
if(sender.track&&sender.track.kind==="audio"){
sender.replaceTrack(newTrack).catch(function(){});
}
});
});
if(CALL_STATE.localStream){
CALL_STATE.localStream.getAudioTracks().forEach(function(t){t.stop();});
CALL_STATE.localStream.addTrack(newTrack);
}
toast("Voice Changer aktif di panggilan","ok");
};
function stopVoiceChain(keepStream){
try{if(VC.visualizerRAF)cancelAnimationFrame(VC.visualizerRAF);VC.visualizerRAF=null;}catch(e){}
try{if(!keepStream&&VC.stream){VC.stream.getTracks().forEach(function(t){t.stop();});}}catch(e){}
try{Object.keys(VC.processors||{}).forEach(function(k){try{VC.processors[k].disconnect();}catch(e){}});}catch(e){}
try{if(VC.source)VC.source.disconnect();}catch(e){}
try{if(VC.gain)VC.gain.disconnect();}catch(e){}
try{if(VC.analyser)VC.analyser.disconnect();}catch(e){}
try{if(VC.ctx&&VC.ctx.state!=="closed")VC.ctx.close();}catch(e){}
VC.ctx=null;VC.source=null;VC.processors={};VC.gain=null;VC.analyser=null;VC.callDest=null;
if(!keepStream)VC.stream=null;
VC.active=false;
if(typeof vcRenderStatus==="function")vcRenderStatus();
}
function startVisualizer(){
var canvas=$("vcVisualizerCanvas");
if(!canvas)return;
var ctx2d=canvas.getContext("2d");
var W=canvas.width=canvas.offsetWidth||300;
var H=canvas.height=canvas.offsetHeight||70;
var dataArray=new Uint8Array(VC.analyser.frequencyBinCount);
function draw(){
if(!VC.active||!VC.analyser)return;
VC.visualizerRAF=requestAnimationFrame(draw);
VC.analyser.getByteFrequencyData(dataArray);
ctx2d.fillStyle="rgba(5,16,9,0.25)";
ctx2d.fillRect(0,0,W,H);
var barW=(W/dataArray.length)*2.5;
var x=0;
for(var i=0;i<dataArray.length;i++){
var barH=(dataArray[i]/255)*H;
var grad=ctx2d.createLinearGradient(0,H-barH,0,H);
grad.addColorStop(0,"#00ff88");
grad.addColorStop(0.5,"#22d3ee");
grad.addColorStop(1,"#22c55e");
ctx2d.fillStyle=grad;
ctx2d.fillRect(x,H-barH,barW-1,barH);
x+=barW;
}
}
draw();
}
window.vcStart=function(presetKey){
if(VC.active){vcSetPreset(presetKey);return;}
navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}}).then(function(stream){buildVoiceChain(presetKey,stream);toast("Voice aktif: "+(VC_PRESETS[presetKey]?VC_PRESETS[presetKey].label:presetKey),"ok");}).catch(function(err){toast("Mic ditolak: "+err.message,"err");});
};
window.vcStop=function(){stopVoiceChain(false);toast("Voice changer OFF","ok");};
window.vcSetPreset=function(presetKey){
if(!VC.active){vcStart(presetKey);return;}
if(!VC.stream){toast("Stream hilang","err");return;}
buildVoiceChain(presetKey,VC.stream);
toast("Preset: "+(VC_PRESETS[presetKey]?VC_PRESETS[presetKey].label:presetKey),"ok");
};
window.vcRecordStart=function(){
if(!VC.active){toast("Aktifkan voice changer dulu","err");return;}
if(!window.MediaRecorder){toast("Recorder tidak support","err");return;}
VC.chunks=[];
var dest=VC.ctx.createMediaStreamDestination();
VC.gain.connect(dest);
VC.recorder=new MediaRecorder(dest.stream,{mimeType:"audio/webm"});
VC.recorder.ondataavailable=function(e){if(e.data.size>0)VC.chunks.push(e.data);};
VC.recorder.onstop=function(){
var blob=new Blob(VC.chunks,{type:"audio/webm"});
var url=URL.createObjectURL(blob);
var player=$("vcPlayer");
if(player){player.src=url;player.style.display="block";}
var dl=$("vcDownload");
if(dl){dl.href=url;dl.download="voice_"+Date.now()+".webm";dl.style.display="inline-flex";}
toast("Rekaman selesai","ok");
VC.recording=false;
vcRenderStatus();
};
VC.recorder.start();
VC.recording=true;
vcRenderStatus();
toast("Mulai rekam...","ok");
};
window.vcRecordStop=function(){if(VC.recorder&&VC.recording){VC.recorder.stop();toast("Stop rekam","ok");}};
window.vcRenderStatus=function(){
var status=$("vcStatus");
if(status){
if(VC.recording){status.className="vc-status on";status.textContent="REC";status.style.animation="recPulse 1.2s infinite";}
else if(VC.active){status.className="vc-status on";status.textContent="AKTIF";}
else{status.className="vc-status off";status.textContent="OFF";}
}
var startBtn=$("vcStartBtn"),stopBtn=$("vcStopBtn"),recBtn=$("vcRecBtn");
if(startBtn)startBtn.disabled=VC.active;
if(stopBtn)stopBtn.disabled=!VC.active;
if(recBtn)recBtn.disabled=!VC.active;
document.querySelectorAll(".vc-preset").forEach(function(el){var p=el.getAttribute("data-preset");if(p===VC.preset&&VC.active)el.classList.add("active");else el.classList.remove("active");});
};
window.vcRenderUI=function(){
var el=$("voiceChangerUI");
if(!el)return;
if(!IS_OWNER){el.innerHTML='<div class="info-box red">Fitur Voice Changer hanya untuk Owner.</div>';return;}
var h='<div class="voice-changer-panel" style="padding:4px">';
h+='<div style="display:flex;align-items:center;gap:12px;padding:12px;background:linear-gradient(135deg,rgba(168,85,247,.15),rgba(15,36,22,.6));border:1.5px solid rgba(168,85,247,.5);border-radius:14px;margin-bottom:12px"><div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--p),var(--p2));display:flex;align-items:center;justify-content:center;color:#000;font-size:20px"><i class="fas fa-wave-square"></i></div><div style="flex:1"><div style="font-family:var(--fd);font-size:.8rem;font-weight:900;color:#fff;letter-spacing:2px">VOICE CHANGER</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--p2);letter-spacing:2px;margin-top:2px">OWNER ONLY</div></div><div id="vcStatus" class="vc-status off" style="padding:6px 12px;border-radius:8px;font-family:var(--fm);font-size:.55rem;font-weight:900;background:rgba(107,114,128,.3);color:#9ca3af">OFF</div></div>';
h+='<div style="height:70px;background:rgba(0,0,0,.5);border-radius:12px;overflow:hidden;margin-bottom:12px;border:1px solid var(--b)"><canvas id="vcVisualizerCanvas" style="width:100%;height:100%"></canvas></div>';
h+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">';
Object.keys(VC_PRESETS).forEach(function(k){
var p=VC_PRESETS[k];
h+='<div class="vc-preset" data-preset="'+k+'" onclick="vcSetPreset(\''+k+'\')" style="padding:10px 6px;background:rgba(15,36,22,.6);border:1.5px solid '+p.color+'55;border-radius:12px;text-align:center;cursor:pointer;transition:all .15s"><i class="fas '+p.icon+'" style="color:'+p.color+';font-size:16px;margin-bottom:4px;display:block"></i><span style="font-family:var(--fm);font-size:.5rem;color:'+p.color+';font-weight:900">'+p.label.toUpperCase()+'</span></div>';
});
h+='</div>';
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px"><button class="btn green" id="vcStartBtn" onclick="vcStart(VC.preset||\'none\')"><i class="fas fa-play"></i> START</button><button class="btn red" id="vcStopBtn" onclick="vcStop()"><i class="fas fa-stop"></i> STOP</button></div>';
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px"><button class="btn cyan" id="vcRecBtn" onclick="vcRecordStart()"><i class="fas fa-circle"></i> REKAM</button><button class="btn gold" onclick="vcRecordStop()"><i class="fas fa-square"></i> STOP REKAM</button></div>';
h+='<audio id="vcPlayer" controls style="width:100%;margin-top:8px;display:none"></audio>';
h+='<a id="vcDownload" class="btn sec" style="margin-top:8px;display:none"><i class="fas fa-download"></i> DOWNLOAD</a>';
h+='</div>';
el.innerHTML=h;
vcRenderStatus();
setTimeout(function(){if(VC.active)startVisualizer();},300);
};
