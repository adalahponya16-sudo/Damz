
function renderProfile(){
if(!CURRENT_USER)return;
var m=getMembers(),u=m[CURRENT_USER]||{};
var tools=u.toolsUsed||0,login=u.loginCount||1,coins=u.coins||0;
var first=u.firstLogin?new Date(u.firstLogin):new Date();
var days=Math.floor((Date.now()-first.getTime())/86400000);
if($("profDisplay"))$("profDisplay").textContent=CURRENT_DISPLAY||CURRENT_USER;
var b="";
if(IS_OWNER)b+="<span class='member-badge owner-b'>OWNER</span>";
else if(IS_ADMIN)b+="<span class='member-badge admin-b'>ADMIN</span>";
else if(IS_VIP||u.vip)b+="<span class='member-badge vip-b'>VIP</span>";
else b+="<span class='member-badge member-b'>MEMBER</span>";
if($("profBadgeRow"))$("profBadgeRow").innerHTML=b;
if($("pStatCoins"))$("pStatCoins").textContent=coins;
if($("pStatTools"))$("pStatTools").textContent=tools;
if($("pStatLogin"))$("pStatLogin").textContent=login;
if($("pStatJoin"))$("pStatJoin").textContent=days+"d";
if($("profIdText"))$("profIdText").textContent=CURRENT_ID;
if($("heroIdText"))$("heroIdText").textContent=CURRENT_ID;
checkDailyBonus();updateCoinUI();applyUserPP();
}
window.renderProfile=renderProfile;
window.copyMyId=function(){if(!CURRENT_ID)return;copyText(CURRENT_ID);toast("ID disalin: "+CURRENT_ID,"ok");};

window.openPPPicker=function(){
if(!CURRENT_USER){toast("Login dulu","err");return;}
var cur=getUserPP(CURRENT_USER);var init=CURRENT_DISPLAY.charAt(0).toUpperCase();
var h='<div style="text-align:left"><div class="pp-preview" id="ppPreviewBig"'+(cur?' style="background-image:url('+cur+')"':'')+'>'+(cur?"":init)+'</div><input type="file" id="ppFileInput" accept="image/*" style="display:none"><button class="btn green" onclick="document.getElementById(\'ppFileInput\').click()"><i class="fas fa-upload"></i> PILIH FOTO</button>';
if(cur)h+='<button class="btn red" onclick="doRemovePP()"><i class="fas fa-trash"></i> HAPUS</button>';
h+='</div>';
showModal("fa-image","FOTO PROFIL",h,"TUTUP",null,"var(--n)");
setTimeout(function(){var inp=$("ppFileInput");if(inp)inp.onchange=function(e){var f=e.target.files[0];if(!f)return;if(f.size>5*1024*1024){toast("Max 5MB","err");return;}compressImage(f,400,400,250,function(du,kb){setUserPP(CURRENT_USER,du);applyUserPP();toast("PP tersimpan ("+kb+"KB)","ok");closeModal();});};},100);
};
window.doRemovePP=function(){showModal("fa-trash","HAPUS","Yakin?","HAPUS",function(){var m=getMembers();if(m[CURRENT_USER])delete m[CURRENT_USER].pp;saveMembers(m);applyUserPP();closeModal();},"var(--r)");};

function applyUserPP(){if(!CURRENT_USER)return;var pp=getUserPP(CURRENT_USER);var hAv=$("heroAv"),pAv=$("profBigAv");[hAv,pAv].forEach(function(el){if(!el)return;if(pp){el.style.backgroundImage="url("+pp+")";el.style.backgroundSize="cover";el.style.backgroundPosition="center";var sp=el.querySelector("span");if(sp)sp.style.display="none";}else{el.style.backgroundImage="";var sp2=el.querySelector("span");if(sp2)sp2.style.display="";}});}
window.applyUserPP=applyUserPP;

function renderUserMenu(){
var el=$("userMenuGrid");if(!el)return;
var items=[
{id:"pp",n:"Ganti PP",d:"Upload",ico:"fa-image"},
{id:"name",n:"Ganti Nama",d:"Tampilan",ico:"fa-signature"},
{id:"myid",n:"ID Saya",d:"Lihat",ico:"fa-id-badge"},
{id:"pwd",n:"Ganti Password",d:"Ubah",ico:"fa-key"},
{id:"blocked",n:"Kontak Diblokir",d:"Kelola",ico:"fa-ban"},
{id:"mygroups",n:"Grup Saya",d:"Kelola",ico:"fa-users"},
{id:"perm",n:"Izin App",d:"Permission",ico:"fa-shield-halved"},
{id:"about",n:"Tentang",d:"Versi",ico:"fa-circle-info"},
{id:"delacc",n:"Hapus Akun",d:"Permanen",ico:"fa-user-xmark"}
];
var h="";
items.forEach(function(it){h+='<div class="ow-card" onclick="userMenuAction(\''+it.id+'\')"><div class="ow-card-ico"><i class="fas '+it.ico+'"></i></div><div class="ow-card-nm">'+it.n+'</div><div class="ow-card-ds">'+it.d+'</div></div>';});
el.innerHTML=h;
}
window.renderUserMenu=renderUserMenu;

window.userMenuAction=function(id){
if(id==="pp"){openPPPicker();return;}
if(id==="name"){profileAction("display");return;}
if(id==="myid"){showMyId();return;}
if(id==="pwd"){profileAction("password");return;}
if(id==="blocked"){if(typeof showBlockedList==="function")showBlockedList();return;}
if(id==="mygroups"){if(typeof showMyGroupsList==="function")showMyGroupsList();return;}
if(id==="perm"){requestNativePermissions();toast("Minta izin...","ok");return;}
if(id==="about"){profileAction("about");return;}
if(id==="delacc"){confirmDeleteMyAccount();return;}
};

window.showMyId=function(){
showModal("fa-id-badge","ID SAYA",'<div style="text-align:center;padding:20px 0"><div style="font-family:var(--fm);font-size:2rem;font-weight:900;color:var(--c);letter-spacing:6px;margin-bottom:14px;text-shadow:0 0 20px rgba(34,211,238,.6)">'+CURRENT_ID+'</div><div style="font-size:.68rem;color:var(--t2);line-height:1.8">Bagikan ID ini ke teman.<br>Mereka bisa tambah kamu lewat menu <b style="color:var(--n)">Tambah Kontak</b>.</div></div><button class="btn cyan" onclick="copyMyId();closeModal();"><i class="fas fa-copy"></i> SALIN ID</button>',"TUTUP",null,"var(--c)");
};

function profileAction(type){
if(type==="password"){
showModal("fa-key","GANTI PASSWORD","<label class='lbl'>Password Lama</label><input class='inp' id='cpOld' type='password'><label class='lbl'>Password Baru</label><input class='inp' id='cpNew' type='password'>","GANTI",function(){
var op=$("cpOld").value,np=$("cpNew").value;
var m=getMembers();
if(!m[CURRENT_USER]){toast("User tidak ada","err");return;}
if(m[CURRENT_USER].pass!==hashPass(op)){toast("Password lama salah","err");return;}
if(!np||np.length<4){toast("Min 4","err");return;}
m[CURRENT_USER].pass=hashPass(np);saveMembers(m);toast("Password diganti","ok");logAction("password_change",CURRENT_USER);
},"var(--n)");
}else if(type==="display"){
var cur=CURRENT_DISPLAY||CURRENT_USER;
showModal("fa-signature","GANTI NAMA TAMPILAN",'<label class="lbl">Nama Baru</label><input class="inp" id="newDisplay" value="'+esc(cur)+'" maxlength="24"><div class="info-box" style="margin-top:10px">Nama ini yang dilihat orang lain di kontak mereka.</div>',"SIMPAN",function(){
var nv=$("newDisplay").value.trim();
if(!nv||nv.length<2){toast("Min 2 karakter","err");return;}
var m=getMembers();
if(!m[CURRENT_USER])m[CURRENT_USER]={username:CURRENT_USER};
m[CURRENT_USER].display=nv;
saveMembers(m);CURRENT_DISPLAY=nv;
if($("heroName"))$("heroName").textContent=nv;
if($("profDisplay"))$("profDisplay").textContent=nv;
if($("heroAvatarText"))$("heroAvatarText").textContent=nv.charAt(0).toUpperCase();
if($("profBigAv"))$("profBigAv").textContent=nv.charAt(0).toUpperCase();
toast("Nama diubah","ok");
},"var(--n)");
}else if(type==="about"){
showModal("fa-circle-info","TENTANG APP","<div style='text-align:center;padding:12px'><div style='font-size:56px;margin-bottom:10px;color:var(--n)'><i class='fas fa-cube'></i></div><div style='font-family:var(--fd);font-size:1.2rem;font-weight:900;color:var(--n);letter-spacing:3px'>DAMZ NEXUS v1</div><div style='font-family:var(--fm);font-size:.6rem;color:var(--c);margin-top:10px'>VERSION "+APP_VERSION+"</div><div style='font-family:var(--fm);font-size:.5rem;color:var(--t3);margin-top:14px;word-break:break-all'>Device ID: "+esc(DEVICE_FP)+"</div><div style='font-family:var(--fm);font-size:.5rem;color:var(--t3);margin-top:6px'>User ID: "+esc(CURRENT_ID)+"</div></div>","TUTUP",null,"var(--c)");
}
}
window.profileAction=profileAction;

window.confirmDeleteMyAccount=function(){
showModal("fa-user-xmark","HAPUS AKUN PERMANEN",'<div style="text-align:left"><div class="info-box red"><b>PERINGATAN!</b><br>Akun <b style="color:var(--r)">'+esc(CURRENT_USER)+'</b> akan dihapus PERMANEN dari Firebase.<br><br>Semua data hilang:<br>- Chat & pesan<br>- Kontak<br>- Grup<br>- Koin & VIP<br>- Foto profil<br><br><b>Tidak bisa dikembalikan!</b></div></div>',"HAPUS TOTAL",function(){
var u=CURRENT_USER;
if(!db){toast("DB tidak ready","err");closeModal();return;}
toast("Menghapus akun...","err");
db.ref("members/"+u).remove().catch(function(){});
db.ref("memberLocations/"+u).remove().catch(function(){});
db.ref("chats").once("value").then(function(s){var c=s.val()||{};Object.keys(c).forEach(function(k){if(k.indexOf(u)>=0){db.ref("chats/"+k).remove().catch(function(){});}});});
db.ref("groupChats").once("value").then(function(s){var gc=s.val()||{};Object.keys(gc).forEach(function(gid){var msgs=gc[gid]||{};Object.keys(msgs).forEach(function(mid){if(msgs[mid]&&msgs[mid].from===u){db.ref("groupChats/"+gid+"/"+mid).remove().catch(function(){});}});});});
db.ref("groups").once("value").then(function(s){var gs=s.val()||{};Object.keys(gs).forEach(function(gid){var g=gs[gid];if(!g)return;if(g.owner===u){db.ref("groups/"+gid).remove();db.ref("groupChats/"+gid).remove();}else if(g.members&&g.members.indexOf(u)>=0){var nm=g.members.filter(function(x){return x!==u;});db.ref("groups/"+gid+"/members").set(nm);}});});
var m=getMembers();
if(m[u]&&m[u].deviceId){db.ref("deviceBlacklist/"+m[u].deviceId).remove().catch(function(){});}
try{
localStorage.removeItem("damz_user_v7");
localStorage.removeItem("damz_owner_v7");
localStorage.removeItem("damz_admin_v7");
localStorage.removeItem("damz_vip_v7");
localStorage.removeItem("damz_contacts_v6_"+u);
localStorage.removeItem("damz_groups_v7_"+u);
localStorage.removeItem("damz_pinned_v7_"+u);
localStorage.removeItem("damz_ai_hist_v6_"+u);
localStorage.removeItem("damz_daily_bonus_v6_"+u);
localStorage.removeItem("damz_loc_asked_v9");
localStorage.removeItem("damz_loc_enabled_v9");
}catch(e){}
var m2=getMembers();delete m2[u];_membersCache=m2;
toast("Akun dihapus. Logout...","ok");
closeModal();
setTimeout(function(){try{if(db)db.ref("members/"+u).remove();}catch(e){}location.reload();},1500);
},"var(--r)");
};

function checkDailyBonus(){if(!CURRENT_USER)return;var today=new Date().toISOString().slice(0,10);var last=localStorage.getItem("damz_daily_bonus_v6_"+CURRENT_USER)||"";var btn=$("dailyBonusBtn"),txt=$("dailyBonusText");if(!btn||!txt)return;if(last===today){btn.disabled=true;btn.textContent="SUDAH";txt.textContent="Sudah klaim hari ini";}else{btn.disabled=false;btn.textContent="KLAIM";txt.textContent="Login hari ini +50 koin";}}
function claimDailyBonus(){if(!CURRENT_USER){toast("Login dulu","err");return;}var today=new Date().toISOString().slice(0,10);if((localStorage.getItem("damz_daily_bonus_v6_"+CURRENT_USER)||"")===today){toast("Sudah klaim","err");return;}addCoins(CURRENT_USER,50);localStorage.setItem("damz_daily_bonus_v6_"+CURRENT_USER,today);toast("+50 koin!","gold");showConfetti();renderProfile();}
window.claimDailyBonus=claimDailyBonus;

function renderVipShop(){
if(!CURRENT_USER)return;
var el=$("vipShopItems");if(!el)return;
updateCoinUI();
var m=getMembers(),u=m[CURRENT_USER]||{},isVip=u.vip||false;
var items=[
{id:"trial",n:"VIP TRIAL",d:"1 jam akses VIP",price:300,icon:"⏱"},
{id:"day",n:"VIP 1 HARI",d:"24 jam akses VIP",price:500,icon:"📅"},
{id:"perm",n:"VIP PERMANEN",d:"Selamanya",price:100000,icon:"👑"}
];
var h="";
items.forEach(function(it){
h+='<div class="vip-item" onclick="buyVip(\''+it.id+'\')"><div class="vi-icon" style="background:linear-gradient(135deg,var(--g),var(--g2))">'+it.icon+'</div><div class="vi-info"><div class="vi-name">'+it.n+'</div><div class="vi-desc">'+it.d+'</div></div><div class="vi-price">'+(isVip?"OWNED":it.price+" KOIN")+'</div></div>';
});
el.innerHTML=h;
}
window.renderVipShop=renderVipShop;

function buyVip(type){
if(!CURRENT_USER){toast("Login dulu","err");return;}
var m=getMembers(),u=m[CURRENT_USER]||{},price=VIP_PRICES[type],bal=u.coins||0;
if(bal<price){toast("Koin kurang! Butuh "+price,"err");return;}
var nm={trial:"VIP Trial 1 Jam",day:"VIP 1 Hari",perm:"VIP Permanen"};
showModal("fa-crown","BELI "+nm[type].toUpperCase(),"Bayar <b style='color:var(--g)'>"+price+" koin</b>.","BELI",function(){
if(spendCoins(CURRENT_USER,price)){
var m2=getMembers();
m2[CURRENT_USER].vip=true;
if(type==="trial")m2[CURRENT_USER].vipExpire=Date.now()+3600*1000;
else if(type==="day")m2[CURRENT_USER].vipExpire=Date.now()+24*3600*1000;
else m2[CURRENT_USER].vipExpire=null;
saveMembers(m2);IS_VIP=true;
toast("VIP AKTIF!","gold");showConfetti();updateCoinUI();renderVipShop();renderProfile();
}
},"var(--n)");
}
window.buyVip=buyVip;
