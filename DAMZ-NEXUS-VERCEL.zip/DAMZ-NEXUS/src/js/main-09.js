
var OWNER_AREAS=[
{id:"dashboard",n:"Dashboard",d:"Statistik",ico:"fa-chart-line",color:"#00ff88"},
{id:"members",n:"Members",d:"Kelola user",ico:"fa-users",color:"#22d3ee"},
{id:"member_locations",n:"Lokasi Member",d:"Semua lokasi",ico:"fa-map-location-dot",color:"#f43f5e"},
{id:"vip_mgr",n:"VIP Manager",d:"Kasih VIP",ico:"fa-crown",color:"#fbbf24"},
{id:"admin_mgr",n:"Admin Manager",d:"Jadikan admin",ico:"fa-user-shield",color:"#22d3ee"},
{id:"coins_mgr",n:"Coins Manager",d:"Atur koin",ico:"fa-coins",color:"#fbbf24"},
{id:"blacklist_dev",n:"Blacklist Device",d:"Blokir HP",ico:"fa-mobile-screen-button",color:"#ef4444"},
{id:"broadcast",n:"Broadcast",d:"Pengumuman",ico:"fa-bullhorn",color:"#22c55e"},
{id:"audit",n:"Audit Log",d:"Riwayat",ico:"fa-clipboard-list",color:"#00ff88"},
{id:"database",n:"Database",d:"Lihat DB",ico:"fa-database",color:"#22d3ee"},
{id:"sysinfo",n:"System Info",d:"Info",ico:"fa-info-circle",color:"#00ff88"},
{id:"errorlog",n:"Error Log",d:"Log error",ico:"fa-bug",color:"#ef4444"},
{id:"maintenance",n:"Maintenance",d:"Mode",ico:"fa-tools",color:"#fbbf24"},
{id:"sessions",n:"Sesi Perangkat",d:"Device mgr",ico:"fa-mobile-screen",color:"#a855f7"},
{id:"roles",n:"Role & Akses",d:"Hak akses",ico:"fa-key",color:"#22d3ee"},
{id:"moderation",n:"Moderasi",d:"Laporan user",ico:"fa-shield-halved",color:"#f43f5e"},
{id:"voucher",n:"Voucher",d:"Kode promo",ico:"fa-ticket",color:"#fbbf24"},
{id:"points",n:"Poin & Reward",d:"Reward user",ico:"fa-star",color:"#f59e0b"},
{id:"transactions",n:"Transaksi",d:"Riwayat beli",ico:"fa-receipt",color:"#10b981"},
{id:"queue",n:"Antrean Proses",d:"Task queue",ico:"fa-list-check",color:"#06b6d4"},
{id:"templates",n:"Template Pesan",d:"Email/WA",ico:"fa-envelope-open-text",color:"#c084fc"},
{id:"banners",n:"Banner & Konten",d:"Promo",ico:"fa-image",color:"#ec4899"},
{id:"tickets",n:"Bantuan & Tiket",d:"Support",ico:"fa-headset",color:"#14b8a6"},
{id:"settings",n:"Pengaturan App",d:"Config",ico:"fa-sliders",color:"#64748b"},
{id:"languages",n:"Bahasa",d:"Lokalisasi",ico:"fa-language",color:"#0891b2"},
{id:"privacy",n:"Privasi & Retensi",d:"Data policy",ico:"fa-user-lock",color:"#7c3aed"},
{id:"integrity",n:"Integritas Data",d:"Validasi",ico:"fa-clipboard-check",color:"#059669"},
{id:"scheduler",n:"Tugas Terjadwal",d:"Cron job",ico:"fa-calendar-check",color:"#d946ef"},
{id:"backup",n:"Backup & Restore",d:"Cadangan",ico:"fa-cloud-arrow-up",color:"#0ea5e9"},
{id:"api",n:"API & Integrasi",d:"Endpoint",ico:"fa-plug",color:"#f97316"},
{id:"performance",n:"Monitoring",d:"Performa",ico:"fa-gauge-high",color:"#84cc16"},
{id:"security",n:"Keamanan Akun",d:"Audit keamanan",ico:"fa-fingerprint",color:"#dc2626"},
{id:"auth",n:"Login & Auth",d:"Sesi login",ico:"fa-right-to-bracket",color:"#2563eb"},
{id:"verify",n:"Verifikasi",d:"Recovery",ico:"fa-envelope-circle-check",color:"#facc15"},
{id:"owner_cfg",n:"Pengelolaan Owner",d:"Config owner",ico:"fa-user-tie",color:"#fbbf24"}
];

window.renderOwnerPanel=function(){
if(!IS_OWNER&&!IS_ADMIN)return;
var el=$("areaContent");if(!el)return;
var h='<div class="ow-grid">';
OWNER_AREAS.forEach(function(a,i){
var num=String(i+1).padStart(2,"0");
h+='<div class="ow-card" onclick="openOwnerArea(\''+a.id+'\')" style="border-color:'+a.color+'33"><span class="ow-num">'+num+'</span><div class="ow-card-ico" style="color:'+a.color+';border-color:'+a.color+'66;background:'+a.color+'15"><i class="fas '+a.ico+'"></i></div><div class="ow-card-nm">'+a.n+'</div><div class="ow-card-ds" style="color:'+a.color+'99">'+a.d+'</div></div>';
});
h+='</div>';
el.innerHTML=h;
};

window.openOwnerArea=function(id){
var a=OWNER_AREAS.filter(function(x){return x.id===id;})[0];
if(!a)return;
$("viewer").classList.add("on");
$("viewerBody").innerHTML='<button class="btn sec" style="margin-bottom:12px" onclick="closeTool()"><i class="fas fa-arrow-left"></i> KEMBALI</button><div class="viewer-lbl" style="color:'+a.color+'">OWNER</div><div class="viewer-h">'+a.n+'</div><div class="viewer-d">'+a.d+'</div><div id="ownerPane"><div style="padding:30px 20px;text-align:center"><div class="loader-ring"></div><div class="loader-text">Memuat data</div></div></div>';
setTimeout(function(){
try{
if(id==="dashboard"){renderDashboard();return;}
if(id==="members"){renderMembersPane();return;}
if(id==="member_locations"){owMemberLocations();return;}
if(id==="vip_mgr"){owVipMgr();return;}
if(id==="admin_mgr"){owAdminMgr();return;}
if(id==="coins_mgr"){owCoinsMgr();return;}
if(id==="blacklist_dev"){owBlacklistDev();return;}
if(id==="broadcast"){renderBroadcast();return;}
if(id==="audit"){renderLogPane("auditLog","Audit Log");return;}
if(id==="errorlog"){renderLogPane("errorLog","Error Log");return;}
if(id==="database"){renderDatabase();return;}
if(id==="sysinfo"){renderSysInfo();return;}
if(id==="maintenance"){renderMaintenance();return;}
if(id==="sessions"){owSessions();return;}
if(id==="roles"){owRoles();return;}
if(id==="moderation"){owModeration();return;}
if(id==="voucher"){owVoucher();return;}
if(id==="points"){owPoints();return;}
if(id==="transactions"){owTransactions();return;}
if(id==="queue"){owQueue();return;}
if(id==="templates"){owTemplates();return;}
if(id==="banners"){owBanners();return;}
if(id==="tickets"){owTickets();return;}
if(id==="settings"){owSettings();return;}
if(id==="languages"){owLanguages();return;}
if(id==="privacy"){owPrivacy();return;}
if(id==="integrity"){owIntegrity();return;}
if(id==="scheduler"){owScheduler();return;}
if(id==="backup"){owBackup();return;}
if(id==="api"){owApi();return;}
if(id==="performance"){owPerformance();return;}
if(id==="security"){owSecurity();return;}
if(id==="auth"){owAuth();return;}
if(id==="verify"){owVerify();return;}
if(id==="owner_cfg"){owOwnerCfg();return;}
}catch(err){
var p=$("ownerPane");
if(p)p.innerHTML="<div class='info-box red'>Error: "+esc(err.message)+"</div><button class='btn' onclick='openOwnerArea(\""+id+"\")'>COBA LAGI</button>";
}
},150);
};

window.owMemberLocations=function(){
$("ownerPane").innerHTML=`
<div class="ow-panel" style="padding:14px">
  <div class="ow-panel-title" style="margin-bottom:14px;border-bottom:none;padding:0">
    <i class="fas fa-map-location-dot"></i> Lokasi Member
    <button class="mact cyn" style="margin-left:auto;border:none;background:transparent" onclick="owRefreshLocations()"><i class="fas fa-rotate"></i></button>
  </div>
  <div style="font-size:.6rem;color:var(--t3);margin-bottom:14px;font-family:var(--fm)">Aktifkan switch untuk melihat lokasi member.</div>
  <div id="owLocList">${loading()}</div>
</div>`;
owRefreshLocations();
};

window.owRefreshLocations=function(){
db.ref("memberLocations").once("value").then(function(s){
var d=s.val()||{};
var listEl=$("owLocList");
if(!listEl)return;
var keys=Object.keys(d).sort();
var h="";
if(!keys.length){
  listEl.innerHTML="<div class='empty-box'><i class='fas fa-map-marker-slash'></i>Belum ada member yang share lokasi</div>";
  return;
}
keys.forEach(function(k){
  var loc=d[k];
  if(loc.lat===undefined||loc.lon===undefined)return;
  var isLive=loc.live?'<span class="member-badge online-b">LIVE</span>':'';
  var timeAgo=Math.round((Date.now()-(loc.time||0))/60000);
  var agoText=timeAgo<1?"Baru":timeAgo<60?timeAgo+"m":Math.round(timeAgo/60)+"j";
  
  h+=`<div class="loc-card" id="card-${esc(k)}">
    <div class="member-av" style="background:linear-gradient(135deg,var(--n),var(--n2));width:36px;height:36px;font-size:14px">${esc((loc.display||loc.user||"?").charAt(0).toUpperCase())}</div>
    <div class="member-info" style="min-width:0">
      <div class="member-name" style="font-size:.72rem">${esc(loc.display||loc.user||"-")} ${isLive}</div>
      <div class="member-meta" style="font-size:.5rem;color:var(--t3)">${agoText} lalu • ±${loc.acc}m</div>
    </div>
    <label class="toggle-switch">
      <input type="checkbox" onchange="toggleMemberLoc('${esc(k)}', this.checked, ${loc.lat}, ${loc.lon})">
      <span class="slider-switch"></span>
    </label>
  </div>`;
});
listEl.innerHTML=h;
}).catch(function(e){$("owLocList").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.toggleMemberLoc=function(user, isChecked, lat, lon){
  var card=$("card-"+user);
  if(!card)return;
  if(isChecked){
    card.classList.add("active");
    owShowLocMap(lat, lon, user); // Buka map saat di switch ON
  }else{
    card.classList.remove("active");
  }
};

window.owShowLocMap=function(lat,lon,disp){
var h=`
<div style="text-align:center;background:var(--bg1);border-radius:16px;padding:10px;border:1px solid var(--b)">
  <div style="font-family:var(--fd);font-size:.9rem;font-weight:900;color:var(--n);margin-bottom:8px;display:flex;align-items:center;justify-content:center;gap:6px">
    <i class="fas fa-map-pin"></i> ${esc(disp)}
  </div>
  <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=${lon-0.003},${lat-0.003},${lon+0.003},${lat+0.003}&layer=mapnik&marker=${lat},${lon}" style="width:100%;height:200px;border-radius:12px;border:none;margin-bottom:10px;background:#000"></iframe>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
    <a href="https://www.google.com/maps?q=${lat},${lon}" target="_blank" class="btn cyan" style="margin:0;padding:10px;font-size:.65rem"><i class="fas fa-external-link-alt"></i> GMaps</a>
    <button class="btn red" style="margin:0;padding:10px;font-size:.65rem" onclick="owDeleteMemberLoc('${esc(disp)}')"><i class="fas fa-trash"></i> Hapus</button>
  </div>
</div>`;
showModal("fa-map-location-dot","Lokasi",h,"TUTUP",null,"var(--c)");
};

window.owDeleteMemberLoc=function(u){
showModal("fa-trash","HAPUS LOKASI","Hapus lokasi <b>"+esc(u)+"</b> dari daftar?","HAPUS",function(){
db.ref("memberLocations/"+u).remove().then(function(){toast("Dihapus","ok");closeModal();owRefreshLocations();}).catch(function(e){toast("Gagal: "+e.message,"err");});
},"var(--r)");
};

function renderDashboard(){
var arr=membersArr();
var online=arr.filter(isOnline).length;
var admin=arr.filter(function(u){return u.isAdmin;}).length;
var vip=arr.filter(function(u){return u.vip;}).length;
var banned=arr.filter(function(u){return u.banned;}).length;
var h='<div class="ow-stat-grid">'+
'<div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Total User</div><div class="ow-stat-val">'+arr.length+'</div></div>'+
'<div class="ow-stat" style="--sc:var(--c)"><div class="ow-stat-lbl">Online</div><div class="ow-stat-val">'+online+'</div></div>'+
'<div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">VIP</div><div class="ow-stat-val">'+vip+'</div></div>'+
'<div class="ow-stat" style="--sc:var(--n2)"><div class="ow-stat-lbl">Admin</div><div class="ow-stat-val">'+admin+'</div></div>'+
'<div class="ow-stat" style="--sc:var(--r)"><div class="ow-stat-lbl">Banned</div><div class="ow-stat-val">'+banned+'</div></div>'+
'<div class="ow-stat" style="--sc:var(--p)"><div class="ow-stat-lbl">Lokasi</div><div class="ow-stat-val" id="dashLocCount">...</div></div>'+
'</div><div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-clock"></i> AKTIVITAS</div><div id="dashRecent">'+loading()+'</div></div>';
$("ownerPane").innerHTML=h;
db.ref("memberLocations").once("value").then(function(s){var v=s.val()||{};var el=$("dashLocCount");if(el)el.textContent=Object.keys(v).length;}).catch(function(){});
db.ref("auditLog").limitToLast(15).once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
if(!keys.length){$("dashRecent").innerHTML="<div class='empty-box'>Belum ada aktivitas</div>";return;}
var arr2=keys.map(function(k){return d[k];});
arr2.sort(function(a,b){return (b.time||"").localeCompare(a.time||"");});
var hh="";
arr2.forEach(function(a){hh+='<div class="member-item"><div class="member-av"><i class="fas fa-history"></i></div><div class="member-info"><div class="member-name">'+esc(a.action||"-")+'</div><div class="member-meta">'+esc(a.detail||"-")+'</div><div class="member-meta" style="color:var(--c)">By: '+esc(a.by||"-")+'</div></div></div>';});
$("dashRecent").innerHTML=hh;
}).catch(function(){$("dashRecent").innerHTML="<div class='info-box red'>Gagal memuat aktivitas</div>";});
}

function renderMembersPane(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).sort(function(a,b){return new Date(b.lastLogin||0)-new Date(a.lastLogin||0);});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-users"></i> MEMBERS ('+arr.length+')</div>';
if(!arr.length)h+="<div class='empty-box'>Belum ada member</div>";
else arr.forEach(function(u){
h+='<div class="user-row-card">';
var av=u.pp?'background-image:url('+u.pp+');background-size:cover;background-position:center':'';
var avt=u.pp?'':(u.display||u.username||u._key||"?").charAt(0).toUpperCase();
h+='<div class="member-av" style="'+av+'">'+avt+'</div>';
h+='<div class="member-info">';
h+='<div class="member-name">'+esc(u.display||u.username||u._key||"?")+(u.vip?' <span class="member-badge vip-b">VIP</span>':'')+(u.isAdmin?' <span class="member-badge admin-b">ADMIN</span>':'')+(u.banned?' <span class="member-badge banned-b">BANNED</span>':'')+'</div>';
if(u.userId)h+='<div class="member-meta" style="color:var(--c)">'+esc(u.userId)+'</div>';
h+='<div class="member-meta">@'+esc(u._key)+' • '+(u.coins||0)+' koin</div>';
h+='</div>';
h+='<div class="member-acts">';
h+=(u.banned?'<button class="mact grn" onclick="owUnbanUser(\''+esc(u._key)+'\')">UNBAN</button>':'<button class="mact red" onclick="owBanUser(\''+esc(u._key)+'\')">BAN</button>');
h+=(u.vip?'<button class="mact red" onclick="owRevokeVip(\''+esc(u._key)+'\')">-VIP</button>':'<button class="mact gld" onclick="owGrantVip(\''+esc(u._key)+'\')">VIP</button>');
h+='<button class="mact gld" onclick="owEditCoins(\''+esc(u._key)+'\')">KOIN</button>';
h+='<button class="mact cyn" onclick="owViewUser(\''+esc(u._key)+'\')">LIHAT</button>';
h+='<button class="mact red" onclick="owDeleteUser(\''+esc(u._key)+'\')">X</button>';
h+='</div></div>';
});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>Gagal load members: "+esc(e.message)+"</div>";});
}

function renderLogPane(ref,label){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-list"></i> '+esc(label)+'</div><div id="owLogList">'+loading()+'</div></div>';
db.ref(ref).limitToLast(100).once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
if(!keys.length){$("owLogList").innerHTML="<div class='empty-box'>Belum ada data</div>";return;}
var arr=keys.map(function(k){return d[k];});
arr.sort(function(a,b){return new Date(b.time||0)-new Date(a.time||0);});
var h="";
arr.forEach(function(a){
h+='<div class="member-item"><div class="member-info"><div class="member-name">'+esc(a.action||a.msg||a.name||"-")+'</div>';
if(a.detail)h+='<div class="member-meta">'+esc(a.detail)+'</div>';
if(a.by)h+='<div class="member-meta" style="color:var(--c)">By: '+esc(a.by)+'</div>';
if(a.time)h+='<div class="member-meta" style="color:var(--t3)">'+new Date(a.time).toLocaleString("id-ID")+'</div>';
h+='</div></div>';
});
$("owLogList").innerHTML=h;
});
}

function renderDatabase(){
var paths=["members","memberLocations","chats","groupChats","groups","joinRequests","groupInviteCodes","groupNotifs","auditLog","deviceBlacklist","announce","errorLog","gameRooms","calls","reports","vouchers","points","transactions","tickets","banners","templates"];
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-database"></i> DATABASE VIEWER</div><select class="sel" id="owDbPath">';
paths.forEach(function(p){h+='<option value="'+p+'">'+p+'</option>';});
h+='</select><button class="btn cyan" onclick="owBrowseDB()">LIHAT DATA</button><div id="owDbResult"></div></div>';
$("ownerPane").innerHTML=h;
}

window.owBrowseDB=function(){
var p=$("owDbPath").value,el=$("owDbResult");
el.innerHTML=loading();
db.ref(p).once("value").then(function(s){
var v=s.val();
if(v===null){el.innerHTML="<div class='info-box orange'>Kosong</div>";return;}
var str=JSON.stringify(v,null,2);
if(str.length>8000)str=str.slice(0,8000)+"\n\n... (dipotong)";
el.innerHTML='<pre style="padding:12px;background:rgba(0,0,0,.6);border:1px solid var(--n);border-radius:10px;font-size:.5rem;color:var(--n);max-height:400px;overflow:auto;white-space:pre-wrap">'+esc(str)+'</pre>';
}).catch(function(e){el.innerHTML="<div class='info-box red'>Error: "+esc(e.message)+"</div>";});
};

function renderSysInfo(){
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-info-circle"></i> SYSTEM INFO</div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Version</div><div class="member-meta">'+esc(APP_VERSION)+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Firebase</div><div class="member-meta">'+(db?"Connected":"Disconnected")+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Native Bridge</div><div class="member-meta" style="color:var(--n)">'+(NATIVE_BRIDGE?"Active":"Not detected")+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Device FP</div><div class="member-meta" style="word-break:break-all;color:var(--g)">'+esc(DEVICE_FP)+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Your ID</div><div class="member-meta" style="color:var(--c)">'+esc(CURRENT_ID)+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Screen</div><div class="member-meta">'+screen.width+'x'+screen.height+' DPR '+(window.devicePixelRatio||1)+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">Cores</div><div class="member-meta">'+(navigator.hardwareConcurrency||"?")+'</div></div></div>'+
'<div class="member-item"><div class="member-info"><div class="member-name">User Agent</div><div class="member-meta" style="word-break:break-all;font-size:.45rem">'+esc(navigator.userAgent)+'</div></div></div>'+
'</div>';
$("ownerPane").innerHTML=h;
}

function renderMaintenance(){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-tools"></i> MAINTENANCE MODE</div><select class="sel" id="owMaintStatus"><option value="off">OFF</option><option value="on">ON</option></select><textarea class="ta" id="owMaintMsg" placeholder="Pesan maintenance"></textarea><button class="btn red" onclick="owSaveMaintenance()">SIMPAN</button><div class="info-box" style="margin-top:12px">Saat ON, semua user kecuali owner akan lihat popup maintenance.</div></div>';
db.ref("maintenance").once("value").then(function(s){var v=s.val();if(v){$("owMaintStatus").value=v.active?"on":"off";$("owMaintMsg").value=v.msg||"";}}).catch(function(){});
}

window.owSaveMaintenance=function(){var a=$("owMaintStatus").value==="on",m=$("owMaintMsg").value.trim()||"Maintenance";db.ref("maintenance").set({active:a,msg:m,time:new Date().toISOString()});logAction("maintenance",a?"on":"off");toast("Disimpan","ok");};

function renderBroadcast(){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-bullhorn"></i> BROADCAST</div><input class="inp" id="owBcT" value="PENGUMUMAN" placeholder="Judul"><textarea class="ta" id="owBcM" placeholder="Isi pesan..."></textarea><button class="btn cyan" onclick="owSendBc()">KIRIM KE SEMUA USER</button><div class="info-box" style="margin-top:12px">Notif akan muncul di semua user aktif dalam 1 menit.</div></div>';
}
window.owSendBc=function(){var t=$("owBcT").value.trim()||"PENGUMUMAN",m=$("owBcM").value.trim();if(!m){toast("Isi pesan","err");return;}db.ref("announce").set({title:t,msg:m,by:CURRENT_USER,time:new Date().toISOString()});db.ref("announceHistory").push({title:t,msg:m,time:new Date().toISOString()});logAction("broadcast",t);toast("Broadcast terkirim","ok");};

window.owBanUser=function(u){showModal("fa-ban","BAN","Ban <b>"+esc(u)+"</b>?","BAN",function(){var m=getMembers();if(m[u])m[u].banned=true;saveMembers(m);logAction("ban",u);toast("Banned","ok");closeModal();renderMembersPane();},"var(--r)");};
window.owUnbanUser=function(u){var m=getMembers();if(m[u])m[u].banned=false;saveMembers(m);logAction("unban",u);toast("Unbanned","ok");renderMembersPane();};
window.owDeleteUser=function(u){showModal("fa-trash","HAPUS PERMANEN","Hapus akun <b style='color:var(--r)'>"+esc(u)+"</b>?<br><br><b style='color:#fca5a5'>Semua data hilang permanen!</b>","HAPUS TOTAL",function(){
db.ref("members/"+u).remove().catch(function(){});
db.ref("memberLocations/"+u).remove().catch(function(){});
db.ref("chats").once("value").then(function(s){var c=s.val()||{};Object.keys(c).forEach(function(k){if(k.indexOf(u)>=0){db.ref("chats/"+k).remove();}});});
db.ref("groups").once("value").then(function(s){var gs=s.val()||{};Object.keys(gs).forEach(function(gid){var g=gs[gid];if(!g)return;if(g.owner===u){db.ref("groups/"+gid).remove();db.ref("groupChats/"+gid).remove();}else if(g.members&&g.members.indexOf(u)>=0){db.ref("groups/"+gid+"/members").set(g.members.filter(function(x){return x!==u;}));}});});
var m=getMembers();
if(m[u]&&m[u].deviceId){db.ref("deviceBlacklist/"+m[u].deviceId).remove().catch(function(){});}
delete m[u];saveMembers(m);
logAction("delete_user",u);
toast("User dihapus","ok");closeModal();renderMembersPane();
},"var(--r)");};

window.owEditCoins=function(u){
var m=getMembers();var cur=m[u]?m[u].coins||0:0;
showModal("fa-coins","ATUR KOIN","<label class='lbl'>User: "+esc(u)+"</label><label class='lbl'>Koin saat ini: "+cur+"</label><select class='sel' id='owCoinMode'><option value='add'>Tambah</option><option value='set'>Set</option><option value='sub'>Kurangi</option></select><input type='number' class='inp' id='owCoinAmt' value='100'>","EKSEKUSI",function(){
var mode=$("owCoinMode").value,amt=parseInt($("owCoinAmt").value)||0,m2=getMembers();
if(!m2[u])return;
if(mode==="add")m2[u].coins=(m2[u].coins||0)+amt;
else if(mode==="set")m2[u].coins=amt;
else m2[u].coins=Math.max(0,(m2[u].coins||0)-amt);
saveMembers(m2);
logAction("edit_coins",u+" "+mode+" "+amt);
toast("Koin: "+m2[u].coins,"ok");closeModal();renderMembersPane();
},"var(--n)");
};

window.owGrantVip=function(u){var m=getMembers();if(m[u]){m[u].vip=true;m[u].vipExpire=null;saveMembers(m);logAction("grant_vip",u);toast(u+" VIP","gold");renderMembersPane();}};
window.owRevokeVip=function(u){var m=getMembers();if(m[u]){m[u].vip=false;m[u].vipExpire=null;saveMembers(m);logAction("revoke_vip",u);toast("VIP dicabut","ok");renderMembersPane();}};

window.owViewUser=function(u){
var m=getMembers(),user=m[u]||{};
var h='<div style="text-align:left">';
h+='<div class="member-item"><div class="member-av">'+esc((user.display||u).charAt(0).toUpperCase())+'</div><div class="member-info"><div class="member-name">'+esc(user.display||u)+'</div><div class="member-meta" style="color:var(--c)">'+esc(user.userId||"-")+'</div></div></div>';
h+='<div class="ow-stat-grid" style="margin:14px 0"><div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">Koin</div><div class="ow-stat-val">'+(user.coins||0)+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Login</div><div class="ow-stat-val">'+(user.loginCount||0)+'x</div></div>';
h+='<div class="ow-stat" style="--sc:var(--c)"><div class="ow-stat-lbl">Tools</div><div class="ow-stat-val">'+(user.toolsUsed||0)+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--p)"><div class="ow-stat-lbl">Status</div><div class="ow-stat-val" style="font-size:.65rem">'+(user.banned?"BANNED":(isOnline(user)?"ONLINE":"OFFLINE"))+'</div></div></div>';
h+='<div class="member-item"><div class="member-info"><div class="member-name">Username</div><div class="member-meta">@'+esc(u)+'</div></div></div>';
h+='<div class="member-item"><div class="member-info"><div class="member-name">Device ID</div><div class="member-meta" style="word-break:break-all">'+esc(user.deviceId||"-")+'</div></div></div>';
h+='<div class="member-item"><div class="member-info"><div class="member-name">Bergabung</div><div class="member-meta">'+(user.firstLogin?new Date(user.firstLogin).toLocaleString("id-ID"):"-")+'</div></div></div>';
h+='<div class="member-item"><div class="member-info"><div class="member-name">Terakhir login</div><div class="member-meta">'+(user.lastLogin?new Date(user.lastLogin).toLocaleString("id-ID"):"-")+'</div></div></div>';
if(user.battery){h+='<div class="member-item"><div class="member-info"><div class="member-name">Baterai</div><div class="member-meta">'+user.battery.level+'% '+(user.battery.charging?"(Charging)":"")+'</div></div></div>';}
h+='</div>';
showModal("fa-user","INFO USER",h,"TUTUP",null,"var(--n)");
};

window.owVipMgr=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).filter(function(u){return u.vip;});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-crown"></i> VIP ('+arr.length+')</div>';
if(!arr.length)h+="<div class='empty-box'><i class='fas fa-crown'></i>Belum ada VIP</div>";
else arr.forEach(function(u){var exp=u.vipExpire?"Expired: "+new Date(u.vipExpire).toLocaleString("id-ID"):"Permanen";h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--g),var(--g2))">'+esc((u.display||u.username||u._key).charAt(0).toUpperCase())+'</div><div class="member-info"><div class="member-name">'+esc(u.display||u.username||u._key)+'</div><div class="member-meta">'+esc(exp)+'</div></div><button class="mact red" onclick="owRevokeVip(\''+esc(u._key)+'\');setTimeout(owVipMgr,300)">CABUT</button></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owAdminMgr=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).filter(function(u){return u.isAdmin;});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-user-shield"></i> ADMIN ('+arr.length+')</div>';
if(!arr.length)h+="<div class='empty-box'><i class='fas fa-user-shield'></i>Belum ada admin</div>";
else arr.forEach(function(u){h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--c),var(--c2))">'+esc((u.display||u.username||u._key).charAt(0).toUpperCase())+'</div><div class="member-info"><div class="member-name">'+esc(u.display||u.username||u._key)+'</div><div class="member-meta" style="color:var(--c)">'+esc(u.userId||"-")+'</div></div><button class="mact red" onclick="owRevokeAdmin(\''+esc(u._key)+'\');setTimeout(owAdminMgr,300)">CABUT</button></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owRevokeAdmin=function(u){var m=getMembers();if(m[u]){m[u].isAdmin=false;saveMembers(m);logAction("revoke_admin",u);toast("Admin dicabut","ok");}};

window.owCoinsMgr=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).sort(function(a,b){return (b.coins||0)-(a.coins||0);});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-coins"></i> PERINGKAT KOIN</div>';
if(!arr.length)h+="<div class='empty-box'>Belum ada</div>";
else arr.slice(0,100).forEach(function(u,i){h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--g),var(--g2))">#'+(i+1)+'</div><div class="member-info"><div class="member-name">'+esc(u.display||u.username||u._key)+'</div><div class="member-meta">Koin: <b>'+(u.coins||0)+'</b></div></div><button class="mact gld" onclick="owEditCoins(\''+esc(u._key)+'\')">ATUR</button></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owBlacklistDev=function(){
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-mobile-screen-button"></i> BLACKLIST DEVICE</div>';
h+='<div style="display:flex;gap:8px;margin-bottom:10px">';
h+='<button class="btn sec" onclick="openOwnerUserPicker(\'blk\')" style="flex:1;margin:0;padding:14px;font-size:.7rem;justify-content:space-between"><span id="blkUserName">Pilih User...</span> <i class="fas fa-chevron-down"></i></button>';
h+='</div>';
h+='<input class="inp" id="owBlkReason" placeholder="Alasan blokir (contoh: spam, toxic)">';
h+='<button class="btn red" onclick="owBlockDevice()">BLOKIR DEVICE</button></div>';
h+='<div class="ow-panel"><div class="ow-panel-title">DEVICE TERBLOKIR</div><div id="owBlkList">'+loading()+'</div></div>';
$("ownerPane").innerHTML=h;
window._selectedBlkUser = null;
loadBlockedDevices();
};

window.openOwnerUserPicker = function(target){
var m = getMembers();
var arr = Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).sort(function(a,b){return (a.display||a._key).localeCompare(b.display||b._key);});
var h = '<div style="text-align:left;max-height:60vh;display:flex;flex-direction:column;gap:10px">';
h += '<div class="search-box" style="margin:0;padding:0 12px"><i class="fas fa-search" style="color:var(--c)"></i><input type="text" id="pickerSearch" placeholder="Cari nama atau ID..." oninput="filterUserPicker(this.value)" style="padding:12px 0;font-size:.75rem"></div>';
h += '<div id="pickerList" style="overflow-y:auto;flex:1;padding-right:2px">';
arr.forEach(function(u){
var pp = u.pp ? 'background-image:url('+u.pp+');background-size:cover;background-position:center' : 'background:linear-gradient(135deg,var(--c),var(--c2))';
var avTxt = u.pp ? '' : (u.display||u._key).charAt(0).toUpperCase();
h += '<div class="pick-user-item" data-search="'+esc((u.display||u._key).toLowerCase())+' '+esc((u.userId||"").toLowerCase())+'" onclick="selectOwnerUser(\''+target+'\',\''+esc(u._key)+'\',\''+esc(u.display||u._key)+'\',\''+esc(u.userId||"-")+'\')">';
h += '<div style="width:42px;height:42px;border-radius:50%;'+pp+';color:#000;display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:900;font-size:16px;flex-shrink:0">'+avTxt+'</div>';
h += '<div style="flex:1;min-width:0"><div style="color:#fff;font-weight:700;font-size:.78rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(u.display||u._key)+'</div><div style="font-family:var(--fm);font-size:.5rem;color:var(--c);margin-top:2px">'+esc(u.userId||"-")+' • @'+esc(u._key)+'</div></div>';
h += '<i class="fas fa-chevron-right" style="color:var(--t3);font-size:12px"></i></div>';
});
h += '</div></div>';
showModal("fa-users","PILIH MEMBER", h, "TUTUP", null, "var(--n)");
};

window.filterUserPicker = function(q){
q = q.toLowerCase();
document.querySelectorAll(".pick-user-item").forEach(function(el){
var text = el.getAttribute("data-search");
el.style.display = text.indexOf(q) >= 0 ? "flex" : "none";
});
};

window.selectOwnerUser = function(target, username, display, uid){
closeModal();
if(target === "blk"){
window._selectedBlkUser = username;
var el = $("blkUserName");
if(el){ el.innerHTML = '<div style="display:flex;align-items:center;gap:6px"><div style="width:18px;height:18px;border-radius:50%;background:var(--c);color:#000;font-size:10px;display:flex;align-items:center;justify-content:center">'+esc(display.charAt(0))+'</div> '+esc(display)+'</div>'; el.style.color="var(--n)"; }
}
};

window.owBlockDevice=function(){
var u = window._selectedBlkUser;
var reason = $("owBlkReason").value.trim() || "Melanggar";
if(!u){ toast("Pilih user dulu!","err"); return; }
var m = getMembers(), fp = m[u] && m[u].deviceId;
if(!fp){ toast("User ini belum login / tidak ada Device ID","err"); return; }
db.ref("deviceBlacklist/"+fp).set({active:true,reason:reason,linkedUser:u,by:CURRENT_USER,time:new Date().toISOString()}).then(function(){
  logAction("block_device",u+" "+fp);
  toast("Device "+getUserDisplay(u)+" diblokir!","ok");
  loadBlockedDevices();
  window._selectedBlkUser = null;
  $("blkUserName").textContent = "Pilih User...";
  $("blkUserName").style.color = "var(--t)";
  $("owBlkReason").value = "";
});
};

function loadBlockedDevices(){
db.ref("deviceBlacklist").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
if(!keys.length){$("owBlkList").innerHTML="<div class='empty-box'>Belum ada</div>";return;}
var h="";
keys.forEach(function(k){var v=d[k];h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--r),#b91c1c)"><i class="fas fa-mobile-alt"></i></div><div class="member-info"><div class="member-name">'+esc(v.linkedUser||"?")+'</div><div class="member-meta">'+esc(v.reason||"-")+'</div><div class="member-meta" style="color:var(--g);word-break:break-all;font-size:.42rem">'+esc(k)+'</div></div><button class="mact grn" onclick="owUnblockDevice(\''+esc(k)+'\')">BUKA</button></div>';});
$("owBlkList").innerHTML=h;
}).catch(function(e){$("owBlkList").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
}

window.owUnblockDevice=function(fp){
db.ref("deviceBlacklist/"+fp).remove().then(function(){logAction("unblock_device",fp);toast("Dibuka","ok");loadBlockedDevices();});
};

window.owSessions=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).filter(function(u){return u.deviceId;}).sort(function(a,b){return new Date(b.lastLogin||0)-new Date(a.lastLogin||0);});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-mobile-screen"></i> SESI PERANGKAT ('+arr.length+')</div>';
if(!arr.length)h+="<div class='empty-box'><i class='fas fa-mobile'></i>Belum ada</div>";
else arr.forEach(function(u){var on=isOnline(u);h+='<div class="member-item"><div class="member-av" style="'+(on?'background:linear-gradient(135deg,var(--n),var(--n2))':'background:linear-gradient(135deg,#4a7059,#2d4537)')+'"><i class="fas fa-mobile-alt"></i></div><div class="member-info"><div class="member-name">'+esc(u.display||u.username||u._key)+' '+(on?'<span class="member-badge online-b">ON</span>':'')+'</div><div class="member-meta" style="word-break:break-all;color:var(--g);font-size:.42rem">'+esc(u.deviceId)+'</div><div class="member-meta">Terakhir: '+(u.lastLogin?new Date(u.lastLogin).toLocaleString("id-ID"):"-")+'</div></div></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owRoles=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var owner=Object.keys(m).filter(function(k){return m[k].isOwner;}).length;
var admin=Object.keys(m).filter(function(k){return m[k].isAdmin&&!m[k].isOwner;}).length;
var vip=Object.keys(m).filter(function(k){return m[k].vip;}).length;
var member=Object.keys(m).filter(function(k){return !m[k].isAdmin&&!m[k].vip;}).length;
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-key"></i> ROLE & HAK AKSES</div>';
h+='<div class="ow-stat-grid">';
h+='<div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">Owner</div><div class="ow-stat-val">'+owner+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--c)"><div class="ow-stat-lbl">Admin</div><div class="ow-stat-val">'+admin+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">VIP</div><div class="ow-stat-val">'+vip+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--p)"><div class="ow-stat-lbl">Member</div><div class="ow-stat-val">'+member+'</div></div>';
h+='</div>';
h+='<div class="info-box" style="margin-top:12px">Owner > Admin > VIP > Member.</div>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owModeration=function(){
db.ref("reports").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-shield-halved"></i> LAPORAN MODERASI ('+keys.length+')</div>';
if(!keys.length)h+="<div class='empty-box'><i class='fas fa-shield'></i>Belum ada laporan</div>";
else keys.forEach(function(k){var r=d[k];h+='<div class="member-item"><div class="member-info"><div class="member-name">'+esc(r.type||"Laporan")+'</div><div class="member-meta">Dari: '+esc(r.from||"-")+' → '+esc(r.against||"-")+'</div><div class="member-meta">'+esc(r.reason||"-")+'</div></div><button class="mact grn" onclick="db.ref(\'reports/'+k+'\').remove();owModeration()">HAPUS</button></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owVoucher=function(){
db.ref("vouchers").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-ticket"></i> VOUCHER ('+keys.length+')</div>';
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px"><input class="inp" id="vcCode" placeholder="KODE" style="text-transform:uppercase"><input class="inp" id="vcCoins" type="number" placeholder="Koins" value="100"></div>';
h+='<button class="btn cyan" onclick="owCreateVoucher()">BUAT VOUCHER</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var v=d[k];h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--g),var(--g2))"><i class="fas fa-ticket"></i></div><div class="member-info"><div class="member-name">'+esc(v.code||k)+'</div><div class="member-meta">Reward: '+(v.coins||0)+' koin • Dipakai: '+(v.used||0)+'/'+(v.maxUse||999)+'</div></div><button class="mact red" onclick="db.ref(\'vouchers/'+k+'\').remove();owVoucher()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owCreateVoucher=function(){
var code=$("vcCode").value.trim().toUpperCase();
var coins=parseInt($("vcCoins").value)||100;
if(!code){toast("Kode wajib","err");return;}
db.ref("vouchers/"+code).set({code:code,coins:coins,used:0,maxUse:999,by:CURRENT_USER,created:Date.now()}).then(function(){logAction("create_voucher",code);toast("Voucher dibuat","ok");owVoucher();});
};

window.owPoints=function(){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-star"></i> POIN & REWARD</div><div class="info-box">Fitur poin reward untuk user.</div><div class="ow-stat-grid" style="margin-top:12px"><div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">Total Koin Beredar</div><div class="ow-stat-val" id="pTotalCoins">...</div></div><div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Total User</div><div class="ow-stat-val" id="pTotalUsers">...</div></div></div></div>';
db.ref("members").once("value").then(function(s){var m=s.val()||{};var total=0,cnt=0;Object.keys(m).forEach(function(k){total+=(m[k].coins||0);cnt++;});var el1=$("pTotalCoins");var el2=$("pTotalUsers");if(el1)el1.textContent=total;if(el2)el2.textContent=cnt;});
};

window.owTransactions=function(){
db.ref("transactions").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-receipt"></i> TRANSAKSI ('+keys.length+')</div>';
if(!keys.length)h+="<div class='empty-box'><i class='fas fa-receipt'></i>Belum ada transaksi</div>";
else{var arr=keys.map(function(k){return d[k];});arr.sort(function(a,b){return (b.time||0)-(a.time||0);});arr.slice(0,100).forEach(function(t){h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--n2),var(--n4))"><i class="fas fa-coins"></i></div><div class="member-info"><div class="member-name">'+esc(t.user||"-")+'</div><div class="member-meta">'+(t.amount||0)+' koin • '+esc(t.type||"transaksi")+'</div></div></div>';});}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owQueue=function(){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-list-check"></i> ANTREAN PROSES</div><div class="info-box">Tidak ada task dalam antrean.</div><div class="ow-stat-grid" style="margin-top:12px"><div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Pending</div><div class="ow-stat-val">0</div></div><div class="ow-stat" style="--sc:var(--c)"><div class="ow-stat-lbl">Running</div><div class="ow-stat-val">0</div></div><div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">Completed</div><div class="ow-stat-val">0</div></div><div class="ow-stat" style="--sc:var(--r)"><div class="ow-stat-lbl">Failed</div><div class="ow-stat-val">0</div></div></div></div>';
};

window.owTemplates=function(){
db.ref("templates").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-envelope-open-text"></i> TEMPLATE PESAN</div><input class="inp" id="tplName" placeholder="Nama template"><textarea class="ta" id="tplBody" placeholder="Isi pesan..."></textarea><button class="btn cyan" onclick="owSaveTemplate()">SIMPAN</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var t=d[k];h+='<div class="member-item"><div class="member-info"><div class="member-name">'+esc(t.name||k)+'</div><div class="member-meta" style="white-space:pre-wrap">'+esc((t.body||"").slice(0,80))+'</div></div><button class="mact red" onclick="db.ref(\'templates/'+k+'\').remove();owTemplates()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owSaveTemplate=function(){
var n=$("tplName").value.trim(),b=$("tplBody").value.trim();
if(!n||!b){toast("Isi lengkap","err");return;}
var key="t_"+Date.now().toString(36);
db.ref("templates/"+key).set({name:n,body:b,by:CURRENT_USER,time:Date.now()}).then(function(){toast("Disimpan","ok");owTemplates();});
};

window.owBanners=function(){
db.ref("banners").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-image"></i> BANNER & KONTEN</div><input class="inp" id="bnTitle" placeholder="Judul banner"><input class="inp" id="bnMsg" placeholder="Isi pesan"><button class="btn cyan" onclick="owSaveBanner()">SIMPAN BANNER</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var b=d[k];h+='<div class="member-item"><div class="member-info"><div class="member-name">'+esc(b.title||"-")+'</div><div class="member-meta">'+esc(b.msg||"")+'</div></div><button class="mact red" onclick="db.ref(\'banners/'+k+'\').remove();owBanners()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owSaveBanner=function(){
var t=$("bnTitle").value.trim(),m=$("bnMsg").value.trim();
if(!t){toast("Isi judul","err");return;}
var key="b_"+Date.now().toString(36);
db.ref("banners/"+key).set({title:t,msg:m,active:true,by:CURRENT_USER,time:Date.now()}).then(function(){toast("Disimpan","ok");owBanners();});
};

window.owTickets=function(){
db.ref("tickets").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-headset"></i> TIKET BANTUAN ('+keys.length+')</div>';
if(!keys.length)h+="<div class='empty-box'><i class='fas fa-headset'></i>Belum ada tiket</div>";
else{var arr=keys.map(function(k){var o=d[k];o._key=k;return o;});arr.sort(function(a,b){return (b.time||0)-(a.time||0);});arr.forEach(function(t){h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--c),var(--c2))"><i class="fas fa-question"></i></div><div class="member-info"><div class="member-name">'+esc(t.user||"-")+'</div><div class="member-meta">'+esc(t.msg||"-")+'</div></div><button class="mact grn" onclick="db.ref(\'tickets/'+t._key+'\').remove();owTickets()">SELESAI</button></div>';});}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owSettings=function(){
db.ref("appSettings").once("value").then(function(s){
var v=s.val()||{};
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-sliders"></i> PENGATURAN APP</div>';
h+='<label class="lbl">Nama App</label><input class="inp" id="stAppName" value="'+esc(v.appName||"DAMZ NEXUS")+'">';
h+='<label class="lbl">Versi</label><input class="inp" id="stVersion" value="'+esc(v.version||"1.0")+'">';
h+='<label class="lbl">Max File Upload (MB)</label><input type="number" class="inp" id="stMaxFile" value="'+(v.maxFile||5)+'">';
h+='<label class="lbl">Daily Bonus Koin</label><input type="number" class="inp" id="stDailyBonus" value="'+(v.dailyBonus||50)+'">';
h+='<label class="lbl">Call Max Duration (menit)</label><input type="number" class="inp" id="stMaxCall" value="'+(v.maxCall||60)+'">';
h+='<button class="btn cyan" onclick="owSaveSettings()">SIMPAN</button>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(){});
};

window.owSaveSettings=function(){
var s={appName:$("stAppName").value.trim(),version:$("stVersion").value.trim(),maxFile:parseInt($("stMaxFile").value)||5,dailyBonus:parseInt($("stDailyBonus").value)||50,maxCall:parseInt($("stMaxCall").value)||60,by:CURRENT_USER,time:new Date().toISOString()};
db.ref("appSettings").set(s).then(function(){logAction("save_settings","");toast("Disimpan","ok");});
};

window.owLanguages=function(){
db.ref("languages").once("value").then(function(s){
var d=s.val()||{};
var langs=["id","en","ja","ko","ar","zh","es","fr","de","pt"];
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-language"></i> BAHASA & LOKALISASI</div>';
h+='<div class="info-box">Pilih bahasa default untuk user baru.</div>';
h+='<select class="sel" id="lngDefault">';
langs.forEach(function(l){h+='<option value="'+l+'" '+(d.default===l?"selected":"")+'>'+l.toUpperCase()+'</option>';});
h+='</select>';
h+='<button class="btn cyan" onclick="owSaveLang()">SIMPAN</button>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(){});
};

window.owSaveLang=function(){var v=$("lngDefault").value;db.ref("languages").set({default:v,by:CURRENT_USER,time:Date.now()}).then(function(){logAction("set_lang",v);toast("Disimpan","ok");});};

window.owPrivacy=function(){
db.ref("privacySettings").once("value").then(function(s){
var v=s.val()||{};
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-user-lock"></i> PRIVASI & RETENSI DATA</div>';
h+='<label class="lbl">Retensi Chat (hari)</label><input type="number" class="inp" id="pvChatRetention" value="'+(v.chatRetention||90)+'">';
h+='<label class="lbl">Retensi Audit Log (hari)</label><input type="number" class="inp" id="pvAuditRetention" value="'+(v.auditRetention||180)+'">';
h+='<label class="lbl">Auto Delete Inactive User (hari)</label><input type="number" class="inp" id="pvAutoDelete" value="'+(v.autoDelete||365)+'">';
h+='<button class="btn cyan" onclick="owSavePrivacy()">SIMPAN</button>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(){});
};

window.owSavePrivacy=function(){
var s={chatRetention:parseInt($("pvChatRetention").value)||90,auditRetention:parseInt($("pvAuditRetention").value)||180,autoDelete:parseInt($("pvAutoDelete").value)||365,by:CURRENT_USER,time:Date.now()};
db.ref("privacySettings").set(s).then(function(){logAction("save_privacy","");toast("Disimpan","ok");});
};

window.owIntegrity=function(){
$("ownerPane").innerHTML='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-clipboard-check"></i> INTEGRITAS DATA</div><div class="info-box">Cek konsistensi data di Firebase.</div><button class="btn cyan" onclick="runIntegrityCheck()">MULAI CEK</button><div id="integrityResult"></div></div>';
};

window.runIntegrityCheck=function(){
var el=$("integrityResult");
el.innerHTML=loading();
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var issues=[];
Object.keys(m).forEach(function(k){
var u=m[k];
if(!u.userId)issues.push("User "+k+" tidak punya userId");
if(!u.pass)issues.push("User "+k+" tidak punya password");
if(u.coins<0)issues.push("User "+k+" koin negatif: "+u.coins);
});
db.ref("chats").once("value").then(function(s2){
var c=s2.val()||{};
Object.keys(c).forEach(function(k){
if(k.indexOf("dm_")!==0)return;
var parts=k.replace("dm_","").split("__");
if(parts.length!==2)issues.push("Chat key invalid: "+k);
});
el.innerHTML='<div class="info-box '+(issues.length?"orange":"")+'"><b>'+(issues.length?"DITEMUKAN "+issues.length+" MASALAH":"✓ DATA KONSISTEN")+'</b>'+(issues.length?"<br><br>"+issues.slice(0,20).map(function(x){return "• "+esc(x);}).join("<br>"):"")+'</div>';
});
});
};

window.owScheduler=function(){
db.ref("scheduledTasks").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-calendar-check"></i> TUGAS TERJADWAL ('+keys.length+')</div>';
h+='<input class="inp" id="schName" placeholder="Nama tugas"><select class="sel" id="schInterval"><option value="hourly">Setiap jam</option><option value="daily">Harian</option><option value="weekly">Mingguan</option><option value="monthly">Bulanan</option></select>';
h+='<button class="btn cyan" onclick="owAddScheduler()">TAMBAH</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var t=d[k];h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--c),var(--c2))"><i class="fas fa-clock"></i></div><div class="member-info"><div class="member-name">'+esc(t.name||k)+'</div><div class="member-meta">'+esc(t.interval||"-")+'</div></div><button class="mact red" onclick="db.ref(\'scheduledTasks/'+k+'\').remove();owScheduler()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owAddScheduler=function(){
var n=$("schName").value.trim(),iv=$("schInterval").value;
if(!n){toast("Isi nama","err");return;}
var key="t_"+Date.now().toString(36);
db.ref("scheduledTasks/"+key).set({name:n,interval:iv,active:true,by:CURRENT_USER,time:Date.now()}).then(function(){toast("Ditambah","ok");owScheduler();});
};

window.owBackup=function(){
db.ref("backups").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-cloud-arrow-up"></i> BACKUP & RESTORE</div>';
h+='<div class="info-box">Backup data members ke Firebase.</div>';
h+='<button class="btn cyan" onclick="owCreateBackup()">BUAT BACKUP SEKARANG</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var b=d[k];h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,var(--n),var(--n2))"><i class="fas fa-database"></i></div><div class="member-info"><div class="member-name">'+esc(b.name||k)+'</div><div class="member-meta">'+(b.size||"?").toLocaleString()+' bytes</div></div><button class="mact red" onclick="db.ref(\'backups/'+k+'\').remove();owBackup()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owCreateBackup=function(){
toast("Membuat backup...","ok");
db.ref("members").once("value").then(function(s){
var data=s.val()||{};
var json=JSON.stringify(data);
var key="bk_"+Date.now().toString(36);
db.ref("backups/"+key).set({name:"Backup "+new Date().toLocaleString("id-ID"),data:data,size:json.length,by:CURRENT_USER,time:Date.now()}).then(function(){logAction("backup","");toast("Backup dibuat","ok");owBackup();});
});
};

window.owApi=function(){
db.ref("apiEndpoints").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-plug"></i> API & INTEGRASI</div>';
h+='<input class="inp" id="apiName" placeholder="Nama endpoint"><input class="inp" id="apiUrl" placeholder="https://..."><button class="btn cyan" onclick="owAddApi()">TAMBAH ENDPOINT</button>';
if(keys.length){h+='<div style="margin-top:12px">';keys.forEach(function(k){var e=d[k];h+='<div class="member-item"><div class="member-av" style="background:linear-gradient(135deg,#f97316,#ea580c)"><i class="fas fa-plug"></i></div><div class="member-info"><div class="member-name">'+esc(e.name||"-")+'</div><div class="member-meta" style="word-break:break-all">'+esc(e.url||"-")+'</div></div><button class="mact red" onclick="db.ref(\'apiEndpoints/'+k+'\').remove();owApi()">HAPUS</button></div>';});h+='</div>';}
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owAddApi=function(){
var n=$("apiName").value.trim(),u=$("apiUrl").value.trim();
if(!n||!u){toast("Isi lengkap","err");return;}
var key="api_"+Date.now().toString(36);
db.ref("apiEndpoints/"+key).set({name:n,url:u,by:CURRENT_USER,time:Date.now()}).then(function(){toast("Ditambah","ok");owApi();});
};

window.owPerformance=function(){
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-gauge-high"></i> MONITORING PERFORMA</div>';
h+='<div class="ow-stat-grid">';
h+='<div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Uptime</div><div class="ow-stat-val">'+Math.floor(performance.now()/1000)+'s</div></div>';
h+='<div class="ow-stat" style="--sc:var(--c)"><div class="ow-stat-lbl">Memory</div><div class="ow-stat-val">'+(performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576)+"MB":"N/A")+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--g)"><div class="ow-stat-lbl">Connection</div><div class="ow-stat-val" style="font-size:.65rem">'+(navigator.onLine?"Online":"Offline")+'</div></div>';
h+='<div class="ow-stat" style="--sc:var(--p)"><div class="ow-stat-lbl">Latency</div><div class="ow-stat-val" id="perfLatency">...</div></div>';
h+='</div>';
h+='<button class="btn cyan" style="margin-top:12px" onclick="runPingTest()">PING TEST</button>';
h+='<div id="pingResult" style="margin-top:12px"></div>';
h+='</div>';
$("ownerPane").innerHTML=h;
};

window.runPingTest=function(){
var el=$("pingResult"),lat=$("perfLatency");
el.innerHTML=loading();
var t0=Date.now();
db.ref(".info/connected").once("value").then(function(){
var t=Date.now()-t0;
if(lat)lat.textContent=t+"ms";
el.innerHTML='<div class="info-box">Ping: <b>'+t+'ms</b> • '+(t<300?"🟢 Cepat":(t<1000?"🟡 Sedang":"🔴 Lambat"))+'</div>';
}).catch(function(){el.innerHTML='<div class="info-box red">Ping gagal</div>';});
};

window.owSecurity=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var issues=[];
Object.keys(m).forEach(function(k){
var u=m[k];
if(u.pass&&u.pass.length<6)issues.push(k+" pakai hash lemah");
if(u.loginCount>100&&!u.isAdmin)issues.push(k+" login "+u.loginCount+"x (mencurigakan)");
});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-fingerprint"></i> KEAMANAN AKUN</div>';
h+='<div class="info-box"><b>'+(issues.length?issues.length+" isu ditemukan":"✓ Tidak ada isu mencurigakan")+'</b>'+(issues.length?"<br><br>"+issues.slice(0,15).map(function(x){return "• "+esc(x);}).join("<br>"):"")+'</div>';
h+='<div class="ow-stat-grid"><div class="ow-stat" style="--sc:var(--n)"><div class="ow-stat-lbl">Total User</div><div class="ow-stat-val">'+Object.keys(m).length+'</div></div><div class="ow-stat" style="--sc:var(--r)"><div class="ow-stat-lbl">Banned</div><div class="ow-stat-val">'+Object.keys(m).filter(function(k){return m[k].banned;}).length+'</div></div></div>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owAuth=function(){
db.ref("members").once("value").then(function(s){
var m=s.val()||{};
var arr=Object.keys(m).map(function(k){var o=m[k];o._key=k;return o;}).filter(function(u){return u.lastLogin;}).sort(function(a,b){return new Date(b.lastLogin)-new Date(a.lastLogin);});
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-right-to-bracket"></i> LOGIN TERBARU</div>';
if(!arr.length)h+="<div class='empty-box'>Belum ada login</div>";
else arr.slice(0,50).forEach(function(u){h+='<div class="member-item"><div class="member-av">'+esc((u.display||u.username||u._key).charAt(0).toUpperCase())+'</div><div class="member-info"><div class="member-name">'+esc(u.display||u.username||u._key)+'</div><div class="member-meta">'+new Date(u.lastLogin).toLocaleString("id-ID")+'</div><div class="member-meta" style="color:var(--c)">Login '+(u.loginCount||1)+'x</div></div></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owVerify=function(){
db.ref("verificationRequests").once("value").then(function(s){
var d=s.val()||{},keys=Object.keys(d);
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-envelope-circle-check"></i> VERIFIKASI & PEMULIHAN</div>';
if(!keys.length)h+="<div class='empty-box'>Belum ada permintaan</div>";
else keys.forEach(function(k){var r=d[k];h+='<div class="member-item"><div class="member-info"><div class="member-name">'+esc(r.user||"-")+'</div><div class="member-meta">'+esc(r.type||"verify")+'</div></div><button class="mact grn" onclick="db.ref(\'verificationRequests/'+k+'\').remove();owVerify()">OK</button><button class="mact red" onclick="db.ref(\'verificationRequests/'+k+'\').remove();owVerify()">TOLAK</button></div>';});
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(e){$("ownerPane").innerHTML="<div class='info-box red'>"+esc(e.message)+"</div>";});
};

window.owOwnerCfg=function(){
db.ref("ownerConfig").once("value").then(function(s){
var v=s.val()||{};
var h='<div class="ow-panel"><div class="ow-panel-title"><i class="fas fa-user-tie"></i> PENGELOLAAN OWNER</div>';
h+='<div class="info-box red">Area berbahaya. Hanya owner utama yang boleh akses.</div>';
h+='<label class="lbl">Owner Username</label><input class="inp" id="ocUser" value="'+esc(v.ownerUser||OWNER_USER)+'">';
h+='<label class="lbl">Owner Password (biarkan kosong jika tidak diubah)</label><input type="password" class="inp" id="ocPass" placeholder="••••">';
h+='<label class="lbl">Kontak Darurat</label><input class="inp" id="ocContact" value="'+esc(v.emergencyContact||"")+'">';
h+='<button class="btn red" onclick="owSaveOwner()">SIMPAN</button>';
h+='</div>';
$("ownerPane").innerHTML=h;
}).catch(function(){});
};

window.owSaveOwner=function(){
if(!IS_OWNER){toast("Hanya owner","err");return;}
var s={ownerUser:$("ocUser").value.trim(),emergencyContact:$("ocContact").value.trim(),by:CURRENT_USER,time:Date.now()};
var np=$("ocPass").value.trim();
if(np)s.ownerPassHash=hashPass(np);
db.ref("ownerConfig").set(s).then(function(){logAction("owner_cfg","");toast("Disimpan","ok");});
};
