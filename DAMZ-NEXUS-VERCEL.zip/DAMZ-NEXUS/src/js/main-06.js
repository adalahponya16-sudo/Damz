
var MEMBER_TOOLS=[
{id:"t_tiktok",n:"TikTok DL",d:"Video no watermark",c:"tools",hot:1,ico:"fa-tiktok"},
{id:"t_fakewa",n:"Fake WA Chat",d:"Simulasi chat",c:"text",ico:"fa-whatsapp"},
{id:"t_fakewaprof",n:"Fake WA Profil",d:"Preview profil",c:"text",ico:"fa-user-circle"},
{id:"t_fakewagroup",n:"Fake WA Group",d:"Grup chat",c:"text",ico:"fa-users"},
{id:"t_fakewastatus",n:"Fake WA Status",d:"Story",c:"text",ico:"fa-circle-notch"},
{id:"t_fakewacall",n:"Fake WA Call",d:"UI demo",c:"text",ico:"fa-phone"},
{id:"t_fakemsgr",n:"Fake Messenger",d:"Simulasi",c:"text",ico:"fa-comment"},
{id:"t_faketg",n:"Fake Telegram",d:"Chat",c:"text",ico:"fa-paper-plane"},
{id:"t_fakeig",n:"Fake IG DM",d:"Simulasi",c:"text",ico:"fa-instagram"},
{id:"t_fakesms",n:"Fake SMS",d:"Simulasi",c:"text",ico:"fa-sms"},
{id:"t_fakeemail",n:"Fake Email",d:"Preview",c:"text",ico:"fa-envelope"},
{id:"t_b64",n:"Base64",d:"Encode/decode",c:"text",hot:1,ico:"fa-code"},
{id:"t_urlenc",n:"URL Encoder",d:"Encode/decode",c:"text",ico:"fa-link"},
{id:"t_htmlent",n:"HTML Entity",d:"Encode/decode",c:"text",ico:"fa-code"},
{id:"t_morse",n:"Morse Code",d:"-.-.",c:"text",ico:"fa-broadcast-tower"},
{id:"t_reverse",n:"Reverse Text",d:"Balik teks",c:"text",ico:"fa-rotate"},
{id:"t_case",n:"Case Converter",d:"UPPER/lower",c:"text",ico:"fa-font"},
{id:"t_leet",n:"Leet Speak",d:"h4ck",c:"text",ico:"fa-terminal"},
{id:"t_rot13",n:"ROT13",d:"Cipher",c:"text",ico:"fa-sync"},
{id:"t_caesar",n:"Caesar Cipher",d:"Shift",c:"text",ico:"fa-shield"},
{id:"t_binary",n:"Binary Code",d:"01010",c:"text",ico:"fa-microchip"},
{id:"t_hex",n:"Hex Code",d:"0x",c:"text",ico:"fa-hashtag"},
{id:"t_upsidedown",n:"Upside Down",d:"Balik",c:"text",ico:"fa-arrows-up-down"},
{id:"t_bubble",n:"Bubble Text",d:"Bulat",c:"text",ico:"fa-circle"},
{id:"t_strike",n:"Strike Text",d:"Coret",c:"text",ico:"fa-strikethrough"},
{id:"t_pig",n:"Pig Latin",d:"Trans",c:"text",ico:"fa-language"},
{id:"t_json",n:"JSON Formatter",d:"Beautify",c:"tools",hot:1,ico:"fa-brackets-curly"},
{id:"t_jsonval",n:"JSON Validator",d:"Validate",c:"tools",ico:"fa-check-circle"},
{id:"t_htmlfmt",n:"HTML Formatter",d:"Beautify",c:"tools",ico:"fa-html5"},
{id:"t_cssfmt",n:"CSS Formatter",d:"Beautify",c:"tools",ico:"fa-css3"},
{id:"t_jsfmt",n:"JS Formatter",d:"Beautify",c:"tools",ico:"fa-js"},
{id:"t_cssmin",n:"CSS Minifier",d:"Minify",c:"tools",ico:"fa-compress"},
{id:"t_jsmin",n:"JS Minifier",d:"Minify",c:"tools",ico:"fa-compress"},
{id:"t_regex",n:"Regex Test",d:"Test",c:"tools",ico:"fa-magnifying-glass"},
{id:"t_uuid",n:"UUID v4",d:"ID unik",c:"tools",ico:"fa-fingerprint"},
{id:"t_hash",n:"Hash Calc",d:"Hash",c:"tools",ico:"fa-lock"},
{id:"t_timestamp",n:"Timestamp",d:"Convert",c:"tools",ico:"fa-clock"},
{id:"t_charcount",n:"Char Counter",d:"Hitung",c:"tools",ico:"fa-text-width"},
{id:"t_wordcount",n:"Word Counter",d:"Hitung",c:"tools",ico:"fa-font"},
{id:"t_linecount",n:"Line Counter",d:"Hitung",c:"tools",ico:"fa-list-ol"},
{id:"t_dupline",n:"Dup Line Remover",d:"Hapus",c:"tools",ico:"fa-clone"},
{id:"t_sorttext",n:"Text Sorter",d:"Sort",c:"tools",ico:"fa-sort"},
{id:"t_diff",n:"Text Diff",d:"Compare",c:"tools",ico:"fa-code-compare"},
{id:"t_mdprev",n:"Markdown",d:"Preview",c:"tools",ico:"fa-markdown"},
{id:"t_csvjson",n:"CSV to JSON",d:"Convert",c:"tools",ico:"fa-file-csv"},
{id:"t_jsoncsv",n:"JSON to CSV",d:"Convert",c:"tools",ico:"fa-file-csv"},
{id:"t_urlparse",n:"URL Parser",d:"Parse",c:"tools",ico:"fa-link"},
{id:"t_httpstat",n:"HTTP Status",d:"Ref",c:"tools",ico:"fa-signal"},
{id:"t_ua",n:"User Agent",d:"View",c:"tools",ico:"fa-mobile"},
{id:"t_ipinfo",n:"IP Info",d:"Lookup",c:"tools",ico:"fa-location-dot"},
{id:"t_qr",n:"QR Generator",d:"QR code",c:"tools",hot:1,ico:"fa-qrcode"},
{id:"t_barcode",n:"Barcode",d:"Code",c:"tools",ico:"fa-barcode"},
{id:"t_colorpicker",n:"Color Picker",d:"HEX",c:"tools",ico:"fa-palette"},
{id:"t_colorconv",n:"Color Convert",d:"HEX/RGB",c:"tools",ico:"fa-droplet"},
{id:"t_gradient",n:"Gradient Gen",d:"CSS",c:"tools",ico:"fa-fill-drip"},
{id:"t_pwgen",n:"Password Gen",d:"Secure",c:"tools",hot:1,ico:"fa-key"},
{id:"t_pwcheck",n:"Password Check",d:"Strength",c:"tools",ico:"fa-shield-halved"},
{id:"t_random",n:"Random Num",d:"Acak",c:"tools",ico:"fa-dice"},
{id:"t_randstr",n:"Random String",d:"Acak",c:"tools",ico:"fa-shuffle"},
{id:"t_stopwatch",n:"Stopwatch",d:"Timer",c:"tools",ico:"fa-stopwatch"},
{id:"t_countdown",n:"Countdown",d:"Timer",c:"tools",ico:"fa-hourglass"},
{id:"t_pomodoro",n:"Pomodoro",d:"Timer",c:"tools",ico:"fa-clock"},
{id:"t_calc",n:"Calculator",d:"Hitung",c:"tools",ico:"fa-calculator"},
{id:"t_length",n:"Length Conv",d:"Meter",c:"tools",ico:"fa-ruler"},
{id:"t_weight",n:"Weight Conv",d:"Kg",c:"tools",ico:"fa-weight-scale"},
{id:"t_temp",n:"Temp Conv",d:"Suhu",c:"tools",ico:"fa-temperature-half"},
{id:"t_percent",n:"Percent",d:"%",c:"tools",ico:"fa-percent"},
{id:"t_tip",n:"Tip Calc",d:"Tip",c:"tools",ico:"fa-hand-holding-dollar"},
{id:"t_discount",n:"Discount",d:"Diskon",c:"tools",ico:"fa-tag"},
{id:"t_bmi",n:"BMI Calc",d:"Index",c:"tools",ico:"fa-heart-pulse"},
{id:"t_age",n:"Age Calc",d:"Umur",c:"tools",ico:"fa-cake-candles"},
{id:"t_lottery",n:"Lottery",d:"Lotre",c:"tools",ico:"fa-ticket"},
{id:"t_coin",n:"Coin Flip",d:"Koin",c:"fun",ico:"fa-coins"},
{id:"t_dice",n:"Dice Roll",d:"Dadu",c:"fun",ico:"fa-dice"},
{id:"f_joke",n:"Joke",d:"Lawak",c:"fun",ico:"fa-face-laugh"},
{id:"f_love",n:"Love Calc",d:"Kecocokan",c:"fun",ico:"fa-heart"},
{id:"f_truth",n:"Truth/Dare",d:"T/D",c:"fun",ico:"fa-question"},
{id:"f_spin",n:"Spin Wheel",d:"Putar",c:"fun",ico:"fa-circle-notch"},
{id:"f_magic8",n:"Magic 8 Ball",d:"Bola",c:"fun",ico:"fa-8"},
{id:"f_fortune",n:"Fortune",d:"Ramalan",c:"fun",ico:"fa-cookie"},
{id:"f_horoscope",n:"Horoscope",d:"Zodiak",c:"fun",ico:"fa-star"},
{id:"f_nickname",n:"Nickname",d:"Nick",c:"fun",ico:"fa-gamepad"},
{id:"f_slug",n:"Slug Maker",d:"URL",c:"fun",ico:"fa-link"},
{id:"f_palindrome",n:"Palindrome",d:"Cek",c:"fun",ico:"fa-rotate"},
{id:"f_vowel",n:"Vowel Counter",d:"Vokal",c:"fun",ico:"fa-a"},
{id:"mk_iqc",n:"IQC Generator",d:"Quote",c:"maker",hot:1,ico:"fa-quote-left"},
{id:"mk_brat",n:"BRAT Maker",d:"Brat",c:"maker",ico:"fa-font"},
{id:"mk_meme",n:"Meme Gen",d:"Meme",c:"maker",ico:"fa-image"},
{id:"mk_quote",n:"Quote Maker",d:"Quote",c:"maker",ico:"fa-quote-right"},
{id:"mk_hashtag",n:"Hashtag",d:"Tag",c:"maker",ico:"fa-hashtag"},
{id:"mk_vcard",n:"vCard",d:".vcf",c:"maker",ico:"fa-address-card"},
{id:"mk_emoji",n:"Emoji Art",d:"Emoji",c:"maker",ico:"fa-face-smile"},
{id:"i_resize",n:"Image Resize",d:"Resize",c:"image",ico:"fa-expand"},
{id:"i_compress",n:"Image Compress",d:"Kompres",c:"image",ico:"fa-compress"},
{id:"i_crop",n:"Image Crop",d:"Crop",c:"image",ico:"fa-crop"},
{id:"i_format",n:"Format Convert",d:"Convert",c:"image",ico:"fa-file-image"},
{id:"i_rotate",n:"Image Rotate",d:"Putar",c:"image",ico:"fa-rotate-right"},
{id:"i_grayscale",n:"Grayscale",d:"Abu",c:"image",ico:"fa-droplet-slash"},
{id:"i_blur",n:"Image Blur",d:"Blur",c:"image",ico:"fa-eye-slash"},
{id:"i_brightness",n:"Brightness",d:"Terang",c:"image",ico:"fa-sun"},
{id:"i_contrast",n:"Image Contrast",d:"Kontras",c:"image",ico:"fa-circle-half-stroke"},
{id:"v_voice",n:"Voice Changer",d:"Real-time (Owner)",c:"voice",hot:1,ico:"fa-wave-square",ownerOnly:true},
{id:"v_ai_chat",n:"AI Chat",d:"REAL AI",c:"vip",hot:1,ico:"fa-robot"},
{id:"v_ai_image",n:"AI Image",d:"Text2img",c:"vip",hot:1,ico:"fa-image"},
{id:"v_ai_translate",n:"AI Translate",d:"100+ bahasa",c:"vip",ico:"fa-language"},
{id:"v_img_hd",n:"HD Image",d:"Upscale",c:"vip",hot:1,ico:"fa-expand"},
{id:"v_tts",n:"Text to Voice",d:"TTS",c:"vip",ico:"fa-volume-up"},
{id:"v_json",n:"JSON Format VIP",d:"Format",c:"vip",ico:"fa-brackets-curly"}
];
var COLORS_MAP={text:"#fbbf24",tools:"#22d3ee",fun:"#a855f7",maker:"#22c55e",image:"#f43f5e",vip:"#f59e0b",voice:"#a855f7"};
function getToolIcon(t){if(t.ico)return t.ico;var m={text:"fa-font",tools:"fa-screwdriver-wrench",fun:"fa-face-laugh",maker:"fa-wand-magic-sparkles",image:"fa-image",vip:"fa-gem",voice:"fa-wave-square"};return m[t.c]||"fa-toolbox";}
function getToolsForRole(){var all=MEMBER_TOOLS.slice();if(!IS_OWNER&&!IS_ADMIN&&!IS_VIP){all=all.filter(function(t){return t.c!=="vip";});}if(!IS_OWNER){all=all.filter(function(t){return !t.ownerOnly;});}return all;}
function renderPopular(){var hot=getToolsForRole().filter(function(t){return t.hot;}).slice(0,6);renderGrid("popularGrid",hot);}
window.renderPopular=renderPopular;
function renderGrid(id,items){var c=$(id);if(!c)return;if(!items.length){c.innerHTML="<div style='grid-column:1/-1;text-align:center;padding:20px;color:var(--t3);font-size:.7rem'>Kosong</div>";return;}var h="";items.forEach(function(t){var badge=t.c==="vip"?"<span class='tool-card-tag vip'>VIP</span>":(t.ownerOnly?"<span class='tool-card-tag vip'>OWNER</span>":(t.hot?"<span class='tool-card-tag hot'>HOT</span>":""));var ac=COLORS_MAP[t.c]||"#00ff88";h+="<div class='tool-card' style='--ac:"+ac+"' onclick=\"openTool('"+t.id+"')\">"+badge+"<div class='tool-card-ico'><i class='fas "+getToolIcon(t)+"'></i></div><div class='tool-card-nm'>"+esc(t.n)+"</div><div class='tool-card-ds'>"+esc(t.d||"")+"</div></div>";});c.innerHTML=h;}
function renderCategory(cat){var container=$("toolsContainer");if(!container)return;var items=getToolsForRole();if(cat!=="all")items=items.filter(function(t){return t.c===cat;});container.innerHTML="<div class='sec-head'><span class='sec-head-num'>//</span><span class='sec-head-title'>MODULES</span><span class='sec-head-count'>"+items.length+"</span></div><div class='tools-grid' id='catGrid'></div>";renderGrid("catGrid",items);document.querySelectorAll(".chip").forEach(function(ch){if(ch.getAttribute("data-cat")===cat)ch.classList.add("on");else ch.classList.remove("on");});}
window.renderCategory=renderCategory;
function openTool(id){var tools=getToolsForRole(),t=null;for(var i=0;i<tools.length;i++)if(tools[i].id===id){t=tools[i];break;}if(!t){toast("Tool tidak ada","err");return;}if(t.c==="vip"&&!IS_OWNER&&!IS_ADMIN&&!IS_VIP){toast("Khusus VIP","err");return;}if(t.ownerOnly&&!IS_OWNER){toast("Fitur khusus Owner","err");return;}if(CURRENT_USER){var m=getMembers();if(m[CURRENT_USER]){m[CURRENT_USER].toolsUsed=(m[CURRENT_USER].toolsUsed||0)+1;saveMembers(m);}}$("viewer").classList.add("on");$("viewerBody").innerHTML="<div class='viewer-lbl'>"+t.c.toUpperCase()+"</div><div class='viewer-h'>"+esc(t.n)+"</div><div class='viewer-d'>"+esc(t.d||"")+"</div><div id='toolInput'>"+getToolUI(t.id)+"</div><div id='toolResult' style='display:none;margin-top:12px'></div>";if(t.id==="t_tiktok"){setTimeout(bindTikTokUI,80);}if(t.id==="v_voice"){setTimeout(vcRenderUI,80);}}
window.openTool=openTool;
function showResult(h){var r=$("toolResult");if(!r)return;r.style.display="block";r.innerHTML=h+'<div id="resultActions" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button class="btn sec" onclick="copyResultText()" type="button"><i class="fas fa-copy"></i> SALIN</button><button class="btn cyan" onclick="downloadResultText()" type="button"><i class="fas fa-download"></i> DOWNLOAD</button></div>';}
window.showResult=showResult;
function getResultText(){var r=$("toolResult");if(!r)return "";var clone=r.cloneNode(true);clone.querySelectorAll("button").forEach(function(b){b.remove();});var img=clone.querySelector("img");if(img)return img.src;var audio=clone.querySelector("audio");if(audio)return audio.src;return clone.textContent.trim();}
window.getResultText=getResultText;
window.copyResultText=function(){var t=getResultText();if(!t){toast("Tidak ada hasil","err");return;}copyText(t);};
window.downloadResultText=function(){var t=getResultText();if(!t){toast("Tidak ada hasil","err");return;}if(t.indexOf("data:image")===0){var a=document.createElement("a");a.href=t;a.download="damz_"+Date.now()+".png";a.click();toast("Gambar didownload","ok");return;}if(t.indexOf("http")===0&&(t.indexOf(".png")>=0||t.indexOf(".jpg")>=0||t.indexOf("qrserver")>=0||t.indexOf("pollinations")>=0||t.indexOf("tec-it")>=0)){toast("Mengunduh...","ok");fetch(t).then(function(r){return r.blob();}).then(function(blob){var u=URL.createObjectURL(blob);var a2=document.createElement("a");a2.href=u;a2.download="damz_"+Date.now()+".png";a2.click();setTimeout(function(){URL.revokeObjectURL(u);},3000);toast("Gambar didownload","ok");}).catch(function(){window.open(t,"_blank");});return;}var blob=new Blob([t],{type:"text/plain"});var a3=document.createElement("a");a3.href=URL.createObjectURL(blob);a3.download="damz_"+Date.now()+".txt";a3.click();setTimeout(function(){URL.revokeObjectURL(a3.href);},3000);toast("File didownload","ok");};

function getToolUI(id){
var u={
"t_tiktok":"<div id='ttWrap'><div style='background:linear-gradient(135deg,rgba(15,36,22,.85),rgba(10,26,16,.6));border:1.5px solid var(--b2);border-radius:16px;padding:14px;margin-bottom:12px'><div style='display:flex;gap:8px'><input type='url' id='ttUrl' placeholder='Tempel link TikTok...' autocomplete='off' autocapitalize='none' style='flex:1;padding:12px 14px;background:rgba(5,16,9,.9);border:1.5px solid var(--b);color:var(--t);font-size:.75rem;border-radius:10px;font-weight:600;outline:none;font-family:var(--fm)'><button type='button' id='ttPaste' style='padding:0 12px;background:rgba(0,255,136,.12);border:1.5px solid var(--b2);color:var(--n);font-family:var(--fm);font-size:.46rem;font-weight:900;border-radius:10px;cursor:pointer'>PASTE</button></div></div><button type='button' id='ttFetch' style='width:100%;padding:14px;background:linear-gradient(135deg,var(--n),var(--c));color:#000;font-family:var(--fd);font-weight:900;font-size:.72rem;letter-spacing:3px;border:none;border-radius:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px'><i class='fas fa-bolt'></i> CARI VIDEO</button><div id='ttError' style='display:none;background:rgba(239,68,68,.1);border-left:4px solid var(--r);color:#fca5a5;padding:10px 12px;border-radius:0 10px 10px 0;font-size:.65rem;margin-top:10px'></div><div id='ttLoading' style='display:none;text-align:center;padding:24px 20px'><div class='loader-ring' style='margin:0 auto 10px;width:44px;height:44px'></div><div class='loader-text'>Mengambil video...</div></div><div id='ttResult' style='display:none;margin-top:12px'></div></div>",
"t_fakewa":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Halo!</textarea><button class='btn' onclick='runFakeWa()'>GEN</button>",
"t_fakewaprof":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><label class='lbl'>Bio</label><input class='inp' id='inp2' value='Hello'><button class='btn' onclick='runFakeWaProf()'>GEN</button>",
"t_fakewagroup":"<label class='lbl'>Grup</label><input class='inp' id='inp1' value='Grup'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Hello</textarea><button class='btn' onclick='runFakeWaGroup()'>GEN</button>",
"t_fakewastatus":"<label class='lbl'>Status</label><input class='inp' id='inp1' value='Status'><button class='btn' onclick='runFakeWaStatus()'>GEN</button>",
"t_fakewacall":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><button class='btn' onclick='runFakeWaCall()'>GEN</button>",
"t_fakemsgr":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Hello</textarea><button class='btn' onclick='runFakeMsgr()'>GEN</button>",
"t_faketg":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Hello</textarea><button class='btn' onclick='runFakeTg()'>GEN</button>",
"t_fakeig":"<label class='lbl'>Nama</label><input class='inp' id='inp1' value='User'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Hello</textarea><button class='btn' onclick='runFakeIg()'>GEN</button>",
"t_fakesms":"<label class='lbl'>Nomor</label><input class='inp' id='inp1' value='+62'><label class='lbl'>Pesan</label><textarea class='ta' id='inp2'>Hello</textarea><button class='btn' onclick='runFakeSms()'>GEN</button>",
"t_fakeemail":"<label class='lbl'>Dari</label><input class='inp' id='inp1' value='user@mail.com'><label class='lbl'>Subject</label><input class='inp' id='inp2' value='Subject'><label class='lbl'>Body</label><textarea class='ta' id='inp3'>Hello</textarea><button class='btn' onclick='runFakeEmail()'>GEN</button>",
"t_b64":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runB64(1)'>ENCODE</button><button class='btn sec' onclick='runB64(0)'>DECODE</button></div>",
"t_urlenc":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runUrlEnc(1)'>ENCODE</button><button class='btn sec' onclick='runUrlEnc(0)'>DECODE</button></div>",
"t_htmlent":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runHtmlEnt(1)'>ENCODE</button><button class='btn sec' onclick='runHtmlEnt(0)'>DECODE</button></div>",
"t_morse":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runMorse(1)'>T to M</button><button class='btn sec' onclick='runMorse(0)'>M to T</button></div>",
"t_reverse":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runReverse()'>REVERSE</button>",
"t_case":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runCase(1)'>UPPER</button><button class='btn sec' onclick='runCase(0)'>lower</button></div>",
"t_leet":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runLeet()'>LEET</button>",
"t_rot13":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runRot13()'>ROT13</button>",
"t_caesar":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><label class='lbl'>Shift</label><input type='number' class='inp' id='inp2' value='3'><button class='btn' onclick='runCaesar()'>ENCRYPT</button>",
"t_binary":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runBinary(1)'>T to B</button><button class='btn sec' onclick='runBinary(0)'>B to T</button></div>",
"t_hex":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn' onclick='runHex(1)'>T to H</button><button class='btn sec' onclick='runHex(0)'>H to T</button></div>",
"t_upsidedown":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runUpsideDown()'>BALIK</button>",
"t_bubble":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runBubble()'>BUBBLE</button>",
"t_strike":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runStrike()'>STRIKE</button>",
"t_pig":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runPig()'>PIG</button>",
"t_json":"<label class='lbl'>JSON</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runJson()'>FORMAT</button>",
"t_jsonval":"<label class='lbl'>JSON</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runJsonVal()'>VALIDATE</button>",
"t_htmlfmt":"<label class='lbl'>HTML</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runHtmlFmt()'>FORMAT</button>",
"t_cssfmt":"<label class='lbl'>CSS</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runCssFmt()'>FORMAT</button>",
"t_jsfmt":"<label class='lbl'>JS</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runJsFmt()'>FORMAT</button>",
"t_cssmin":"<label class='lbl'>CSS</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runCssMin()'>MINIFY</button>",
"t_jsmin":"<label class='lbl'>JS</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runJsMin()'>MINIFY</button>",
"t_regex":"<label class='lbl'>Pattern</label><input class='inp' id='inp1' placeholder='digit+'><label class='lbl'>Text</label><textarea class='ta' id='inp2'></textarea><button class='btn' onclick='runRegex()'>TEST</button>",
"t_uuid":"<button class='btn' onclick='runUuid()'>GENERATE UUID v4</button>",
"t_hash":"<label class='lbl'>Text</label><input class='inp' id='inp1'><button class='btn' onclick='runHash()'>HASH</button>",
"t_timestamp":"<label class='lbl'>Timestamp atau Date</label><input class='inp' id='inp1' placeholder='1730000000000'><button class='btn' onclick='runTimestamp()'>CONVERT</button>",
"t_charcount":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runCharCount()'>HITUNG</button>",
"t_wordcount":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runWordCount()'>HITUNG</button>",
"t_linecount":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runLineCount()'>HITUNG</button>",
"t_dupline":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runDupLine()'>HAPUS DUPLIKAT</button>",
"t_sorttext":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runSortText()'>SORT</button>",
"t_diff":"<label class='lbl'>Text 1</label><textarea class='ta' id='inp1'></textarea><label class='lbl'>Text 2</label><textarea class='ta' id='inp2'></textarea><button class='btn' onclick='runDiff()'>DIFF</button>",
"t_mdprev":"<label class='lbl'>Markdown</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runMdPrev()'>PREVIEW</button>",
"t_csvjson":"<label class='lbl'>CSV</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runCsvJson()'>CONVERT</button>",
"t_jsoncsv":"<label class='lbl'>JSON</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runJsonCsv()'>CONVERT</button>",
"t_urlparse":"<label class='lbl'>URL</label><input class='inp' id='inp1' value='https://example.com/path?x=1'><button class='btn' onclick='runUrlParse()'>PARSE</button>",
"t_httpstat":"<label class='lbl'>Code</label><input class='inp' id='inp1' value='200'><button class='btn' onclick='runHttpStat()'>LIHAT</button>",
"t_ua":"<button class='btn' onclick='runUaView()'>LIHAT USER AGENT</button>",
"t_ipinfo":"<button class='btn' onclick='runIpInfo()'>LIHAT IP</button>",
"t_qr":"<label class='lbl'>Text atau URL</label><input class='inp' id='inp1'><button class='btn' onclick='runQr()'>BUAT QR</button>",
"t_barcode":"<label class='lbl'>Text</label><input class='inp' id='inp1'><button class='btn' onclick='runBarcode()'>BUAT BARCODE</button>",
"t_colorpicker":"<label class='lbl'>Warna</label><input type='color' id='inp1' value='#00ff88' style='width:100%;height:56px;border-radius:12px;margin-bottom:10px;border:none'><button class='btn' onclick='runColorPicker()'>INFO</button>",
"t_colorconv":"<label class='lbl'>HEX</label><input class='inp' id='inp1' value='#00ff88'><button class='btn' onclick='runColorConv()'>KONVERSI</button>",
"t_gradient":"<label class='lbl'>W1</label><input type='color' id='inp1' value='#00ff88' style='width:100%;height:46px;border-radius:12px;margin-bottom:10px;border:none'><label class='lbl'>W2</label><input type='color' id='inp2' value='#22d3ee' style='width:100%;height:46px;border-radius:12px;margin-bottom:10px;border:none'><button class='btn' onclick='runGradient()'>BUAT</button>",
"t_pwgen":"<label class='lbl'>Panjang</label><input type='range' id='inp1' min='6' max='64' value='16' style='width:100%;margin-bottom:10px'><div style='display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap'><label style='font-size:.6rem;color:var(--t2)'><input type='checkbox' id='pwU' checked> UPPER</label><label style='font-size:.6rem;color:var(--t2)'><input type='checkbox' id='pwL' checked> lower</label><label style='font-size:.6rem;color:var(--t2)'><input type='checkbox' id='pwN' checked> 123</label><label style='font-size:.6rem;color:var(--t2)'><input type='checkbox' id='pwS' checked> SIMBOL</label></div><button class='btn' onclick='runPwGen()'>GEN</button>",
"t_pwcheck":"<label class='lbl'>Password</label><input class='inp' id='inp1'><button class='btn' onclick='runPwCheck()'>CEK</button>",
"t_random":"<label class='lbl'>Min</label><input type='number' class='inp' id='inp1' value='1'><label class='lbl'>Max</label><input type='number' class='inp' id='inp2' value='100'><button class='btn' onclick='runRandom()'>GEN</button>",
"t_randstr":"<label class='lbl'>Panjang</label><input type='number' class='inp' id='inp1' value='16'><button class='btn' onclick='runRandStr()'>GEN</button>",
"t_stopwatch":"<div style='text-align:center;font-family:var(--fm);font-size:2.8rem;font-weight:900;color:var(--n);margin-bottom:12px' id='inp1'>00:00.0</div><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn green' onclick='swStart()'>START</button><button class='btn red' onclick='swReset()'>RESET</button></div>",
"t_countdown":"<label class='lbl'>Detik</label><input type='number' class='inp' id='inp1' value='60'><button class='btn' onclick='runCountdown()'>MULAI</button><div id='cdDisplay' style='text-align:center;font-family:var(--fm);font-size:2rem;color:var(--n);margin-top:12px'></div>",
"t_pomodoro":"<div id='pomoDisplay' style='text-align:center;font-family:var(--fm);font-size:2rem;color:var(--n);padding:20px'>25:00</div><button class='btn' onclick='runPomodoro()'>MULAI 25 MENIT</button>",
"t_calc":"<input class='inp' id='inp1' placeholder='2+3*4'><button class='btn green' onclick='runCalc()'>HITUNG</button>",
"t_length":"<label class='lbl'>Meter</label><input type='number' class='inp' id='inp1' value='1'><button class='btn' onclick='runLength()'>KONVERSI</button>",
"t_weight":"<label class='lbl'>KG</label><input type='number' class='inp' id='inp1' value='1'><button class='btn' onclick='runWeight()'>KONVERSI</button>",
"t_temp":"<label class='lbl'>Nilai</label><input type='number' class='inp' id='inp1' value='30'><label class='lbl'>Dari</label><select class='sel' id='inp2'><option value='C'>Celsius</option><option value='F'>Fahrenheit</option><option value='K'>Kelvin</option></select><button class='btn' onclick='runTemp()'>KONVERSI</button>",
"t_percent":"<label class='lbl'>Angka</label><input type='number' class='inp' id='inp1' value='50'><label class='lbl'>Persen</label><input type='number' class='inp' id='inp2' value='20'><button class='btn' onclick='runPercent()'>HITUNG</button>",
"t_tip":"<label class='lbl'>Tagihan</label><input type='number' class='inp' id='inp1' value='100000'><label class='lbl'>Tip persen</label><input type='number' class='inp' id='inp2' value='10'><button class='btn' onclick='runTip()'>HITUNG</button>",
"t_discount":"<label class='lbl'>Harga</label><input type='number' class='inp' id='inp1' value='100000'><label class='lbl'>Diskon persen</label><input type='number' class='inp' id='inp2' value='20'><button class='btn' onclick='runDiscount()'>HITUNG</button>",
"t_bmi":"<label class='lbl'>Berat kg</label><input type='number' class='inp' id='inp1' value='60'><label class='lbl'>Tinggi cm</label><input type='number' class='inp' id='inp2' value='170'><button class='btn' onclick='runBmi()'>HITUNG</button>",
"t_age":"<label class='lbl'>Tgl Lahir</label><input type='date' class='inp' id='inp1'><button class='btn' onclick='runAge()'>HITUNG</button>",
"t_lottery":"<label class='lbl'>Jumlah</label><input type='number' class='inp' id='inp1' value='6'><button class='btn' onclick='runLottery()'>GEN</button>",
"t_coin":"<button class='btn gold' onclick='runCoin()'>FLIP COIN</button>",
"t_dice":"<label class='lbl'>Jumlah</label><input type='number' class='inp' id='inp1' value='1'><button class='btn' onclick='runDice()'>ROLL</button>",
"f_joke":"<button class='btn' onclick='runJoke()'>JOKE</button>",
"f_love":"<label class='lbl'>Nama 1</label><input class='inp' id='inp1'><label class='lbl'>Nama 2</label><input class='inp' id='inp2'><button class='btn' onclick='runLove()'>HITUNG</button>",
"f_truth":"<div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><button class='btn cyan' onclick='runTruth(\"truth\")'>TRUTH</button><button class='btn red' onclick='runTruth(\"dare\")'>DARE</button></div>",
"f_spin":"<label class='lbl'>Pilihan pisahkan koma</label><input class='inp' id='inp1' value='A,B,C,D,E'><button class='btn' onclick='runSpin()'>PUTAR</button>",
"f_magic8":"<label class='lbl'>Pertanyaan</label><input class='inp' id='inp1'><button class='btn' onclick='runMagic8()'>TANYA</button>",
"f_fortune":"<button class='btn gold' onclick='runFortune()'>BUKA</button>",
"f_horoscope":"<label class='lbl'>Zodiak</label><select class='sel' id='inp1'><option>Aries</option><option>Taurus</option><option>Gemini</option><option>Cancer</option><option>Leo</option><option>Virgo</option><option>Libra</option><option>Scorpio</option><option>Sagittarius</option><option>Capricorn</option><option>Aquarius</option><option>Pisces</option></select><button class='btn' onclick='runHoroscope()'>LIHAT</button>",
"f_nickname":"<label class='lbl'>Nama</label><input class='inp' id='inp1'><button class='btn' onclick='runNickname()'>GEN</button>",
"f_slug":"<label class='lbl'>Text</label><input class='inp' id='inp1'><button class='btn' onclick='runSlug()'>BUAT</button>",
"f_palindrome":"<label class='lbl'>Text</label><input class='inp' id='inp1' placeholder='kasur rusak'><button class='btn' onclick='runPalindrome()'>CEK</button>",
"f_vowel":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runVowel()'>HITUNG</button>",
"mk_iqc":"<label class='lbl'>Quote</label><textarea class='ta' id='inp1'>Stay hungry, stay foolish.</textarea><label class='lbl'>Author</label><input class='inp' id='inp2' value='Steve Jobs'><button class='btn' onclick='runIqc()'>GEN</button>",
"mk_brat":"<label class='lbl'>Text</label><input class='inp' id='inp1' value='brat'><button class='btn' onclick='runBrat()'>GEN</button>",
"mk_meme":"<label class='lbl'>Top</label><input class='inp' id='inp1' value='TOP TEXT'><label class='lbl'>Bottom</label><input class='inp' id='inp2' value='BOTTOM TEXT'><button class='btn' onclick='runMeme()'>GEN</button>",
"mk_quote":"<label class='lbl'>Quote</label><textarea class='ta' id='inp1'></textarea><button class='btn' onclick='runQuote()'>GEN</button>",
"mk_hashtag":"<label class='lbl'>Topik</label><input class='inp' id='inp1' value='motivasi'><button class='btn' onclick='runHashtag()'>GEN</button>",
"mk_vcard":"<label class='lbl'>Nama</label><input class='inp' id='inp1'><label class='lbl'>Telp</label><input class='inp' id='inp2'><label class='lbl'>Email</label><input class='inp' id='inp3'><button class='btn' onclick='runVcard()'>GEN</button>",
"mk_emoji":"<label class='lbl'>Emoji</label><input class='inp' id='inp1' value='⭐'><button class='btn' onclick='runEmojiArt()'>REPEAT</button>",
"i_resize":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Lebar (px)</label><input type='number' class='inp' id='inp2' value='800'><button class='btn' onclick='runImgResize()'>RESIZE</button>",
"i_compress":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Kualitas (10-100)</label><input type='number' class='inp' id='inp2' value='60'><button class='btn' onclick='runImgCompress()'>KOMPRES</button>",
"i_crop":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px'><input type='number' class='inp' id='inp2' value='0' placeholder='X'><input type='number' class='inp' id='inp3' value='0' placeholder='Y'><input type='number' class='inp' id='inp4' value='300' placeholder='W'><input type='number' class='inp' id='inp5' value='300' placeholder='H'></div><button class='btn' onclick='runImgCrop()'>CROP</button>",
"i_format":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Format</label><select class='sel' id='inp2'><option value='image/png'>PNG</option><option value='image/jpeg'>JPEG</option><option value='image/webp'>WEBP</option></select><button class='btn' onclick='runImgFormat()'>CONVERT</button>",
"i_rotate":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Derajat</label><input type='number' class='inp' id='inp2' value='90'><button class='btn' onclick='runImgRotate()'>ROTATE</button>",
"i_grayscale":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><button class='btn' onclick='runImgGrayscale()'>GRAYSCALE</button>",
"i_blur":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Blur px</label><input type='number' class='inp' id='inp2' value='5'><button class='btn' onclick='runImgBlur()'>BLUR</button>",
"i_brightness":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Level (50-200)</label><input type='number' class='inp' id='inp2' value='120'><button class='btn' onclick='runImgBrightness()'>APPLY</button>",
"i_contrast":"<label class='lbl'>Upload Image</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Level (50-200)</label><input type='number' class='inp' id='inp2' value='120'><button class='btn' onclick='runImgContrast()'>APPLY</button>",
"v_voice":"<div id='voiceChangerUI'></div>",
"v_ai_chat":"<label class='lbl'>Pertanyaan</label><textarea class='ta' id='inp1' placeholder='Tanya apa aja...'></textarea><div style='display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px'><button class='btn green' onclick='runAiChat()'><i class='fas fa-robot'></i> TANYA</button><button class='btn red' onclick='clearAiHist()'><i class='fas fa-trash'></i> HAPUS</button></div><div id='aiHist' style='max-height:200px;overflow-y:auto'></div>",
"v_ai_image":"<label class='lbl'>Prompt</label><textarea class='ta' id='inp1' placeholder='kucing imut'></textarea><button class='btn green' onclick='runAiImage()'>GENERATE</button>",
"v_ai_translate":"<label class='lbl'>Text</label><textarea class='ta' id='inp1'></textarea><label class='lbl'>Ke</label><select class='sel' id='inp2'><option value='en'>English</option><option value='id'>Indonesia</option><option value='ja'>Jepang</option><option value='ko'>Korea</option><option value='ar'>Arab</option></select><button class='btn green' onclick='runAiTranslate()'>TRANSLATE</button>",
"v_img_hd":"<label class='lbl'>Upload</label><input type='file' class='inp' accept='image/*' id='inp1'><label class='lbl'>Level</label><select class='sel' id='inp2'><option value='2'>2x</option><option value='3'>3x</option><option value='4'>4x</option></select><button class='btn green' onclick='runHdImage()'>HD</button>",
"v_tts":"<label class='lbl'>Text max 200</label><textarea class='ta' id='inp1' maxlength='200'>Halo, ini DAMZ Nexus</textarea><label class='lbl'>Bahasa</label><select class='sel' id='inp2'><option value='id'>Indonesia</option><option value='en'>English</option><option value='ja'>Jepang</option></select><button class='btn green' onclick='runTts()'><i class='fas fa-volume-up'></i> PUTAR</button>",
"v_json":"<label class='lbl'>JSON</label><textarea class='ta' id='inp1'></textarea><button class='btn green' onclick='runJson()'>FORMAT</button>"
};return u[id]||"<div class='info-box orange'><b>Tool belum tersedia</b><br>Fitur ini disembunyikan sampai fungsi aslinya siap.</div>";}
window.getToolUI=getToolUI;

var TT_STATE={hd:"",normal:"",audio:"",cover:"",desc:"",author:"",currentQ:"auto"};
window.bindTikTokUI=function(){
var inp=$("ttUrl"),pasteBtn=$("ttPaste"),fetchBtn=$("ttFetch");
if(pasteBtn)pasteBtn.onclick=function(){
if(navigator.clipboard&&navigator.clipboard.readText){navigator.clipboard.readText().then(function(t){if(inp)inp.value=t;toast("Paste berhasil","ok");}).catch(function(){toast("Gagal akses clipboard","err");});}
else toast("Clipboard tidak support","err");
};
if(fetchBtn)fetchBtn.onclick=runTikTokFetch;
if(inp)inp.onkeydown=function(e){if(e.key==="Enter"){e.preventDefault();runTikTokFetch();}};
};
window.runTikTokFetch=function(){
var inp=$("ttUrl"),err=$("ttError"),load=$("ttLoading"),res=$("ttResult"),btn=$("ttFetch");
if(!inp)return;
var url=inp.value.trim();
if(err)err.style.display="none";
if(res)res.style.display="none";
if(!url){if(err){err.textContent="Masukkan link TikTok";err.style.display="block";}return;}
if(!/tiktok\.com/i.test(url)){if(err){err.textContent="Link harus dari TikTok";err.style.display="block";}return;}
if(load)load.style.display="block";
if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> MENCARI...';}
var ctrl=new AbortController();
var to=setTimeout(function(){ctrl.abort();},45000);
fetch("https://www.tikwm.com/api/?url="+encodeURIComponent(url),{signal:ctrl.signal})
.then(function(r){return r.json();})
.then(function(json){
clearTimeout(to);
if(!json||!json.data||(!json.data.play&&!json.data.hdplay))throw new Error(json&&json.msg?json.msg:"Video tidak ditemukan / private");
var d=json.data;
TT_STATE.hd=(d.hdplay||d.play||"").indexOf("http")===0?(d.hdplay||d.play||""):("https://www.tikwm.com"+(d.hdplay||d.play||""));
TT_STATE.normal=(d.play||d.hdplay||"").indexOf("http")===0?(d.play||d.hdplay||""):("https://www.tikwm.com"+(d.play||d.hdplay||""));
TT_STATE.audio=(d.music||"").indexOf("http")===0?(d.music||""):("https://www.tikwm.com"+(d.music||""));
TT_STATE.cover=(d.origin_cover||d.cover||"").indexOf("http")===0?(d.origin_cover||d.cover||""):("https://www.tikwm.com"+(d.origin_cover||d.cover||""));
TT_STATE.desc=d.title||"Tidak ada deskripsi";
TT_STATE.author=d.author?(d.author.nickname||d.author.unique_id||"unknown"):"unknown";
TT_STATE.currentQ="hd";
if(load)load.style.display="none";
if(btn){btn.disabled=false;btn.innerHTML='<i class="fas fa-bolt"></i> CARI VIDEO';}
renderTikTokResult();
})
.catch(function(e){
clearTimeout(to);
if(load)load.style.display="none";
if(btn){btn.disabled=false;btn.innerHTML='<i class="fas fa-bolt"></i> CARI VIDEO';}
if(err){err.textContent=(e.name==="AbortError"?"Request timeout":(e.message||"Gagal"));err.style.display="block";}
});
};
function renderTikTokResult(){
var res=$("ttResult");if(!res)return;
var h='<div class="tt-card"><div class="tt-player" id="ttPlayer">';
if(TT_STATE.cover)h+='<img class="tt-poster" id="ttPoster" src="'+esc(TT_STATE.cover)+'" crossorigin="anonymous" referrerpolicy="no-referrer" alt="cover">';
h+='<video id="ttVideo" playsinline preload="metadata" style="display:none"></video>';
h+='<div class="tt-overlay" id="ttOverlay"><div class="tt-overlay-btn"><i class="fas fa-play"></i></div></div>';
h+='<div class="tt-controls"><div class="tt-progress" id="ttProgress"><div class="tt-progress-fill" id="ttProgressFill"></div><div class="tt-progress-dot" id="ttProgressDot"></div></div>';
h+='<div class="tt-ctrl-row"><button class="tt-btn-ctrl" id="ttPlayBtn" type="button"><i class="fas fa-play"></i></button>';
h+='<button class="tt-btn-ctrl" id="ttMuteBtn" type="button"><i class="fas fa-volume-up"></i></button>';
h+='<input type="range" class="tt-vol" id="ttVolume" min="0" max="1" step="0.1" value="1">';
h+='<span class="tt-time" id="ttTime">0:00 / 0:00</span>';
h+='<span style="flex:1"></span>';
h+='<button class="tt-btn-ctrl" id="ttFsBtn" type="button"><i class="fas fa-expand"></i></button>';
h+='</div></div></div>';
h+='<div class="tt-details"><div class="tt-author"><i class="fas fa-user-circle"></i> @'+esc(TT_STATE.author)+'</div>';
h+='<div class="tt-caption">'+esc(TT_STATE.desc)+'</div>';
h+='<div class="tt-quality"><button class="tt-q-btn active" data-q="hd" type="button">HD</button><button class="tt-q-btn" data-q="normal" type="button">NORMAL</button><button class="tt-q-btn" data-q="audio" type="button">AUDIO</button></div>';
h+='<div class="tt-actions"><button class="tt-btn-action primary" id="ttDlVideo" type="button"><i class="fas fa-video"></i> VIDEO</button>';
h+='<button class="tt-btn-action secondary" id="ttDlAudio" type="button"><i class="fas fa-music"></i> AUDIO</button>';
h+='<button class="tt-btn-action ghost" id="ttCopyLink" type="button"><i class="fas fa-link"></i> LINK</button>';
h+='<button class="tt-btn-action ghost" id="ttCopyDesc" type="button"><i class="fas fa-copy"></i> TEKS</button>';
h+='</div></div>';
h+='<div class="tt-dl-box" id="ttDlBox"><div class="tt-dl-text"><span>MENGUNDUH...</span><span id="ttDlPct">0%</span></div><div class="tt-dl-track"><div class="tt-dl-fill" id="ttDlFill"></div></div></div>';
h+='</div>';
res.innerHTML=h;
res.style.display="block";
bindTikTokPlayer();
}
function bindTikTokPlayer(){
var video=$("ttVideo"),poster=$("ttPoster"),overlay=$("ttOverlay"),player=$("ttPlayer");
var playBtn=$("ttPlayBtn"),muteBtn=$("ttMuteBtn"),vol=$("ttVolume"),timeEl=$("ttTime");
var progress=$("ttProgress"),progFill=$("ttProgressFill"),progDot=$("ttProgressDot"),fsBtn=$("ttFsBtn");
var currentSrc=TT_STATE.hd;
if(overlay)overlay.onclick=function(){
overlay.classList.add("hide");
if(poster)poster.style.display="none";
if(video){video.style.display="block";video.src=currentSrc;video.play().catch(function(){});}
};
if(player)player.addEventListener("touchstart",function(){player.classList.add("touched");setTimeout(function(){player.classList.remove("touched");},3000);});
if(video){
video.onplay=function(){if(playBtn)playBtn.innerHTML='<i class="fas fa-pause"></i>';};
video.onpause=function(){if(playBtn)playBtn.innerHTML='<i class="fas fa-play"></i>';};
video.ontimeupdate=function(){if(!video.duration)return;var p=(video.currentTime/video.duration)*100;if(progFill)progFill.style.width=p+"%";if(progDot)progDot.style.left=p+"%";if(timeEl)timeEl.textContent=ttFmt(video.currentTime)+" / "+ttFmt(video.duration);};
}
if(playBtn)playBtn.onclick=function(){if(!video)return;if(video.paused)video.play();else video.pause();};
if(muteBtn)muteBtn.onclick=function(){if(!video)return;video.muted=!video.muted;muteBtn.innerHTML=video.muted?'<i class="fas fa-volume-mute"></i>':'<i class="fas fa-volume-up"></i>';};
if(vol)vol.oninput=function(){if(video)video.volume=this.value;};
if(progress)progress.onclick=function(e){if(!video||!video.duration)return;var r=progress.getBoundingClientRect();var p=(e.clientX-r.left)/r.width;video.currentTime=p*video.duration;};
if(fsBtn)fsBtn.onclick=function(){if(!player)return;if(document.fullscreenElement)document.exitFullscreen();else player.requestFullscreen().catch(function(){});};
document.querySelectorAll(".tt-q-btn").forEach(function(b){b.onclick=function(){
document.querySelectorAll(".tt-q-btn").forEach(function(x){x.classList.remove("active");});
b.classList.add("active");
var q=b.getAttribute("data-q");
if(q==="hd")currentSrc=TT_STATE.hd;
else if(q==="normal")currentSrc=TT_STATE.normal;
else currentSrc=TT_STATE.audio;
TT_STATE.currentQ=q;
if(video&&!overlay.classList.contains("hide")){
var t=video.currentTime,playing=!video.paused;
video.src=currentSrc;video.load();
video.onloadedmetadata=function(){video.currentTime=t;if(playing)video.play();video.onloadedmetadata=null;};
}
toast("Kualitas: "+b.textContent,"ok");
};});
var dlV=$("ttDlVideo"),dlA=$("ttDlAudio"),cpL=$("ttCopyLink"),cpD=$("ttCopyDesc");
if(dlV)dlV.onclick=function(){var src=TT_STATE.currentQ==="normal"?TT_STATE.normal:(TT_STATE.currentQ==="audio"?TT_STATE.audio:TT_STATE.hd);ttDownload(src,"tiktok_"+Date.now()+".mp4");};
if(dlA)dlA.onclick=function(){ttDownload(TT_STATE.audio,"tiktok_audio_"+Date.now()+".mp3");};
if(cpL)cpL.onclick=function(){copyText($("ttUrl").value);};
if(cpD)cpD.onclick=function(){copyText(TT_STATE.desc);};
}
function ttFmt(s){if(!s||isNaN(s))return "0:00";var m=Math.floor(s/60),sec=Math.floor(s%60);return m+":"+String(sec).padStart(2,"0");}
function ttDownload(url,name){
var box=$("ttDlBox"),fill=$("ttDlFill"),pct=$("ttDlPct");
if(box)box.classList.add("show");
if(fill)fill.style.width="0%";
if(pct)pct.textContent="0%";
fetch(url).then(function(res){
if(!res.ok)throw new Error("HTTP "+res.status);
var total=+res.headers.get("Content-Length")||0;
var reader=res.body.getReader();
var chunks=[];var recv=0;
function pump(){
return reader.read().then(function(r){
if(r.done){
var blob=new Blob(chunks);
var a=document.createElement("a");
a.href=URL.createObjectURL(blob);a.download=name;a.click();
setTimeout(function(){URL.revokeObjectURL(a.href);},3000);
toast("Download selesai","ok");
if(box)setTimeout(function(){box.classList.remove("show");},1200);
return;
}
chunks.push(r.value);recv+=r.value.length;
if(total&&fill&&pct){var p=Math.round((recv/total)*100);fill.style.width=p+"%";pct.textContent=p+"%";}
return pump();
});
}
return pump();
}).catch(function(){
window.open(url,"_blank");
if(box)box.classList.remove("show");
});
}
