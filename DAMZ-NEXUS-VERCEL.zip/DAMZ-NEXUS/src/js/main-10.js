
window.addEventListener("online",function(){toast("Koneksi pulih","ok");if(db&&CURRENT_USER){try{db.ref("members/"+CURRENT_USER+"/lastPing").set(new Date().toISOString());}catch(e){}}});
window.addEventListener("offline",function(){toast("Koneksi terputus","err");});

document.addEventListener("visibilitychange",function(){
if(document.visibilityState==="visible"&&CURRENT_USER&&db){
try{db.ref("members/"+CURRENT_USER+"/lastLogin").set(new Date().toISOString());}catch(e){}
}
});

setTimeout(function(){
if(CURRENT_USER&&typeof watchNewMessages==="function"&&!watchNewMessages._done)watchNewMessages();
if(CURRENT_USER&&typeof watchGroupMessagesNotif==="function"&&!watchGroupMessagesNotif._done)watchGroupMessagesNotif();
if(CURRENT_USER&&typeof watchJoinRequests==="function"&&!watchJoinRequests._done)watchJoinRequests();
if(CURRENT_USER&&typeof watchGroupNotifs==="function"&&!watchGroupNotifs._done)watchGroupNotifs();
if(CURRENT_USER&&typeof watchInvites==="function")watchInvites();
if(CURRENT_USER&&typeof watchIncomingCall==="function")watchIncomingCall();
},5000);

window.DAMZ_VERSION=APP_VERSION;
window.DAMZ_BUILD=Date.now();
console.log("%c DAMZ NEXUS v"+APP_VERSION+" ","background:linear-gradient(135deg,#00ff88,#22d3ee);color:#000;font-weight:900;padding:6px 12px;border-radius:6px;font-family:monospace;font-size:14px");
console.log("%c Sistem siap • "+new Date().toLocaleString("id-ID"),"color:#00ff88;font-family:monospace;font-size:11px");
