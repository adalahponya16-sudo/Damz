# DAMZ NEXUS v1

Static HTML/CSS/JavaScript project prepared for Vercel. No build command or package installation is required.

## Deploy to Vercel
1. Extract this ZIP.
2. Import the extracted project folder into a Git repository, then import that repository in Vercel (or use Vercel CLI from this folder).
3. Set **Framework Preset: Other**, **Build Command: empty**, **Output Directory: `.`**.
4. Deploy. The site entry point is `index.html`; the imported tool library is at `/tools/`.

## Project layout
- `index.html` — main app shell.
- `src/css/` — app and tool styles.
- `src/js/` — application modules and original tool registry.
- `tools/index.html` — tool-library page embedded by the main app.
- `config/firebase-config.js` — Firebase web client configuration.
- `vercel.json` — static hosting configuration.

## Important deployment security
This is a browser-only Firebase app. Firebase web config is visible to visitors by design; it is not an access-control mechanism. Before public deployment, configure Firebase Realtime Database Security Rules to enforce authentication and role permissions. The existing owner login logic also contains client-side credentials and is not secure against someone inspecting the source. Do not use this as a production admin system until owner authentication and privileged actions are moved behind a trusted server/Cloud Functions and the exposed default owner credential is rotated.

The project is packaged and syntax-checked, but a successful Vercel deployment and live multi-user Firebase test must be performed in the owner's Vercel/Firebase projects.
